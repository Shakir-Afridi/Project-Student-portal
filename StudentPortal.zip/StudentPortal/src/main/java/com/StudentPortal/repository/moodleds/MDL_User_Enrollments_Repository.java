package com.StudentPortal.repository.moodleds;

import com.StudentPortal.model.moodleds.MDL_User_Enrollments;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Created by abdul on 3/23/17.
 */
public interface MDL_User_Enrollments_Repository extends JpaRepository<MDL_User_Enrollments, Integer> {

    @Query("SELECT id from MDL_User_Enrollments where userid = :id")
    public List<Integer> get_enrolled_id(@Param("id") int id);
}
