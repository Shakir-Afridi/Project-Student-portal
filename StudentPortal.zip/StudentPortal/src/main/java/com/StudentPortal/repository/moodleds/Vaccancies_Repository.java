package com.StudentPortal.repository.moodleds;

import com.StudentPortal.model.moodleds.Vaccancies;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by abdul on 4/11/17.
 */
public interface Vaccancies_Repository extends JpaRepository <Vaccancies, Integer>{

    @Query ("SELECT j_id, date, due_date FROM Vaccancies")
    public List<Object> get_vaccancies();

    @Query ("SELECT j_id FROM Vaccancies WHERE j_id = :j_id")
    public Object get_J_Id(@Param("j_id") int j_id);

    @Modifying
    @Transactional
    @Query ("DELETE FROM Vaccancies WHERE j_id = :j_id")
    public void delete_Job_Vaccancy(@Param("j_id") int j_id);
}
