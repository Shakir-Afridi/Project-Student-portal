package com.StudentPortal.repository.moodleds;

import com.StudentPortal.model.moodleds.Fee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import javax.persistence.criteria.CriteriaBuilder;
import java.util.List;

/**
 * Created by Shakir Afridi on 2/17/17.
 */
public interface FeeRepository extends JpaRepository<Fee, Integer>{
    @Query("SELECT f.amount FROM Fee f WHERE f.fee_id = :fee_id")
    public Object findByfstFeeId(@Param("fee_id") int fee_id);

    @Query("SELECT f.amount FROM Fee f WHERE f.fee_id = :fee_id")
    public Object findBysndFeeId(@Param("fee_id") int fee_id);

    @Query("SELECT f.amount FROM Fee f WHERE f.fee_id = :fee_id")
    public Object findBythrdFeeId(@Param("fee_id") int fee_id);

    @Query("SELECT f.amount FROM Fee f WHERE f.fee_id = :fee_id")
    public Object findByfrthFeeId(@Param("fee_id") int fee_id);
}
