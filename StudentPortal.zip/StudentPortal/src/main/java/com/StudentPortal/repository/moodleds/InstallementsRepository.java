package com.StudentPortal.repository.moodleds;

import com.StudentPortal.model.moodleds.Installment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Created by Shakir Afridi on 2/20/17.
 */
public interface InstallementsRepository extends JpaRepository<Installment, Integer> {

    @Query("select i.fee_id,f.installement_type,f.duration_to,f.duration_from,i.paid_on,i.amount,i.due_for from Installment i,Fee f where f.fee_id!=1 and i.fee_id = f.fee_id and i.rollno = :rollno")
    public List<Object> findByRollNumber(@Param("rollno") String rollno);

    @Query("SELECT i.fee_id, i.rollno, i.paid_on, i.amount FROM Installment i WHERE i.rollno = :rollno AND i.fee_id=1")
    public List<Object> findByRollNumberHostelFee(@Param("rollno") String rollno);

    @Query("SELECT i.fee_id, i.rollno,i.paid_on,i.amount FROM Installment i WHERE i.rollno = :rollno AND i.fee_id=2")
    public List<Object> findByRollNumberFirstInstallement(@Param("rollno") String rollno);

    @Query ("SELECT i.fee_id, i.rollno,i.paid_on,i.amount FROM Installment i WHERE i.rollno = :rollno AND i.fee_id=3")
    public List<Object> findByRollNumberSecondInstallement(@Param("rollno") String rollno);
}