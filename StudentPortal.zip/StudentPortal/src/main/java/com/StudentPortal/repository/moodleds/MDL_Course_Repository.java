package com.StudentPortal.repository.moodleds;

import com.StudentPortal.model.moodleds.MDL_Course;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Created by abdul on 3/23/17.
 */
public interface MDL_Course_Repository extends JpaRepository<MDL_Course, Integer> {

    @Query("SELECT id, fullname, credithour from MDL_Course WHERE id IN (SELECT enrolid from MDL_User_Enrollments WHERE userid = :student_id) AND year = :year")
    public List<Object> getEnrolledCourses(@Param("student_id") int student_id, @Param("year") int year);

    @Query("SELECT id, idnumber from MDL_Course WHERE id IN (SELECT enrolid from MDL_User_Enrollments WHERE userid = :student_id) AND year = :year")
    public List<Object> getEnrolledCoursesId(@Param("student_id") int student_id, @Param("year") int year);

    @Query("SELECT c.id, c.fullname, c.shortname FROM MDL_Course c where c.year = :year AND c.id IN (select enrolid from MDL_User_Enrollments where userid = :userid)")
    public List<Object> get_CourseOffering_By_Year (@Param("year") int year, @Param("userid") int userid);

    @Query("SELECT id from MDL_Course WHERE id IN (SELECT enrolid from MDL_User_Enrollments WHERE userid = :student_id) AND year = :year")
    public List<Integer> getid(@Param("student_id") int student_id, @Param("year") int year);

    @Query("SELECT fullname,year FROM MDL_Course WHERE id IN (SELECT enrolid FROM MDL_User_Enrollments WHERE userid = (SELECT id FROM MDL_User WHERE username = :username))")
    public List<Object> get_teacher_modules(@Param("username") String username);

}
