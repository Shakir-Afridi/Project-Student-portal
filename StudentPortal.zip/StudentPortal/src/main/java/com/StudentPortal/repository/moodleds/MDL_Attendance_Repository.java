package com.StudentPortal.repository.moodleds;

import com.StudentPortal.model.moodleds.MDL_Attendance;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 * Created by abdul on 3/28/17.
 */
public interface MDL_Attendance_Repository extends JpaRepository <MDL_Attendance, Integer> {

    @Query ("SELECT id from MDL_Attendance where course = :course_id")
    public int get_attendance_id(@Param("course_id") int course_id);

}
