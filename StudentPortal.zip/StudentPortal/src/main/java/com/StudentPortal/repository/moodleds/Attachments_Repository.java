package com.StudentPortal.repository.moodleds;

import com.StudentPortal.model.moodleds.Attachments;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Created by abdul on 2/28/17.
 */
public interface Attachments_Repository extends JpaRepository<Attachments, Integer> {

    @Query("SELECT file_name FROM Attachments WHERE thread_id = :thread_id")
    public List<String> get_Thread_Files_Names(@Param("thread_id") int thread_id);

    @Query("SELECT file_name FROM Attachments WHERE reply_id = :reply_id")
    public List<String> get_reply_Files_Names(@Param("reply_id") int reply_id);

//    @Query("SELECT ")
}
