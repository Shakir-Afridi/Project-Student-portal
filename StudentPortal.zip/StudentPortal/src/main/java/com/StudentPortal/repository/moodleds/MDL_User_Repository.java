package com.StudentPortal.repository.moodleds;

import com.StudentPortal.model.moodleds.MDL_User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Created by abdul on 3/23/17.
 */
public interface MDL_User_Repository extends JpaRepository<MDL_User, Integer> {

    @Query ("SELECT id from MDL_User where currentlyenrolled = :year")
    public List<Integer> get_user_id(@Param("year") int year);

    @Query ("SELECT id, password, firstname, lastname, currently_enrolled FROM MDL_User where username = :username")
    public List<Object> get_password(@Param("username") String username);

    @Query ("SELECT email, department, enrollmentYear, graduating_year, currently_enrolled, pat, fyp_supervisor, address, phone1, phone2 FROM MDL_User WHERE username = :username")
    public List<Object> get_Student_Information(@Param("username") String username);

    @Query ("SELECT firstname, lastname, email, address, department, phone1, phone2 FROM MDL_User WHERE id = :id")
    public List<Object> get_Teacher_Information(@Param("id") int id);

    @Query ("SELECT id from MDL_User where username = :username")
    public int get_user_id(@Param("username") String username);

    @Query ("SELECT id from MDL_User where currentlyenrolled = 3 AND department = 'EE'")
    public List<Integer> get_CS_User_id();

    @Query ("SELECT currently_enrolled FROM MDL_User WHERE id = :id")
    public int find_year(@Param("id") int id);

    @Query ("SELECT email FROM MDL_User WHERE username = :username")
    public String get_Email_Id(@Param("username") String username);

    @Query ("SELECT firstname, lastname FROM MDL_User WHERE email = :email")
    public List<Object> get_Name_By_Email(@Param("email") String email);


    @Query("SELECT username, firstname, lastname, currently_enrolled FROM MDL_User WHERE pat = (SELECT id FROM MDL_User WHERE username = :username)")
    public List<Object> get_students_as_pat(@Param("username") String username);

    @Query("SELECT username, firstname, lastname FROM MDL_User WHERE fypsupervisor = (SELECT id FROM MDL_User WHERE username = :username)")
    public List<Object> get_students_as_fypsupervisor(@Param("username") String username);

    @Query("select firstname, lastname from MDL_User where username = (select uob from Societies_Body where j_id = 13 and patron = :username)")
    public List<Object> get_societies_president(@Param("username") String username);

    @Query("select firstname, lastname from MDL_User where username = (select uob from Societies_Body where j_id = 14 and patron = :username)")
    public List<Object> get_societies_GS(@Param("username") String username);

    @Query("select firstname, lastname from MDL_User where username = (select uob from Societies_Body where j_id = 15 and patron = :username)")
    public List<Object> get_societies_FM(@Param("username") String username);

    @Query("select firstname, lastname from MDL_User where username = (select uob from Societies_Body where j_id = 16 and patron = :username)")
    public List<Object> get_societies_MM(@Param("username") String username);

    @Query("select username, firstname, lastname, currently_enrolled from MDL_User where username in (select uob from Societies_Body where j_id = 17 and patron = :username)")
    public List<Object> get_societies_EM(@Param("username") String username);

    @Query("select username, firstname, lastname, currently_enrolled from MDL_User where username in (select uob from Societies_Body where j_id = 18 and patron = :username)")
    public List<Object> get_societies_M(@Param("username") String username);


    @Query(" select username,firstname, lastname from MDL_User where id in (select userid from MDL_User_Enrollments where enrolid in (select enrolid from MDL_User_Enrollments where userid = (select id from MDL_User where username = :username))) and username like '1%'")
    public List<Object> getStudents(@Param("username") String username);

    // For SSO
    @Query("select firstname,lastname,username,currently_enrolled,department from MDL_User where username = :username")
    public List<Object> get_requested_students(@Param("username") String username);

    @Query ("SELECT firstname, lastname, email, phone1, phone2, department, address FROM MDL_User WHERE username = :username")
    public List<Object> get_teacher(@Param("username") String username);

    @Query ("SELECT firstname, lastname FROM MDL_User WHERE username = :username")
    public List<Object> get_Name(@Param("username") String username);
}
