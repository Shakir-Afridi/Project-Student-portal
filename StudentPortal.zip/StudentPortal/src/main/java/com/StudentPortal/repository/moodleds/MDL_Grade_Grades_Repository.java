package com.StudentPortal.repository.moodleds;

import com.StudentPortal.model.moodleds.MDL_Grade_Grades;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 * Created by abdul on 3/23/17.
 */
public interface MDL_Grade_Grades_Repository extends JpaRepository<MDL_Grade_Grades, Integer> {

    @Query("SELECT finalgrade from MDL_Grade_Grades WHERE itemid = :item_id AND userid = :user_id")
    public int assessment_grades(@Param("item_id") int item_id, @Param("user_id") int user_id);
}
