package com.StudentPortal.repository.papercutds;

import com.StudentPortal.model.papercutds.Tbl_Account;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import javax.tools.JavaCompiler;

/**
 * Created by abdul on 4/21/17.
 */
public interface Tbl_Account_Repository extends JpaRepository <Tbl_Account, Integer> {


    @Query ("SELECT balance FROM Tbl_Account WHERE account_id = :account_id")
    public float get_Balance(@Param("account_id") int account_id);
}
