package com.StudentPortal.repository.moodleds;

import com.StudentPortal.model.moodleds.Messages;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by abdul on 2/25/17.
 */
public interface Messages_Repository extends JpaRepository <Messages, Integer> {

    @Query("SELECT m.thread_id, m.sender_name, m.date, m.time FROM Messages m WHERE m.reciever_id = :receiver_email_id AND m.read_unread = :read_unread")
    public List<Object> get_Sender_Information(@Param("receiver_email_id") String receiver_email_id, @Param("read_unread") boolean read_unread);

    @Query("SELECT m.thread_id, m.receiver_name, m.date, m.time FROM Messages m WHERE m.sender_emailid = :sender_email_id")
    public List<Object> get_Receiver_Information(@Param("sender_email_id") String sender_email_id);

    @Modifying
    @Transactional
    @Query("UPDATE Messages m set m.read_unread = :status WHERE m.thread_id = :thread_id")
    public void change_Message_Status(@Param("status") boolean status, @Param("thread_id") int thread_id);

    @Query("SELECT sender_name, sender_emailid, reciever_id, message FROM Messages WHERE thread_id = :thread_id")
    public List<Object> get_Message(@Param("thread_id") int thread_id);

    @Query("SELECT sender_emailid, reciever_id, sender_name, receiver_name FROM Messages WHERE thread_id = :thread_id")
    public List<Object> get_Information_For_Reply(@Param("thread_id") int thread_id);

    @Query ("SELECT sender_name, message FROM Messages WHERE reciever_id = :reciever_id AND read_unread = false")
    public List<Object> messages_mime(@Param("reciever_id") String reciever_id);


}
