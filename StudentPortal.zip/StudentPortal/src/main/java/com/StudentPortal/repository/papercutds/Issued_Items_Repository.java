package com.StudentPortal.repository.papercutds;

import com.StudentPortal.model.papercutds.Issued_Items;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

/**
 * Created by abdul on 4/21/17.
 */
public interface Issued_Items_Repository extends JpaRepository <Issued_Items, Integer> {


    @Query ("SELECT item_id, issue_date, due_date, user_id, quantity FROM Issued_Items")
    public List<Object> get_Issued_Items();

    @Query ("SELECT quantity FROM Issued_Items WHERE item_id = :item_id AND issue_date = :issue_date")
    public int get_Quantity(@Param("item_id") int item_id, @Param("issue_date") Date issue_date);

    @Query ("SELECT issue_date FROM Issued_Items WHERE item_id = :item_id")
    public Date get_date(@Param("item_id") int item_id);

    @Transactional
    @Modifying
    @Query ("DELETE FROM Issued_Items WHERE item_id = :item_id AND issue_date = :issue_date")
    public void delete_Record(@Param("item_id") int item_id, @Param("issue_date") Date issue_date);

    @Query ("SELECT item_id, issue_date, due_date, quantity FROM Issued_Items WHERE user_id = :user_id")
    public List<Object> get_Issued_Items(@Param("user_id") int user_id);
}
