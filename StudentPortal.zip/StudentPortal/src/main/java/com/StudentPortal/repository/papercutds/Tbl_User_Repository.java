package com.StudentPortal.repository.papercutds;

import com.StudentPortal.model.papercutds.Tbl_User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

/**
 * Created by abdul on 4/21/17.
 */
public interface Tbl_User_Repository extends JpaRepository <Tbl_User, Integer> {

    @Query ("SELECT full_name, user_name, email FROM Tbl_User WHERE user_id = :user_id")
    public List<Object> get_User_Information(@Param("user_id") int user_id);

    @Query ("SELECT user_id FROM Tbl_User WHERE user_name = :user_name")
    public int get_User_Id(@Param("user_name") String user_name);

    @Query ("SELECT email FROM Tbl_User WHERE user_id = :user_id")
    public String get_Email(@Param("user_id") int user_id);
}
