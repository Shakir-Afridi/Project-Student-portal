package com.StudentPortal.repository.moodleds;

import com.StudentPortal.model.moodleds.Messages_Reply;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by abdul on 2/25/17.
 */
public interface Messages_Reply_Repository extends JpaRepository <Messages_Reply, Integer> {

    @Query("SELECT reply_id, sender_name, sender_emailid, reciever_emailid, message FROM Messages_Reply WHERE thread_id = :thread_id")
    public List<Object> get_Thread_Replies(@Param("thread_id") int thread_id);

    @Query("SELECT reply_id FROM Messages_Reply WHERE thread_id = :thread_id AND reciever_emailid = :email_id AND read_unread = false")
    public Object[] get_Reply_Status(@Param("thread_id") int thread_id, @Param("email_id") String email_id);

    @Query("SELECT reply_id FROM Messages_Reply WHERE thread_id = :thread_id AND sender_emailid = :email_id")
    public Object[] get_Sender_Reply_Status(@Param("thread_id") int thread_id, @Param("email_id") String email_id);

    @Modifying
    @Transactional
    @Query("UPDATE Messages_Reply set read_unread = True WHERE thread_id = :thread_id AND reciever_emailid = :reciever_emailid")
    public void update_Reply_Messages_Status(@Param("thread_id") int thread_id, @Param("reciever_emailid") String reciever_emailid);
}
