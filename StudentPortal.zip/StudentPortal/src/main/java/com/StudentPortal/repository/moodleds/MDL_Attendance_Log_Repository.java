package com.StudentPortal.repository.moodleds;

import com.StudentPortal.model.moodleds.MDL_Attendance_Log;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 * Created by abdul on 3/28/17.
 */
public interface MDL_Attendance_Log_Repository extends JpaRepository <MDL_Attendance_Log, Integer>{

    //get count of sessions present, absent and leave
    @Query ("SELECT COUNT(*) FROM MDL_Attendance_Log WHERE studentid = :studentid AND sessionid IN (SELECT id from MDL_Attendance_Sessions WHERE attendanceid = :attendanceid) AND statusid = :statusid")
    public int count_Present(@Param("studentid") int studentid, @Param("attendanceid") int attendanceid, @Param("statusid") int statusid);

    @Query ("SELECT COUNT(*) FROM MDL_Attendance_Log WHERE studentid = :studentid AND sessionid IN (SELECT id from MDL_Attendance_Sessions WHERE attendanceid = :attendanceid) AND statusid = :statusid")
    public int count_Absents(@Param("studentid") int studentid, @Param("attendanceid") int attendanceid, @Param("statusid") int statusid);

    @Query ("SELECT statusid FROM MDL_Attendance_Log WHERE studentid = :studentid AND sessionid = :sessionid")
    public int status_attendance(@Param("studentid") int studentid, @Param("sessionid") int sessionid);
}
