package com.StudentPortal.repository.moodleds;

import com.StudentPortal.model.moodleds.MDL_Attendance_Sessions;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Created by abdul on 3/28/17.
 */
public interface MDL_Attendance_Sessions_Repository extends JpaRepository <MDL_Attendance_Sessions, Integer>{

    @Query ("SELECT id, sessdate from MDL_Attendance_Sessions WHERE attendanceid = :attendance_id")
    public List<Object> sessions_information(@Param("attendance_id") int attendance_id);

    @Query ("SELECT COUNT(*) FROM MDL_Attendance_Sessions WHERE attendanceid = :attendanceid")
    public int count_sessions(@Param("attendanceid") int attendanceid);

    @Query ("SELECT id from MDL_Attendance_Sessions WHERE attendanceid = :attendance_id")
    public List<Integer> sessions(@Param("attendance_id") int attendance_id);

}
