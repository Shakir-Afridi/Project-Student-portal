package com.StudentPortal.repository.papercutds;

import com.StudentPortal.model.papercutds.Tbl_Printer_Usage_Log;
import org.springframework.aop.target.LazyInitTargetSource;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Created by abdul on 4/23/17.
 */
public interface Tbl_Printer_Usage_Log_Repository extends JpaRepository<Tbl_Printer_Usage_Log, Integer> {

    @Query ("SELECT usage_date, usage_cost, total_pages FROM Tbl_Printer_Usage_Log WHERE user_id = :user_id")
    public List<Object> get_Account_Information(@Param("user_id") int user_id);
}
