package com.StudentPortal.repository.moodleds;

import com.StudentPortal.model.moodleds.Jobs;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Created by abdul on 2/2/17.
 */
public interface MDL_Jobs_Repository extends JpaRepository <Jobs, Integer> {

    @Query("SELECT j_id, j_title, j_nature, j_socity FROM Jobs j WHERE j.j_id = :j_id")
    public List<Object> findJobById(@Param("j_id") int j_id);

    @Query ("SELECT j_nature FROM Jobs WHERE j_id = :j_id")
    public String get_Job_Nature(@Param("j_id") int j_id);

    @Query ("SELECT j_title, j_nature FROM Jobs WHERE j_id = :j_id")
    public List<Object> get_Title_Nature(@Param("j_id") int j_id);

    @Query ("SELECT j_socity FROM Jobs WHERE j_id = :j_id")
    public String get_society(@Param("j_id") int id);

    @Query("select j_id, j_nature from Jobs where j_id in (select j_id from Societies_Body where patron = :username) and j_title = 'President'")
    public List<Object> find_society_name_by_patron(@Param("username") String username);

    // for SSO
    @Query("select j_nature from Jobs where j_id = :j_id")
    public String get_job_for_requests(@Param("j_id") int j_id);

    @Query ("SELECT j_title FROM Jobs WHERE j_id = :j_id")
    public String get_Title(@Param("j_id") int j_id);

    @Query ("SELECT j_id FROM Jobs WHERE j_nature = :j_nature")
    public int get_j_id_by_j_nature(@Param("j_nature") String j_nature);
}
