package com.StudentPortal.repository.moodleds;

import com.StudentPortal.model.moodleds.MDL_Attendance_Statuses;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Created by abdul on 3/28/17.
 */
public interface MDL_Attendance_Statuses_Repository extends JpaRepository <MDL_Attendance_Statuses, Integer>{

    @Query ("SELECT id from MDL_Attendance_Statuses WHERE attendanceid = :attendance_id AND acronym = 'P'")
    public int get_present_status_id(@Param("attendance_id") int attendance_id);

    @Query ("SELECT id from MDL_Attendance_Statuses WHERE attendanceid = :attendance_id AND acronym = 'A'")
    public int get_absent_status_id(@Param("attendance_id") int attendance_id);

    @Query ("SELECT id from MDL_Attendance_Statuses WHERE attendanceid = :attendance_id")
    public List<Integer> get_statuses_id(@Param("attendance_id") int attendance_id);

    @Query ("SELECT description FROM MDL_Attendance_Statuses WHERE id = :id")
    public String get_Status(@Param("id") int id);
}
