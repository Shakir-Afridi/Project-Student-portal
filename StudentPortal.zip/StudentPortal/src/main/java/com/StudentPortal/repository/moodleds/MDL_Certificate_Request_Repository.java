package com.StudentPortal.repository.moodleds;

import com.StudentPortal.model.moodleds.MDL_Certificates_Requests;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

/**
 * Created by abdul on 4/11/17.
 */
public interface MDL_Certificate_Request_Repository extends JpaRepository <MDL_Certificates_Requests, Integer> {


    @Query ("SELECT id FROM MDL_Certificates_Requests WHERE username = :username AND j_id = :j_id")
    public Object check_Request(@Param("username") String username, @Param("j_id") int j_id);

    @Query ("SELECT request_date, j_id, recieved_date, status FROM MDL_Certificates_Requests WHERE username = :username")
    public List<Object> certificates_information(@Param("username") String username);

//    @Query("select username from MDL_Certificates_Requests where recieved_date is null")
//    public List<Object> get_requested_uob();

    @Query("select j_id,request_date, username, recieved_date from MDL_Certificates_Requests where recieved_date is not null")
    public List<Object> get_issued_certificates_uob();

    @Query("select j_id, request_date, username, status from MDL_Certificates_Requests where recieved_date is null")
    public List<Object> get_requested_j_id();

    @Query("select j_id from MDL_Certificates_Requests where username = :username")
    public int get_issued_certificates_j_id(@Param("username") String username);

    @Query("select request_date from MDL_Certificates_Requests where username = :uname")
    public Date get_pending_request_date(@Param("uname") String urname);

    @Query("select request_date from MDL_Certificates_Requests where username is :uname")
    public Date get_confirm_request_date(@Param("uname") String uname);

    @Modifying
    @Transactional
    @Query ("UPDATE MDL_Certificates_Requests SET status = :status WHERE username = :username AND j_id = :j_id")
    public void change_Status(@Param("username") String username, @Param("j_id") int j_id, @Param("status") boolean status);

    @Modifying
    @Transactional
    @Query ("UPDATE MDL_Certificates_Requests SET status = true, recieved_date = :recieved_date WHERE username = :username AND j_id = :j_id")
    public void issue_certificate(@Param("username") String username, @Param("j_id") int j_id, @Param("recieved_date") Date recieved_date);
}
