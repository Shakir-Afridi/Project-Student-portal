package com.StudentPortal.repository.moodleds;

import com.StudentPortal.model.moodleds.Current_Status_Societies;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Created by abdul on 4/9/17.
 */
public interface Current_Status_Societies_Repository extends JpaRepository <Current_Status_Societies, Integer>{

    @Query ("SELECT joining_date, j_id FROM Current_Status_Societies WHERE j_id IN (SELECT j_id FROM Jobs WHERE j_society = 'Work Study') AND status = true AND username = :username")
    public List<Object> get_Current_Work_Study_Record(@Param("username") String username);

    @Query ("SELECT joining_date, leaving_date, j_id FROM Current_Status_Societies WHERE j_id IN (SELECT j_id FROM Jobs WHERE j_society = 'Work Study') AND status = false AND username = :username")
    public List<Object> get_Past_Work_Study_Record(@Param("username") String username);

    @Query ("SELECT joining_date, j_id FROM Current_Status_Societies WHERE j_id IN (SELECT j_id FROM Jobs WHERE j_society = 'Society') AND status = true AND username = :username")
    public List<Object> get_Current_Societies_Record(@Param("username") String username);

    @Query ("SELECT joining_date, leaving_date, j_id FROM Current_Status_Societies WHERE j_id IN (SELECT j_id FROM Jobs WHERE j_society = 'Society') AND status = false AND username = :username")
    public List<Object> get_Past_Societies_Record(@Param("username") String username);

    @Query ("SELECT joining_date, j_id FROM Current_Status_Societies WHERE j_id IN (SELECT j_id FROM Jobs WHERE j_society = 'NIST') AND status = true AND username = :username")
    public List<Object> get_Current_NIST_Record(@Param("username") String username);

    @Query ("SELECT joining_date, leaving_date, j_id FROM Current_Status_Societies WHERE j_id IN (SELECT j_id FROM Jobs WHERE j_society = 'NIST') AND status = false AND username = :username")
    public List<Object> get_Past_NIST_Record(@Param("username") String username);

    @Query ("SELECT joining_date, leaving_date FROM Current_Status_Societies WHERE username = :username AND j_id = :j_id AND leaving_date IS NOT NULL")
    public List<Object> get_Joining_Leaving_Date(@Param("username")String username, @Param("j_id") int j_id);
}
