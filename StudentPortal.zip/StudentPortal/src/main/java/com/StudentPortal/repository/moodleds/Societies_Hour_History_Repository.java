package com.StudentPortal.repository.moodleds;

import com.StudentPortal.model.moodleds.Societies_Hour_History;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Created by abdul on 4/9/17.
 */
public interface Societies_Hour_History_Repository  extends JpaRepository <Societies_Hour_History, Integer>{

    @Query("SELECT from_date, to_date, hours FROM Societies_Hour_History WHERE username = :username AND j_id = :j_id")
    public List<Object> get_Past_Societies_hours(@Param("username") String username, @Param("j_id") int j_id);
}
