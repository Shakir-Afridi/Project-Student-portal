package com.StudentPortal.repository.moodleds;

import com.StudentPortal.model.moodleds.Societies_Body;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Created by abdul on 2/2/17.
 */
public interface Societies_BodyRepository extends JpaRepository <Societies_Body, Integer> {

    @Query ("SELECT j_id, uob FROM Societies_Body WHERE patron = :username")
    public List<Object> get_jid_uob_by_patron(@Param("username") String username);
//    @Query("select firstname, lastname from MDL_User where username in (select UoB from Societies_Body where j_id in (13) and Patron = :username")
//    public String get_societies_president(@Param("username") String username);
//
//    @Query("select firstname, lastname from MDL_User where username in (select UoB from Societies_Body where j_id in (14) and Patron = :username")
//    public String get_societies_GS(@Param("username") String username);
//
//    @Query("select firstname, lastname from MDL_User where username in (select UoB from Societies_Body where j_id in (15) and Patron = :username")
//    public String get_societies_FM(@Param("username") String username);
//
//    @Query("select firstname, lastname from MDL_User where username in (select UoB from Societies_Body where j_id in (16) and Patron = :username")
//    public String get_societies_MM(@Param("username") String username);
//
//    @Query("select firstname, lastname from MDL_User where username in (select UoB from Societies_Body where j_id in (17) and Patron = :username")
//    public List<Object> get_societies_EM(@Param("username") String username);
//
//    @Query("select firstname, lastname from MDL_User where username in (select UoB from Societies_Body where j_id in (18) and Patron = :username")
//    public List<Object> get_societies_members(@Param("username") String username);
}
