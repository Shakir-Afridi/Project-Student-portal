package com.StudentPortal.repository.moodleds;

import com.StudentPortal.model.moodleds.Working_Hour_History;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Created by abdul on 4/9/17.
 */
public interface Working_Hour_History_Repository extends JpaRepository<Working_Hour_History, Integer> {

    @Query("SELECT w.to_date, w.from_date, w.hours, w.pay, w.paid FROM Working_Hour_History w WHERE w.username = :username AND j_id = :j_id")
    public List<Object> get_Working_hours_details(@Param("username") String username, @Param("j_id") int j_id);
}
