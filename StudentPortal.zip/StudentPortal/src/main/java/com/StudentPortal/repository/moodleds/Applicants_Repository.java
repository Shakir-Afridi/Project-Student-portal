package com.StudentPortal.repository.moodleds;

import com.StudentPortal.model.moodleds.Applicants;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

/**
 * Created by abdul on 4/12/17.
 */
public interface Applicants_Repository extends JpaRepository<Applicants, Integer> {

    @Query ("SELECT a_id FROM Applicants WHERE username = :username AND v_id = :v_id")
    public Object verify_Request(@Param("username") String username, @Param("v_id") int v_id);

    @Modifying
    @Transactional
    @Query ("DELETE FROM Applicants WHERE username = :username AND v_id = :v_id")
    public void remove_Request(@Param("username") String username, @Param("v_id") int v_id);
}
