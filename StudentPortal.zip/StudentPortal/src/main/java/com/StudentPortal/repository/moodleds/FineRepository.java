package com.StudentPortal.repository.moodleds;

import com.StudentPortal.model.moodleds.Fine;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Created by Shakir Afridi on 2/18/17.
 */

public interface FineRepository extends JpaRepository<Fine, Integer>{

    @Query("SELECT f.f_id,f.rollno, f.submission_date, f.due_date, f.fining_authority, f.amount FROM Fine f WHERE f.rollno = :rollno")
    public List<Object> findByRollNumber(@Param("rollno") String rollno);
}