package com.StudentPortal.repository.moodleds;

import com.StudentPortal.model.moodleds.Working_Hour;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Created by abdul on 2/2/17.
 */
public interface Working_HousrRepository extends JpaRepository <Working_Hour, Integer> {

    @Query("SELECT w.to_date, w.from_date, w.hours, w.pay, w.paid FROM Working_Hour w WHERE w.username = :username AND job = :j_id")
    public List<Object> get_Working_hours_details(@Param("username") String username, @Param("j_id") int j_id);

    @Query("SELECT w.to_date, w.from_date, w.hours, w.pay, w.paid FROM Working_Hour w WHERE w.username = :username AND w.job = :job")
    public List<Object> get_Job_Details(@Param("username") String username, @Param("job") int job);
}
