package com.StudentPortal.repository.papercutds;

import com.StudentPortal.model.papercutds.Items;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by abdul on 4/21/17.
 */
public interface Items_Repository extends JpaRepository <Items, Integer> {

    @Query ("SELECT item_name, item_model FROM Items WHERE item_id = :item_id")
    public List<Object> get_Items(@Param("item_id") int item_id);

    @Query ("SELECT id, item_name, item_model FROM Items")
    public List<Object> get_All_Items();

    @Query ("SELECT remaining_items, issued_items FROM Items WHERE item_id = :id")
    public List<Object> get_Item_Quantity(@Param("id") int id);

    @Modifying
    @Transactional
    @Query ("UPDATE Items set issued_items = :issued_items, remaining_items = :remaining_items WHERE item_id = :item_id")
    public void update_items(@Param("issued_items") int issued_items, @Param("remaining_items") int remaining_items, @Param("item_id") int item_id);

    @Query ("SELECT item_name, item_model, quantity, issued_items, remaining_items, id FROM Items")
    public List<Object> get_Items();

    @Transactional
    @Modifying
    @Query ("UPDATE Items SET issued_items = issued_items - :quantity, remaining_items = remaining_items + :quantity WHERE item_id = :item_id")
    public void returned_Item(@Param("item_id") int item_id, @Param("quantity") int quantity);

    @Transactional
    @Modifying
    @Query ("UPDATE Items SET quantity = :quantity, remaining_items = :quantity - issued_items WHERE item_id = :item_id")
    public void update_Quantity(@Param("quantity") int quantity, @Param("item_id") int item_id);

    @Transactional
    @Modifying
    @Query ("DELETE FROM Items WHERE item_id = :item_id")
    public void delete_Item(@Param("item_id") int item_id);
}
