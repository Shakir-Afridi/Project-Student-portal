package com.StudentPortal.repository.moodleds;

import com.StudentPortal.model.moodleds.MDL_Course_Completion;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created by abdul on 3/23/17.
 */
public interface MDL_Course_Completion_Repository extends JpaRepository<MDL_Course_Completion, Integer> {
}
