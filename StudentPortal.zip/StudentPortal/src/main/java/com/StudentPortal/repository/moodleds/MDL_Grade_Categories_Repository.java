package com.StudentPortal.repository.moodleds;

import com.StudentPortal.model.moodleds.MDL_Grade_Categories;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Created by abdul on 3/23/17.
 */
public interface MDL_Grade_Categories_Repository extends JpaRepository<MDL_Grade_Categories, Integer> {

    @Query("SELECT id, fullname, weightage FROM MDL_Grade_Categories WHERE courseid = :courseid")
    public List<Object> get_module_assessments(@Param("courseid") int course_id);

    @Query("SELECT id, weightage FROM MDL_Grade_Categories WHERE courseid = :courseid")
    public List<Object> get_module_assessments_id(@Param("courseid") int course_id);
}
