package com.StudentPortal.repository.moodleds;

import com.StudentPortal.model.moodleds.Societies_Body_History;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Created by abdul on 4/28/17.
 */
public interface Societies_Body_History_Repository extends JpaRepository <Societies_Body_History, Integer> {

    @Query ("SELECT j_id, uob FROM Societies_Body_History WHERE patron = :patron")
    public List<Object> get_History(@Param("patron") String patron);
}
