package com.StudentPortal.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import javax.servlet.http.HttpSession;

/**
 * Created by abdul on 4/24/17.
 */
@Controller
@SessionAttributes(value = {"fac_name", "name", "id"})
public class Teacher_DashBoard_Controller {

    @RequestMapping (value = "/teacher_dashboard")
    public String dash_board(ModelMap modelMap, HttpSession httpSession){

        String fac_name = (String) httpSession.getAttribute("fac_name");
        if(fac_name == null){
            return "redirect:/";
        }

        return "teacher_dashboard";
    }
}
