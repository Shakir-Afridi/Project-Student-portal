package com.StudentPortal.controllers;

import com.StudentPortal.Data.Certificates_;
import com.StudentPortal.repository.moodleds.MDL_Certificate_Request_Repository;
import com.StudentPortal.repository.moodleds.MDL_Jobs_Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

/**
 * Created by abdul on 3/10/17.
 */

@Controller
@SessionAttributes(value = {"username", "name", "id"})
public class CertificatesController {


    @Autowired
    MDL_Certificate_Request_Repository mdl_certificate_request_repository;

    @Autowired
    MDL_Jobs_Repository mdl_jobs_repository;

    @RequestMapping(value = "/certificates")
    public String certificates(ModelMap modelMap, HttpSession httpSession){

        String username = (String) httpSession.getAttribute("username");
        if(username == null){
            return "redirect:/";
        }


        List<Certificates_> certificates = new ArrayList<>();
        List<Object> requested_certificates = mdl_certificate_request_repository.certificates_information(username);
        Iterator iterator = requested_certificates.iterator();

        while (iterator.hasNext()){

            Object[] certificates_information = (Object[]) iterator.next();
            Date request_date = (Date) certificates_information[0];
            int j_id = (int) certificates_information[1];
            Date recieved_date = (Date) certificates_information[2];
            boolean status = (boolean) certificates_information[3];

            List<Object> job = mdl_jobs_repository.get_Title_Nature(j_id);
            Object[] title_nature =  (Object[]) job.iterator().next();
            String title = (String) title_nature[0];
            String nature = (String) title_nature[1];

            Certificates_ certificates_ = null;
            if(status == false && recieved_date == null) {
                certificates_ = new Certificates_(String.valueOf(request_date).split(" ")[0], title, nature, "Not Ready", "Not Recieved");
            }
            else if(status == true && recieved_date == null){
                certificates_ = new Certificates_(String.valueOf(request_date).split(" ")[0], title, nature, "Ready", "Not Recieved");
            }
            else if(status == true && recieved_date != null){
                certificates_ = new Certificates_(String.valueOf(request_date).split(" ")[0], title, nature, "Received", String.valueOf(recieved_date).split(" ")[0]);
            }

            certificates.add(certificates_);
        }

        modelMap.put("certificates", certificates);

        return "Certificates";
    }
}
