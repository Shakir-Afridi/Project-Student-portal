package com.StudentPortal.controllers;

import com.StudentPortal.repository.moodleds.MDL_User_Repository;
import org.apache.tomcat.jni.Buffer;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.Banner;
import org.springframework.core.env.Environment;
import org.springframework.core.env.SystemEnvironmentPropertySource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import javax.servlet.http.HttpSession;
import java.util.*;

/**
 * Created by abdul on 1/3/17.
 */

@Controller
//@SessionAttributes(value = {"login_uob", "name"})
public class LogInController {

    @Autowired
    MDL_User_Repository mdl_user_repository;

    //Handle Request for login.
    @RequestMapping (value = "/", method = RequestMethod.GET)
    public String log_in(){
//        return "teacher_dashboard";
        return "login";
    }

    //Handling Request for home.
    @RequestMapping(value = "/", method = RequestMethod.POST)
    public String home(@RequestParam("username") String username, @RequestParam("password") String password, ModelMap modelMap,
                       HttpSession httpSession){

        List<Object> student_id_pass = mdl_user_repository.get_password(username);
        Iterator iterator = student_id_pass.iterator();
        Object[] objects = (Object[]) iterator.next();
        int id = (int) objects[0];
        String pass = (String) objects[1];
        String first_name = (String) objects[2];
        String last_name = (String) objects[3];
        String name = first_name + " " + last_name;

        int student_faculty = (int) objects[4];

        System.out.println(pass + " " + username);

        if(pass.equals(password)){
            if(student_faculty != -1) {

                System.out.println(username + "   " + name + "    " + id);
                httpSession.setMaxInactiveInterval(60*30);

                httpSession.setAttribute("username", username);
                httpSession.setAttribute("name", name);
                httpSession.setAttribute("id", id);
//                modelMap.addAttribute("id", id);
                return "redirect:/dashboard";
            }else if(student_faculty == -1){

                if(username.equals("itsc")){
                    httpSession.setMaxInactiveInterval(60*30);

                    httpSession.setAttribute("itsc", username);
                    httpSession.setAttribute("name", name);
                    httpSession.setAttribute("id", id);
                    return "redirect:/ITSC_Dashboard";
                }else if(username.equals("sso")){

                    httpSession.setMaxInactiveInterval(60*30);
                    httpSession.setAttribute("sso_name", username);
                    httpSession.setAttribute("name", name);
                    httpSession.setAttribute("id", id);
                    return "redirect:/sso_dashboard";

                } else {
                    httpSession.setMaxInactiveInterval(60*30);
                    httpSession.setAttribute("fac_name", username);
                    httpSession.setAttribute("name", name);
                    httpSession.setAttribute("id", id);
                    return "redirect:/teacher_dashboard";
                }
            }
        }else{
            return "redirect:/";
        }
        return "redirect:/";
    }

    @RequestMapping (value = "/logout")
    public String logout(HttpSession httpSession){

        httpSession.invalidate();
        return "redirect:/";
    }
}
