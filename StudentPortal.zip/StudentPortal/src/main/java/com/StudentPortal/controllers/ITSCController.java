package com.StudentPortal.controllers;

import com.StudentPortal.Data.Account_Information;
import com.StudentPortal.Data.Issued_Items_Data;
import com.StudentPortal.model.papercutds.Tbl_Printer_Usage_Log;
import com.StudentPortal.repository.papercutds.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;


/**
 * Created by abdul on 3/10/17.
 */
@Controller
@SessionAttributes(value = {"username", "name", "id"})
public class ITSCController {

    @Autowired
    private Issued_Items_Repository issued_items_repository;

    @Autowired
    private Tbl_User_Repository tbl_user_repository;

    @Autowired
    private Items_Repository items_repository;

    @Autowired
    private Tbl_User_Account_Repository tbl_user_account_repository;

    @Autowired
    private Tbl_Account_Repository tbl_account_repository;

    @Autowired
    Tbl_Printer_Usage_Log_Repository tbl_printer_usage_log_repository;

    @RequestMapping(value = "/ITSC")
    public String itsc(ModelMap modelMap, HttpSession httpSession){

        String username = (String) httpSession.getAttribute("username");
        if(username == null){
            return "redirect:/";
        }

        List<Issued_Items_Data> issued_items_data = new ArrayList<>();

        int user_id = tbl_user_repository.get_User_Id(username);
        System.out.println("User id is: " + user_id);
        List<Object> issued_items_list = issued_items_repository.get_Issued_Items(user_id);
        Iterator iterator_issued_items_list = issued_items_list.iterator();

        while (iterator_issued_items_list.hasNext()){

            Object[] issued_items = (Object[]) iterator_issued_items_list.next();

            int item_id = (int) issued_items[0];
            String issued_date = String.valueOf((Date) issued_items[1]).split(" ")[0];
            String due_date = String.valueOf((Date) issued_items[2]).split(" ")[0];
            int quantity = (int) issued_items[3];

            List<Object> item_name_ = items_repository.get_Items(item_id);
            Iterator iterator = item_name_.iterator();
            Object[] names = (Object[]) iterator.next();

            String item_name = (String) names[0];
            String model = (String) names[1];

            issued_items_data.add(new Issued_Items_Data(item_name, model, quantity, issued_date, due_date));
        }

        int account_id = tbl_user_account_repository.get_Account_Id(user_id);
        float balance = tbl_account_repository.get_Balance(account_id);

        List<Account_Information> tbl_printer_usage_logs = new ArrayList<>();
        List<Object> account_information = tbl_printer_usage_log_repository.get_Account_Information(user_id);
        Iterator iterator_account_information = account_information.iterator();

        while (iterator_account_information.hasNext()){

            Object[] objects = (Object[]) iterator_account_information.next();

            String date = String.valueOf((Date) objects[0]).split(" ")[0];
            tbl_printer_usage_logs.add(new Account_Information(date, (int) objects[2], (float) objects[1]));
//            date, (int) objects[2]),
        }

        modelMap.put("balance" , balance);
        modelMap.put("account_information", tbl_printer_usage_logs);
        modelMap.put("issued_items", issued_items_data);

        return "ITSC";
    }

}
