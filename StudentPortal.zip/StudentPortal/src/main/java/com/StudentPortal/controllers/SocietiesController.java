package com.StudentPortal.controllers;

import com.StudentPortal.Data.CurrentJob;
import com.StudentPortal.Data.Jobs_Vaccancies;
import com.StudentPortal.model.moodleds.Applicants;
import com.StudentPortal.model.moodleds.MDL_Certificates_Requests;
import com.StudentPortal.repository.moodleds.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

/**
 * Created by abdul on 3/10/17.
 */

@Controller
@SessionAttributes(value = {"username", "name", "id"})
public class SocietiesController {

    @Autowired
    Working_HousrRepository working_housrRepository;

    @Autowired
    Working_Hour_History_Repository working_hour_history_repository;

    @Autowired
    Current_Status_Societies_Repository current_status_societies_repository;

    @Autowired
    MDL_Jobs_Repository jobsRepository;

    @Autowired
    Societies_Hours_Repositroy societies_hours_repositroy;

    @Autowired
    Societies_Hour_History_Repository societies_hour_history_repository;

    @Autowired
    MDL_Certificate_Request_Repository mdl_certificate_request_repository;

    @Autowired
    private Vaccancies_Repository vaccancies_repository;

    @Autowired
    private Applicants_Repository applicants_repository;

    @RequestMapping(value = "/societies")
    public String societies(ModelMap modelMap, HttpSession httpSession){

        String username = (String) httpSession.getAttribute("username");
        if(username == null){
            return "redirect:/";
        }

        /*********************************************
         * Getting current status of work Study Hour *
         ********************************************/
        //Get current working hour society
        List<Object> current_work_study_hour = current_status_societies_repository.get_Current_Work_Study_Record(username);
        Iterator iterator_current_work_study_hour = current_work_study_hour.iterator();
        Object[] object_current_work_study_hour = (Object[]) iterator_current_work_study_hour.next();
        int j_id = (int) object_current_work_study_hour[1];
        //Get all data from Working_Hour table form database...
        List<Object> working_hours_list = working_housrRepository.get_Working_hours_details(username, j_id);
        Iterator iterator_working_hour = working_hours_list.iterator();

        //Create a list for storing the record of work study hour.
        CurrentJob work_study_hour_job = null;

        if (iterator_working_hour.hasNext()){

            Object[] objects = (Object[]) iterator_working_hour.next();
            //Get job nature.

            String job_nature = jobsRepository.get_Job_Nature(j_id);
            //Make an object of job
            String joining_date = String.valueOf((Date) object_current_work_study_hour[0]).split(" ")[0];
            work_study_hour_job = new CurrentJob(j_id, "Work Study", job_nature, joining_date, null, true);

            //Get the starting date and ending date oe work
            Date start_date = (Date) objects[0];
            Date end_date = (Date) objects[1];
            //Insert a record into the array list in class currentjob
            work_study_hour_job.addRow(String.valueOf(start_date).split(" ")[0], String.valueOf(end_date).split(" ")[0], (int) objects[2], (int) objects[3], (boolean) objects[4]);

            while (iterator_working_hour.hasNext()){

                objects = (Object[]) iterator_working_hour.next();
                //Get the starting date and ending date oe work
                start_date = (Date) objects[2];
                end_date = (Date) objects[3];
                //Insert a record into the array list in class currentjob
                work_study_hour_job.addRow(String.valueOf(start_date).split(" ")[0], String.valueOf(end_date).split(" ")[0], (int) objects[4], (int) objects[5], (boolean) objects[6]);

            }
        }

        if(work_study_hour_job == null)
            work_study_hour_job = new CurrentJob(0, "No-Member", "Not Joined", null, null, false);

        /*********************************************
         * Getting history of work Study Hour        *
         ********************************************/
        //Get history of work Study Hour
        List<CurrentJob> work_study_hour_history = new ArrayList<>();
        List<Object> past_work_study_hour = current_status_societies_repository.get_Past_Work_Study_Record(username);
        Iterator iterator_past_work_study_hour = past_work_study_hour.iterator();

        //User could have worked in many departments therefore there could be more then one record
        while (iterator_past_work_study_hour.hasNext()){

            Object[] object_past_work_study_hour = (Object[]) iterator_past_work_study_hour.next();
            int pastj_id = (int) object_past_work_study_hour[2];
            String joining_date = String.valueOf((Date) object_past_work_study_hour[0]).split(" ")[0];
            String leaving_date = String.valueOf((Date) object_past_work_study_hour[1]).split(" ")[0];


            //Get the post and the nature of society and make it a job
            List<Object> job_title_nature = jobsRepository.get_Title_Nature(pastj_id);
            Iterator iterator_job_title_nature = job_title_nature.iterator();
            Object[] obj = (Object[]) iterator_job_title_nature.next();

            String title = (String) obj[0];
            String nature = (String) obj[1];
            CurrentJob currentJob = new CurrentJob(pastj_id, title, nature, joining_date, leaving_date, false);

            List<Object> past_work_study_data = working_hour_history_repository.get_Working_hours_details(username, pastj_id);
            Iterator iterator_past_work_study_data = past_work_study_data.iterator();

            //Insert all the record of the job
            while (iterator_past_work_study_data.hasNext()){

                Object[] past_work_study_hour_objects = (Object[]) iterator_past_work_study_data.next();
                currentJob.addRow(String.valueOf((Date) past_work_study_hour_objects[0]).split(" ")[0],
                        String.valueOf((Date) past_work_study_hour_objects[1]).split(" ")[0], (int) past_work_study_hour_objects[2],
                        (int) past_work_study_hour_objects[3], (boolean) past_work_study_hour_objects[4]);
            }
            work_study_hour_history.add(currentJob);
        }


        /*********************************************
         * Getting Current status of Societies Hour        *
         ********************************************/
        //Get the data of societies that he has joined
        ArrayList<CurrentJob> societies_current_Jobs = new ArrayList<>();
        //Get all the joining datea and j_id's  in which he is working
        List<Object> societies_current_data = current_status_societies_repository.get_Current_Societies_Record(username);
        Iterator iterator = societies_current_data.iterator();

        while (iterator.hasNext()){

            //Getting first job data
            Object[] objects = (Object[]) iterator.next();
            String joining_date = String.valueOf((Date) objects[0]).split(" ")[0];
            j_id = (int) objects[1];

            //Get the post and the nature of society and make it a job
            List<Object> job_title_nature = jobsRepository.get_Title_Nature(j_id);
            Iterator iterator_job_title_nature = job_title_nature.iterator();
            Object[] obj = (Object[]) iterator_job_title_nature.next();

            String title = (String) obj[0];
            String nature = (String) obj[1];
            CurrentJob currentJob = new CurrentJob(j_id, title, nature, joining_date, null, true);

            List<Object> current_society_data = societies_hours_repositroy.get_Current_Societies_hours(username, j_id);
            Iterator iterator_current_society_data = current_society_data.iterator();

            //Insert all the record of the job
            while (iterator_current_society_data.hasNext()){

                Object[] current_society_data_objects = (Object[]) iterator_current_society_data.next();
                currentJob.addRow(String.valueOf((Date) current_society_data_objects[0]).split(" ")[0],
                        String.valueOf((Date) current_society_data_objects[1]).split(" ")[0], (int) current_society_data_objects[2], 0, false);
            }

            societies_current_Jobs.add(currentJob);

        }

        /*********************************************
         * Getting history of work Study Hour        *
         ********************************************/
        //Get the data of societies that he has joined
        ArrayList<CurrentJob> societies_history_Jobs = new ArrayList<>();
        //Get all the joining datea and j_id's  in which he is working
        List<Object> societies_history_data = current_status_societies_repository.get_Past_Societies_Record(username);
        Iterator iterator_societies_history_data = societies_history_data.iterator();

        while (iterator_societies_history_data.hasNext()){

            //Getting first job data
            Object[] objects = (Object[]) iterator_societies_history_data.next();
            String joining_date = String.valueOf((Date) objects[0]).split(" ")[0];
            String leaving_date = String.valueOf((Date) objects[1]).split(" ")[0];
            int past_j_id = (int) objects[2];

            //Get the post and the nature of society and make it a job
            List<Object> job_title_nature = jobsRepository.get_Title_Nature(past_j_id);
            Iterator iterator_job_title_nature = job_title_nature.iterator();
            Object[] obj = (Object[]) iterator_job_title_nature.next();

            String title = (String) obj[0];
            String nature = (String) obj[1];
            CurrentJob currentJob = new CurrentJob(past_j_id, title, nature, joining_date, leaving_date, false);

            List<Object> past_society_data = societies_hour_history_repository.get_Past_Societies_hours(username, past_j_id);
            Iterator iterator_past_society_data = past_society_data.iterator();

            //Insert all the record of the job
            while (iterator_past_society_data.hasNext()){

                Object[] past_society_data_objects = (Object[]) iterator_past_society_data.next();
                currentJob.addRow(String.valueOf((Date) past_society_data_objects[0]).split(" ")[0],
                        String.valueOf((Date) past_society_data_objects[1]).split(" ")[0], (int) past_society_data_objects[2], 0, false);
            }
            societies_history_Jobs.add(currentJob);
        }


        /*********************************************
         * Getting Current data of NIST              *
         ********************************************/

        //Get the data of NIST that he has joined
        ArrayList<CurrentJob> NIST_current_Jobs = new ArrayList<>();
        //Get all the joining datea and j_id's  in which he is working
        List<Object> NIST_current_data = current_status_societies_repository.get_Current_NIST_Record(username);
        Iterator iterator_NIST = NIST_current_data.iterator();

        while (iterator_NIST.hasNext()){

            //Getting first job data
            Object[] objects = (Object[]) iterator_NIST.next();
            String joining_date = String.valueOf((Date) objects[0]).split(" ")[0];
            j_id = (int) objects[1];

            //Get the post and the nature of society and make it a job
            List<Object> job_title_nature = jobsRepository.get_Title_Nature(j_id);
            Iterator iterator_job_title_nature = job_title_nature.iterator();
            Object[] obj = (Object[]) iterator_job_title_nature.next();

            String title = (String) obj[0];
            String nature = (String) obj[1];
            CurrentJob currentJob = new CurrentJob(j_id, title, nature, joining_date, null, true);

            List<Object> current_society_data = societies_hours_repositroy.get_Current_Societies_hours(username, j_id);
            Iterator iterator_current_society_data = current_society_data.iterator();

            //Insert all the record of the job
            while (iterator_current_society_data.hasNext()){

                Object[] current_society_data_objects = (Object[]) iterator_current_society_data.next();
                currentJob.addRow(String.valueOf((Date) current_society_data_objects[0]).split(" ")[0],
                        String.valueOf((Date) current_society_data_objects[1]).split(" ")[0], (int) current_society_data_objects[2], 0, false);
            }

            NIST_current_Jobs.add(currentJob);

        }

        /*********************************************
         * Getting history data of NIST              *
         ********************************************/
        //Get the data of NIST that he has joined
        ArrayList<CurrentJob> NIST_past_Jobs = new ArrayList<>();
        //Get all the joining datea and j_id's  in which he is working
        List<Object> NIST_past_data = current_status_societies_repository.get_Past_NIST_Record(username);
        Iterator iterator_NIST_past_data = NIST_past_data.iterator();

        while (iterator_NIST_past_data.hasNext()){

            //Getting first job data
            Object[] objects = (Object[]) iterator_NIST_past_data.next();
            String joining_date = String.valueOf((Date) objects[0]).split(" ")[0];
            String leaving_date = String.valueOf((Date) objects[1]).split(" ")[0];
            int past_j_id = (int) objects[2];

            //Get the post and the nature of society and make it a job
            List<Object> job_title_nature = jobsRepository.get_Title_Nature(past_j_id);
            Iterator iterator_job_title_nature = job_title_nature.iterator();
            Object[] obj = (Object[]) iterator_job_title_nature.next();

            String title = (String) obj[0];
            String nature = (String) obj[1];
            CurrentJob currentJob = new CurrentJob(past_j_id, title, nature, joining_date, leaving_date, true);

            List<Object> past_society_data = societies_hour_history_repository.get_Past_Societies_hours(username, past_j_id);
            Iterator iterator_past_society_data = past_society_data.iterator();

            //Insert all the record of the job
            while (iterator_past_society_data.hasNext()){

                Object[] current_society_data_objects = (Object[]) iterator_past_society_data.next();
                currentJob.addRow(String.valueOf((Date) current_society_data_objects[0]).split(" ")[0],
                        String.valueOf((Date) current_society_data_objects[1]).split(" ")[0], (int) current_society_data_objects[2], 0, false);
            }

            NIST_past_Jobs.add(currentJob);


        }

        /********************************************
        * Get the societies posts that are available*
        ********************************************/
        List<Jobs_Vaccancies> societies_vaccancies = new ArrayList<>();
        List<Jobs_Vaccancies> NIST_vaccancies = new ArrayList<>();
        List<Jobs_Vaccancies> work_study_vaccancies = new ArrayList<>();
        {
            List<Object> vaccancies_list = vaccancies_repository.get_vaccancies();
            Iterator iterator_vaccancies_list = vaccancies_list.iterator();

            while (iterator_vaccancies_list.hasNext()){

                Object[] vaccancies_details = (Object[]) iterator_vaccancies_list.next();
                int job_id = (int) vaccancies_details[0];
                String date = String.valueOf((Date) vaccancies_details[1]).split(" ")[0];
                String due_date = String.valueOf((Date) vaccancies_details[2]).split(" ")[0];

                //Get the society of job in whihc category it lie.
                String society = jobsRepository.get_society(job_id);

                //Get the post and the nature of society
                List<Object> job_title_nature = jobsRepository.get_Title_Nature(job_id);
                Iterator iterator_job_title_nature = job_title_nature.iterator();
                Object[] obj = (Object[]) iterator_job_title_nature.next();

                String title = (String) obj[0];
                String nature = (String) obj[1];
                if(society.equals("Society")) {
                    societies_vaccancies.add(new Jobs_Vaccancies(job_id, nature, title, date, due_date));
                }else if(society.equals("NIST")){
                    NIST_vaccancies.add(new Jobs_Vaccancies(job_id, nature, title, date, due_date));
                }else if(society.equals("Work Study")){
                    work_study_vaccancies.add(new Jobs_Vaccancies(job_id, nature, title, date, due_date));
                }
            }
        }


        //Map the current data of each society
        modelMap.put("work_study", work_study_hour_job);//map it in .html file and check the null conditions.....
        modelMap.put("current_job", societies_current_Jobs);
        modelMap.put("NIST_current_job", NIST_current_Jobs);

        //Map the history of each society
        modelMap.put("past_work_study_hour", work_study_hour_history);
        modelMap.put("societies_history_jobs", societies_history_Jobs);
        modelMap.put("NIST_past_Jobs", NIST_past_Jobs);

        //map the available post for each society
        modelMap.put("societies_vaccancies", societies_vaccancies);
        modelMap.put("NIST_vaccancies", NIST_vaccancies);
        modelMap.put("work_study_vaccancies", work_study_vaccancies);

        return "Socities";
    }

    @RequestMapping (value = "/issue_certificate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody String handle_Certificates_Requests(HttpSession httpSession, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws IOException{

        int j_id = Integer.valueOf(httpServletRequest.getParameter("society_id"));
//        String username = (String) httpSession.getAttribute("username");
//        if(username == null){
//            return "redirect:/";
//        }
        String username = "14031220";
        Object check_request = mdl_certificate_request_repository.check_Request(username, j_id);
        System.out.println("Returned Object is: " + check_request);

        //Check if the user has already requested for that certificate. If the object is null it means no request is placed
        if(check_request == null){
            Date current_date = new Date();
            mdl_certificate_request_repository.save(new MDL_Certificates_Requests(username, current_date, null, j_id, false));
            httpServletResponse.getWriter().println("Your request has been successfuly submitted");
        }else{
            httpServletResponse.getWriter().println("You have already placed a request");
        }
        httpServletResponse.flushBuffer();

        return null;
    }

    @RequestMapping (value = "/apply_request", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody String handle_Apply_Request(HttpSession httpSession, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws IOException{

        int v_id = Integer.valueOf(httpServletRequest.getParameter("v_id"));
//        String username = (String) httpSession.getAttribute("username");
//        if(username == null){
//            return "redirect:/";
//        }
        String username = "14031220";
        Object check_apply_request = applicants_repository.verify_Request(username, v_id);

        if(check_apply_request == null){
            Date date = new Date();
            applicants_repository.save(new Applicants(v_id, username, date));
            httpServletResponse.getWriter().println("You have applied for this job successfuly.");
        }else{
            httpServletResponse.getWriter().println("You have already applied for this job.");
        }

        httpServletResponse.flushBuffer();

        return null;

    }

    @RequestMapping (value = "/refuse_request", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody String handle_Refuse_Request(HttpSession httpSession, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws IOException{

        int v_id = Integer.valueOf(httpServletRequest.getParameter("v_id"));
//        String username = (String) httpSession.getAttribute("username");
//        if(username == null){
//            return "redirect:/";
//        }
        String username = "14031220";
        Object check_refuse_request = applicants_repository.verify_Request(username, v_id);

        if(check_refuse_request == null){
            httpServletResponse.getWriter().println("You haven't applied for this job yet.");
        }else{
            applicants_repository.remove_Request(username, v_id);
            httpServletResponse.getWriter().println("You application request has been successfuly removed.");
        }

        httpServletResponse.flushBuffer();

        return null;
    }
}
