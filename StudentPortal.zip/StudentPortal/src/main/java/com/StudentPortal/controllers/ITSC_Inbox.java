package com.StudentPortal.controllers;

import com.StudentPortal.Data.Messages_Data;
import com.StudentPortal.Data.Sender_Information;
import com.StudentPortal.model.moodleds.Attachments;
import com.StudentPortal.model.moodleds.Messages;
import com.StudentPortal.model.moodleds.Messages_Reply;
import com.StudentPortal.repository.moodleds.Attachments_Repository;
import com.StudentPortal.repository.moodleds.MDL_User_Repository;
import com.StudentPortal.repository.moodleds.Messages_Reply_Repository;
import com.StudentPortal.repository.moodleds.Messages_Repository;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.*;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by abdul on 4/30/17.
 */

@Controller
@SessionAttributes(value = {"itsc", "name", "id"})
public class ITSC_Inbox {

    @Autowired
    MDL_User_Repository mdl_user_repository;

    @Autowired
    Messages_Repository messages_repository;

    @Autowired
    Messages_Reply_Repository messages_reply_repository;

    @Autowired
    Attachments_Repository attachments_repository;

    @RequestMapping(value = "/message/itsc/{thread_id}")
    public String read_Message_ITSC(@PathVariable int thread_id, ModelMap modelMap, HttpSession httpSession){

        String username = (String) httpSession.getAttribute("itsc");
        if(username == null){
            return "redirect:/";
        }

        String email_id = (String) mdl_user_repository.get_Email_Id(username);

        messages_repository.change_Message_Status(true, thread_id);
        List<Object> message = messages_repository.get_Message(thread_id);
        Iterator iterator = message.iterator();

        Object[] objects = (Object[]) iterator.next();
        Messages_Data messages_data = new Messages_Data(thread_id, (String) objects[1], (String) objects[2], (String) objects[0], (String) objects[3]);
        messages_data.setFiles_Names(attachments_repository.get_Thread_Files_Names(thread_id));

        List<Object> all_replies = messages_reply_repository.get_Thread_Replies(thread_id);
        Iterator iterator1 = all_replies.iterator();
        List<Messages_Data> message_reply_data = new ArrayList<>();

        while (iterator1.hasNext()){

            Object[] obj = (Object[]) iterator1.next();
            Messages_Data messages_data1 = new Messages_Data(thread_id, (String) obj[2], (String) obj[3], (String) obj[1], (String) obj[4]);
            message_reply_data.add(messages_data1);

            messages_data1.setFiles_Names(attachments_repository.get_reply_Files_Names((int) obj[0]));
        }

        messages_reply_repository.update_Reply_Messages_Status(thread_id, email_id);
        modelMap.put("message_data", messages_data);
        modelMap.put("message_reply", message_reply_data);

        return "itsc_message_read";
    }

    @RequestMapping(value = "/send_reply/itsc/message/{username}/{thread_id}", method = RequestMethod.POST)
    public String upload_Files_Handler(@RequestParam("file") MultipartFile[] multipartFile, @RequestParam("text_area") String text, @PathVariable int thread_id, @PathVariable String username, ModelMap modelMap) throws ParseException {


        List<Object> information_for_reply = messages_repository.get_Information_For_Reply(thread_id);
        Iterator iterator = information_for_reply.iterator();
        Object[] objects = (Object[]) iterator.next();

        String receiver_email_id = (String) objects[0];
        String sender_email_id = (String) objects[1];
        String receiver_name = (String) objects[2];
        String sender_name = (String) objects[3];

        DateFormat df1 = new SimpleDateFormat("HH:mm");
        DateFormat df2 = new SimpleDateFormat("dd/MM/yy");
        Calendar calobj = Calendar.getInstance();

        String time = String .valueOf(df1.format(calobj.getTime()));
        Date date = df2.parse(String.valueOf(df2.format(calobj.getTime())));

        Messages_Reply messages_reply = new Messages_Reply(thread_id, sender_email_id, sender_name, receiver_name, receiver_email_id, date, time, text, false);
        messages_reply_repository.save(messages_reply);
        int message_reply_id = messages_reply.getReply_id();


        int totalFiles = multipartFile.length;
        if(totalFiles > 0){

            for(int i = 0; i < totalFiles; i++){

                MultipartFile file = multipartFile[i];
                try {
                    byte[] bytes = file.getBytes();
                    String file_Name = file.getOriginalFilename();

                    if(file_Name.length() > 0) {

                        String upload_File_Path = Paths.get("./Attachments/", username).toString();
                        File server_File = new File(upload_File_Path);
                        if(!server_File.exists()){
                            server_File.mkdir();
                        }

                        upload_File_Path = Paths.get("./Attachments/", username, file_Name).toString();
                        server_File = new File(upload_File_Path);

                        BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(server_File));
                        stream.write(bytes);
                        stream.close();

                        //Add the record for attachment in the database....
                        attachments_repository.save(new Attachments(0, message_reply_id, file_Name));
                    }

                }catch (Exception e){
                    e.printStackTrace();
                    return "Sorry!! Failed to reply please try again.";
                }

            }
        }

        {

//            messages_repository.change_Message_Status(true, thread_id);
            List<Object> message = messages_repository.get_Message(thread_id);
            Iterator iterator_message_repo = message.iterator();

            Object[] objects_message_repo = (Object[]) iterator_message_repo.next();
            Messages_Data messages_data = new Messages_Data(thread_id, (String) objects_message_repo[1], (String) objects_message_repo[2], (String) objects_message_repo[0], (String) objects_message_repo[3]);
            messages_data.setFiles_Names(attachments_repository.get_Thread_Files_Names(thread_id));

            List<Object> all_replies = messages_reply_repository.get_Thread_Replies(thread_id);
            Iterator iterator1 = all_replies.iterator();
            List<Messages_Data> message_reply_data = new ArrayList<>();

            while (iterator1.hasNext()){

                Object[] obj = (Object[]) iterator1.next();
                Messages_Data messages_data1 = new Messages_Data(thread_id, (String) obj[2], (String) obj[3], (String) obj[1], (String) obj[4]);
                message_reply_data.add(messages_data1);

                messages_data1.setFiles_Names(attachments_repository.get_reply_Files_Names((int) obj[0]));
            }

            modelMap.put("message_data", messages_data);
            modelMap.put("message_reply", message_reply_data);
        }
        return "itsc_message_read";
    }

//    @RequestMapping (value = "send_reply/itsc/message/downloadFile/{username}/{file_name}", method = RequestMethod.GET)
//    public void getFile1(@PathVariable String file_name, @PathVariable String username,  HttpServletResponse httpServletResponse){
//
//        try{
//            InputStream inputStream = new FileInputStream("/home/abdul/Documents/StudentPortal/Attachments/" + username + "/" + file_name + ".pdf");
//            IOUtils.copy(inputStream, httpServletResponse.getOutputStream());
//            httpServletResponse.flushBuffer();
//        }catch (IOException e){
//
//            e.printStackTrace();
//        }
//    }

//    @RequestMapping (value = "/message/downloadFile/{username}/{file_name}", method = RequestMethod.GET)
//    public void getFile2(@PathVariable String file_name, @PathVariable String username,  HttpServletResponse httpServletResponse){
//
//        try{
//
//            System.out.println("File name is: " + file_name);
//            InputStream inputStream = new FileInputStream("/home/abdul/Documents/StudentPortal/Attachments/" + username + "/" + file_name);
//            IOUtils.copy(inputStream, httpServletResponse.getOutputStream());
//            httpServletResponse.flushBuffer();
//        }catch (IOException e){
//
//            e.printStackTrace();
//        }
//    }

    @RequestMapping(value = "/itsc_inbox")
    public String itsc_inbox(ModelMap modelMap, HttpSession httpSession){

        String username = (String) httpSession.getAttribute("itsc");
        if(username == null){
            return "redirect:/";
        }

//        String username = "itsc";

        String email_id = (String) mdl_user_repository.get_Email_Id(username);
        List<Object> unread_Messages = messages_repository.get_Sender_Information(email_id, false);
        List<Object> read_Messages = messages_repository.get_Sender_Information(email_id, true);

        Iterator unread_messages_Iterator = unread_Messages.iterator();
        Iterator read_messages_Iterator = read_Messages.iterator();

        List<Sender_Information> unread_Messages_toMap = new ArrayList<>();
        List<Sender_Information> read_Messages_toMap = new ArrayList<>();

        while(unread_messages_Iterator.hasNext()){
            Object[] obj = (Object[]) unread_messages_Iterator.next();
            unread_Messages_toMap.add(new Sender_Information((int) obj[0], (String) obj[1], String.valueOf((Date) obj[2]).split(" ")[0], (String) obj[3]));
        }

        while(read_messages_Iterator.hasNext()){
            Object[] obj = (Object[]) read_messages_Iterator.next();

            int thread_id = (int) obj[0];
            Object[] reply_status = messages_reply_repository.get_Reply_Status(thread_id, email_id);
            if(reply_status.length > 0)
                unread_Messages_toMap.add(new Sender_Information((int) obj[0], (String) obj[1], String.valueOf((Date) obj[2]).split(" ")[0], (String) obj[3]));
            else
                read_Messages_toMap.add(new Sender_Information((int) obj[0], (String) obj[1], String.valueOf((Date) obj[2]).split(" ")[0], (String) obj[3]));
        }

        modelMap.put("unread_messages", unread_Messages_toMap);
        modelMap.put("read_messages", read_Messages_toMap);
        if(username.equals("itsc")) {
            return "itsc_inbox";
        }
        return "itsc_inbox";
    }

    @RequestMapping(value = "/itsc_send_message")
    public String home(@RequestParam("email") String receiver_email, @RequestParam("message") String message, ModelMap modelMap,
                       HttpSession httpSession){

        String username = (String) httpSession.getAttribute("itsc");
        if(username == null){
            return "redirect:/";
        }
//        String username = "faiqa";
        String sender_email_id = mdl_user_repository.get_Email_Id(username);
        Object[] objects = (Object[]) mdl_user_repository.get_Name(username).get(0);
        String sender_name = objects[0] + " " + objects[1];

        List<Object> objectList = mdl_user_repository.get_Name_By_Email(receiver_email);
        String receiver_name;
        if(objectList != null) {
            objects = (Object[])objectList.get(0);
            receiver_name = objects[0] + " " + objects[1];

        }else{
            return "redirect:/itsc_inbox";
        }

        java.util.Date utilDate = new java.util.Date();
        java.sql.Date date = new java.sql.Date(utilDate.getTime());
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        String time = calendar.HOUR + ":" + calendar.MINUTE;

        messages_repository.save(new Messages(sender_email_id, sender_name, receiver_name, receiver_email, date, time, message, false));
        return "redirect:/itsc_inbox";
    }


    @RequestMapping(value = "/sent_itsc_inbox")
    public String itsc_sent__inbox(ModelMap modelMap, HttpSession httpSession){

        String username = (String) httpSession.getAttribute("itsc");
        if(username == null){
            return "redirect:/";
        }

//        String username = "faiqa";

        String email_id = (String) mdl_user_repository.get_Email_Id(username);
        List<Object> sent_Messages = messages_repository.get_Receiver_Information(email_id);

        Iterator sent_messages_Iterator = sent_Messages.iterator();

        List<Sender_Information> sent_Messages_toMap = new ArrayList<>();

        while(sent_messages_Iterator.hasNext()){
            Object[] obj = (Object[]) sent_messages_Iterator.next();

            int thread_id = (int) obj[0];
            Object[] reply_status = messages_reply_repository.get_Sender_Reply_Status(thread_id, email_id);
            if(reply_status.length > 0)
                sent_Messages_toMap.add(new Sender_Information((int) obj[0], (String) obj[1], String.valueOf((Date) obj[2]).split(" ")[0], (String) obj[3]));
            else
                sent_Messages_toMap.add(new Sender_Information((int) obj[0], (String) obj[1], String.valueOf((Date) obj[2]).split(" ")[0], (String) obj[3]));
        }

        modelMap.put("sent_messages", sent_Messages_toMap);
        if(username.equals("itsc")){
            return "itsc_sent_inbox";
        }
//        modelMap.put("read_messages", read_Messages_toMap);
        return "itsc_sent_messages";
    }
}
