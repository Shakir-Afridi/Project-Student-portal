package com.StudentPortal.controllers;

import com.StudentPortal.Data.*;
import com.StudentPortal.model.moodleds.Societies_Hours;
import com.StudentPortal.model.moodleds.Vaccancies;
import com.StudentPortal.repository.moodleds.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.*;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by Shakir Afridi on 4/9/2017.
 */
@Controller
@SessionAttributes(value = {"fac_name", "name", "id"})
public class TeacherController {


    @Autowired
    MDL_User_Repository mdl_user_repository;

    @Autowired
    MDL_Course_Repository mdl_course_repository;

    @Autowired
    MDL_Jobs_Repository jobsRepository;

    @Autowired
    MDL_Grade_Categories_Repository mdl_grade_categories_repository;

    @Autowired
    MDL_Grade_Grades_Repository mdl_grade_grades_repository;

    @Autowired
    MDL_Grade_Categories_History_Repository mdl_grade_categories_history_repository;

    @Autowired
    MDL_Grade_Grades_History_Repository mdl_grade_grades_history_repository;

    @Autowired
    MDL_Attendance_Repository mdl_attendance_repository;

    @Autowired
    MDL_Attendance_Sessions_Repository mdl_attendance_sessions_repository;

    @Autowired
    MDL_Attendance_Statuses_Repository mdl_attendance_statuses_repository;

    @Autowired
    MDL_Attendance_Log_Repository mdl_attendance_log_repository;

    @Autowired
    Vaccancies_Repository vaccancies_repository;

    @Autowired
    Working_HousrRepository working_housrRepository;

    @Autowired
    Current_Status_Societies_Repository current_status_societies_repository;

    @Autowired
    Societies_Hours_Repositroy societies_hours_repositroy;

    @Autowired
    Societies_Body_History_Repository societies_body_history_repository;

    @Autowired
    private MDL_Jobs_Repository mdl_jobs_repository;



    @RequestMapping (value = "/teacher_home")
    public String teacherdata(ModelMap modelMap, HttpSession httpSession){// HttpSession httpSession){

        String username = (String) httpSession.getAttribute("fac_name");
        if(username == null){
            return "redirect:/";
        }

        // Getting society name
        List<Object> society_info = jobsRepository.find_society_name_by_patron(username);
        Object[] society_obj = (Object[]) society_info.get(0);
        String society = (String) society_obj[1];
        int society_id = (int) society_obj[0];

        // Getting teacher detail information
        List<Object> teacher_information_list = mdl_user_repository.get_teacher(username);
        Iterator iterator = teacher_information_list.iterator();
        Object[] teacher_information = (Object[]) iterator.next();

        Teachers_Information teachers_information = new Teachers_Information((String) teacher_information[0],(String) teacher_information[1],
                (String) teacher_information[2],(String) teacher_information[3],(String) teacher_information[4],(String) teacher_information[5],
                (String) teacher_information[6]);

        // Getting teacher modules
        List<Object> teacher_module_list = mdl_course_repository.get_teacher_modules(username);
        Iterator iterator4 = teacher_module_list.iterator();
        List<Teachers_Information> teacher_module = new ArrayList<>();
        while (iterator4.hasNext()){
            Object [] teacher_modules = (Object[])  iterator4.next();
            teacher_module.add(new Teachers_Information((String) teacher_modules[0],(int) teacher_modules[1]));
        }
        // Teacher modules end

        // Getting students enrolled in teacher module
        List<Object> courseId = mdl_user_repository.getStudents(username);
        Iterator iterator1 = courseId.iterator();
//        List<MDL_Course> courses_id = new ArrayList<>();
        List<Student_Information> students = new ArrayList<>();

        while (iterator1.hasNext()){
            Object[] student = (Object[]) iterator1.next();
            students.add(new Student_Information((String) student[0],(String) student[1],(String) student[2]));
        }


        // Getting pat students
        int count_students = 0;
        List<Object> pat_students_list = mdl_user_repository.get_students_as_pat(username);
        Iterator iterator2 = pat_students_list.iterator();
        List<Student_Information> pat_students = new ArrayList<>();
        while (iterator2.hasNext()) {
            count_students++;
            Object[] pat_student = (Object[]) iterator2.next();
            pat_students.add(new Student_Information((String) pat_student[0],(String) pat_student[1],(String) pat_student[2],(int) pat_student[3]));
        }// End



        // Getting fyp students
        int count = 0;
        List<Object> fyp_students_list = mdl_user_repository.get_students_as_fypsupervisor(username);
        Iterator iterator3 = fyp_students_list.iterator();
        List<Student_Information> fyp_students = new ArrayList<>();
        while (iterator3.hasNext()) {
            count++;
            Object[] fyp_student = (Object[]) iterator3.next();
//            count++;
            fyp_students.add(new Student_Information((String) fyp_student[0],(String) fyp_student[1],(String) fyp_student[2]));
        }// End

        modelMap.put("count_students",count_students);
        modelMap.put("fyp_students",fyp_students);
        modelMap.put("count",count);
        modelMap.put("pat_students",pat_students);
        modelMap.put("teacher_modules",teacher_module);
        modelMap.put("teacher_information",teachers_information);
        modelMap.put("society",society);
        modelMap.put("students",students);

        return "teacher_home";
    }

    @RequestMapping (value = "/TeacherSocieties")
    public String teachersocieties(ModelMap modelMap, HttpSession httpSession){


        String username = (String) httpSession.getAttribute("fac_name");
        if(username == null){
            return "redirect:/";
        }

        // Getting society name
        List<Object> society_info = jobsRepository.find_society_name_by_patron(username);
        Object[] society_obj = (Object[]) society_info.get(0);
        String society = (String) society_obj[1];
        int society_id = (int) society_obj[0];

        // Getting teacher name
        List<Object> teacher_information_list = mdl_user_repository.get_teacher(username);
        Iterator iterator = teacher_information_list.iterator();
        Object[] teacher_information = (Object[]) iterator.next();

        Teachers_Information teachers_information = new Teachers_Information((String) teacher_information[0],(String) teacher_information[1],
                (String) teacher_information[2],(String) teacher_information[3],(String) teacher_information[4],(String) teacher_information[5],
                (String) teacher_information[6]);


        // Getting president of the society
        List<Object> president1 = mdl_user_repository.get_societies_president(username);
        Iterator iterator4 = president1.iterator();
        Object[] teacher_societies = (Object[]) iterator4.next();
        String president = teacher_societies[0]+" "+teacher_societies[1];


        // Getting General Secratory of the society
        List<Object> GS1 = mdl_user_repository.get_societies_GS(username);
        Iterator iterator5 = GS1.iterator();
        Object[] teacher_societies1 = (Object[]) iterator5.next();
        String GS = teacher_societies1[0]+" "+teacher_societies1[1];

        // Getting Finance Manager of the society
        List<Object> FM1 = mdl_user_repository.get_societies_FM(username);
        Iterator iterator6 = FM1.iterator();
        Object[] teacher_societies2 = (Object[]) iterator6.next();
        String FM = teacher_societies2[0]+" "+teacher_societies2[1];

        // Getting Marketing Manager of the society
        List<Object> MM1 = mdl_user_repository.get_societies_MM(username);
        Iterator iterator7 = MM1.iterator();
        Object[] teacher_societies3 = (Object[]) iterator7.next();
        String MM = teacher_societies3[0]+" "+teacher_societies3[1];

        // Getting Event managers of the society
        int count = 0;
        List<Object> event_managers = mdl_user_repository.get_societies_EM(username);
        Iterator iterable8 = event_managers.iterator();
        List<Student_Information> EM = new ArrayList<>();
        while (iterable8.hasNext()){
            count++;
            Object[] event_m = (Object[]) iterable8.next();
            EM.add(new Student_Information((String) event_m[0],(String) event_m[1],(String) event_m[2],(int) event_m[3]));
        }

        // Getting members of the society
        int count1 = 0;
        List<Object> members = mdl_user_repository.get_societies_M(username);
        Iterator iterator9 = members.iterator();
        List<Student_Information> member = new ArrayList<>();
        while (iterator9.hasNext()){
            count1++;
            Object[] membrs = (Object[]) iterator9.next();
            member.add(new Student_Information((String) membrs[0],(String) membrs[1],(String) membrs[2],(int) membrs[3]));
        }


        //get societies body history
        List<Societies_Body_History_Data> societies_body_history_data = new ArrayList<>();
        List<Object> societies_body_history = societies_body_history_repository.get_History(username);
        iterator = societies_body_history.iterator();

        while (iterator.hasNext()){

            Object[] objects = (Object[]) iterator.next();
            int j_id = (int) objects[0];
            String roll_no = (String) objects[1];

            List<Object> joining_leaving_date = current_status_societies_repository.get_Joining_Leaving_Date(roll_no, j_id);
            Object[] objects1 = (Object[]) joining_leaving_date.get(0);
            String joining_date = String.valueOf((Date) objects1[0]).split(" ")[0];
            String leaving_date = String.valueOf((Date) objects1[1]).split(" ")[0];

            List<Object> first_last_names = mdl_user_repository.get_Name(roll_no);
            Object[] objects2 = (Object[]) first_last_names.get(0);
            String name = (String) objects2[0];
            name += (String) objects2[1];

            String status = mdl_jobs_repository.get_Title(j_id);

            societies_body_history_data.add(new Societies_Body_History_Data(name, roll_no, status, joining_date, leaving_date));

        }


        modelMap.put("societies_body_history_data", societies_body_history_data);
        modelMap.put("society_id", society_id);
        modelMap.put("GS",GS);
        modelMap.put("FM",FM);
        modelMap.put("MM",MM);
        modelMap.put("president",president);
        modelMap.put("EM",EM);
        modelMap.put("count",count);
        modelMap.put("member",member);
        modelMap.put("count1",count1);
        modelMap.put("teacher_information",teachers_information);
        modelMap.put("society",society);

        return "TeacherSocieties";
    }

    String rollno = null;
    String studentname = null;

    @RequestMapping(value = "/student_detail/{rollno}")
    public String get_Student_Performance(@PathVariable String rollno, ModelMap modelMap, HttpSession httpSession){

        String username = (String) httpSession.getAttribute("fac_name");
        if(username == null){
            return "redirect:/";
        }

        this.rollno = rollno;
        if(rollno == null){
            return "redirect:/";
        }

        Object[] names = (Object[]) mdl_user_repository.get_Name(rollno).iterator().next();
        studentname = names[0] + " " + names[1];
        return "redirect:/student_attendance";
    }

    @RequestMapping(value = "/student_performance", method = RequestMethod.GET)
    public String student_performance(ModelMap modelMap, HttpSession httpSession){

        String username = (String) httpSession.getAttribute("fac_name");
        if(username == null){
            return "redirect:/";
        }

        if(rollno == null){
            return "redirect:/";
        }

        int student_id = mdl_user_repository.get_user_id(rollno);
        int current_year = mdl_user_repository.find_year(student_id);

        List<Ranking> rankings = new ArrayList<>();
        List<List<Year_Result>> all_years_results = new ArrayList<>();

        for(int year = current_year; year >= 1; year--) {

            List<Year_Result> year_results = new ArrayList<>();
            List<Object> list_courses = mdl_course_repository.getEnrolledCourses(student_id, year);
            Iterator iterator = list_courses.iterator();

            while (iterator.hasNext()) {

                Object[] courses_information = (Object[]) iterator.next();

                //Fetch all information of enrolled courses
                int course_id = (int) courses_information[0];
                String title = (String) courses_information[1];
                int credit_hour = (int) courses_information[2];

                List<Obtained_Marks> obtained_marks_detail = new ArrayList<>();
                List<Object> assessments = null;
                if(year == current_year) {
                    assessments = mdl_grade_categories_repository.get_module_assessments(course_id);
                }else {
                    assessments = mdl_grade_categories_history_repository.get_module_assessments(course_id);
                }
                Iterator assessment_iterator = assessments.iterator();

                double total_weightage = 0;
                double total_obtained_marks = 0;

                while (assessment_iterator.hasNext()) {

                    Object[] assessments_information = (Object[]) assessment_iterator.next();
                    int assessment_id = (int) assessments_information[0];
                    String assessment_type = (String) assessments_information[1];
                    double weightage = (int) assessments_information[2];
                    total_weightage += weightage;
                    double obtained_marks = 0;
                    if(year == current_year) {
                        obtained_marks = mdl_grade_grades_repository.assessment_grades(assessment_id, student_id);
                    }else{
                        obtained_marks = mdl_grade_grades_history_repository.assessment_grades(assessment_id, student_id);

                    }
                    total_obtained_marks += obtained_marks;

                    boolean status = true;
                    if (((obtained_marks / weightage) * 100) < 33) {
                        status = false;
                    }
                    obtained_marks_detail.add(new Obtained_Marks(assessment_type, weightage, obtained_marks, status, assessment_id, year));
                }

                boolean status = true;

                if (((total_obtained_marks / total_weightage) * 100) < 33) {
                    status = false;
                }

                Year_Result year_result = new Year_Result(title, total_weightage, total_obtained_marks, credit_hour, status, obtained_marks_detail, year);
                year_results.add(year_result);
            }

            all_years_results.add(year_results);
            rankings.add(find_ranking(student_id, year, current_year));
        }

        modelMap.put("studentname", studentname);
        modelMap.put("rankings", rankings);
        modelMap.put("courses_data", all_years_results);
//        username = null;

        return "mystudent_performance";
    }



    @RequestMapping(value = "/student_attendance")
    public String student_Attendance(ModelMap modelMap, HttpSession httpSession){

        String username = (String) httpSession.getAttribute("fac_name");
        if(username == null){
            return "redirect:/";
        }

        if(rollno == null){
            return "redirect:/";
        }
        int user_id = mdl_user_repository.get_user_id(rollno);

        int current_year = mdl_user_repository.find_year(user_id);
        List<Module> year1 = new ArrayList<>();
        List<Module> year2 = new ArrayList<>();
        List<Module> year3 = new ArrayList<>();
        List<Module> year4 = new ArrayList<>();


        for (int i = 1; i <= current_year; i++) {

            List<Object> all_Courses_Enrolled = mdl_course_repository.get_CourseOffering_By_Year(i, user_id);
            Iterator iterator = all_Courses_Enrolled.iterator();

            while (iterator.hasNext()) {

                Object[] objects = (Object[]) iterator.next();
                int course_id = (int) objects[0];
                String title = (String) objects[1];
                String short_name = (String) objects[2];
                int attendance_id = mdl_attendance_repository.get_attendance_id(course_id);

                int present_status_id = mdl_attendance_statuses_repository.get_present_status_id(attendance_id);
                int absent_status_id = mdl_attendance_statuses_repository.get_absent_status_id(attendance_id);

                int count_of_presents = mdl_attendance_log_repository.count_Present(user_id, attendance_id, present_status_id);
                int count_of_absents = mdl_attendance_log_repository.count_Present(user_id, attendance_id, absent_status_id);
                int total_sessions = mdl_attendance_sessions_repository.count_sessions(attendance_id);

                double attendance_Percentage = count_of_presents / (double) total_sessions * 100;

                if(i == 1) {
                    if ((title).contains("(Semester-1)")) {
                        year1.add(new Module(short_name + " (S1)", attendance_Percentage, 1, null));
                    } else if ((title).contains("(Semester-2)")) {
                        year1.add(new Module(short_name + " (S2)", attendance_Percentage, 2, null));
                    }
                }

                if(i == 2) {
                    if ((title).contains("(Semester-1)")) {
                        year2.add(new Module(short_name + " (S1)", attendance_Percentage, 1, null));
                    } else if ((title).contains("(Semester-2)")) {
                        year2.add(new Module(short_name + " (S2)", attendance_Percentage, 2, null));
                    }
                }

                if(i == 3) {
                    if ((title).contains("(Semester-1)")) {
                        year3.add(new Module(short_name + " (S1)", attendance_Percentage, 1, null));
                    } else if ((title).contains("(Semester-2)")) {
                        year3.add(new Module(short_name + " (S2)", attendance_Percentage, 2, null));
                    }
                }

                if(i == 4) {
                    if ((title).contains("(Semester-1)")) {
                        year4.add(new Module(short_name + " (S1)", attendance_Percentage, 1, null));
                    } else if ((title).contains("(Semester-2)")) {
                        year4.add(new Module(short_name + " (S2)", attendance_Percentage, 2, null));
                    }
                }
            }
        }
        if(current_year == 1) {
            modelMap.put("current_year", current_year);
            modelMap.put("current_year_module", year1);
        }

        if(current_year == 2) {
            modelMap.put("current_year", current_year);
            modelMap.put("current_year_module", year2);
            modelMap.put("past_year1", year1);
        }

        if(current_year == 3) {
            modelMap.put("current_year", current_year);
            modelMap.put("current_year_module", year3);
            modelMap.put("past_year1", year1);
            modelMap.put("past_year2", year2);
        }

        if(current_year == 4) {
            modelMap.put("current_year", current_year);
            modelMap.put("current_year_module", year4);
            modelMap.put("past_year1", year1);
            modelMap.put("past_year2", year2);
            modelMap.put("past_year3", year3);
        }

        modelMap.put("studentname", studentname);
        return "mystudent_attendance";
    }


    @RequestMapping(value = "/student_societies")
    public String student_Societies(ModelMap modelMap, HttpSession httpSession){

        /*********************************************
         * Getting current status of work Study Hour *
         ********************************************/
        //Get current working hour society

        String username = (String) httpSession.getAttribute("fac_name");
        if(username == null){
            return "redirect:/";
        }

        if(rollno == null){
            return "redirect:/";
        }
        List<Object> current_work_study_hour = current_status_societies_repository.get_Current_Work_Study_Record(rollno);
        Iterator iterator_current_work_study_hour = current_work_study_hour.iterator();
        Object[] object_current_work_study_hour = (Object[]) iterator_current_work_study_hour.next();
        int j_id = (int) object_current_work_study_hour[1];
        //Get all data from Working_Hour table form database...
        List<Object> working_hours_list = working_housrRepository.get_Working_hours_details(rollno, j_id);
        Iterator iterator_working_hour = working_hours_list.iterator();

        //Create a list for storing the record of work study hour.
        CurrentJob work_study_hour_job = null;

        if (iterator_working_hour.hasNext()){

            Object[] objects = (Object[]) iterator_working_hour.next();
            //Get job nature.

            String job_nature = jobsRepository.get_Job_Nature(j_id);
            //Make an object of job
            String joining_date = String.valueOf((Date) object_current_work_study_hour[0]).split(" ")[0];
            work_study_hour_job = new CurrentJob(j_id, "Work Study", job_nature, joining_date, null, true);

            //Get the starting date and ending date oe work
            Date start_date = (Date) objects[0];
            Date end_date = (Date) objects[1];
            //Insert a record into the array list in class currentjob
            work_study_hour_job.addRow(String.valueOf(start_date).split(" ")[0], String.valueOf(end_date).split(" ")[0], (int) objects[2], (int) objects[3], (boolean) objects[4]);

            while (iterator_working_hour.hasNext()){

                objects = (Object[]) iterator_working_hour.next();
                //Get the starting date and ending date oe work
                start_date = (Date) objects[2];
                end_date = (Date) objects[3];
                //Insert a record into the array list in class currentjob
                work_study_hour_job.addRow(String.valueOf(start_date).split(" ")[0], String.valueOf(end_date).split(" ")[0], (int) objects[4], (int) objects[5], (boolean) objects[6]);

            }
        }

        if(work_study_hour_job == null)
            work_study_hour_job = new CurrentJob(0, "No-Member", "Not Joined", null, null, false);


        /*********************************************
         * Getting Current status of Societies Hour        *
         ********************************************/
        //Get the data of societies that he has joined
        ArrayList<CurrentJob> societies_current_Jobs = new ArrayList<>();
        //Get all the joining datea and j_id's  in which he is working
        List<Object> societies_current_data = current_status_societies_repository.get_Current_Societies_Record(rollno);
        Iterator iterator = societies_current_data.iterator();

        while (iterator.hasNext()){

            //Getting first job data
            Object[] objects = (Object[]) iterator.next();
            String joining_date = String.valueOf((Date) objects[0]).split(" ")[0];
            j_id = (int) objects[1];

            //Get the post and the nature of society and make it a job
            List<Object> job_title_nature = jobsRepository.get_Title_Nature(j_id);
            Iterator iterator_job_title_nature = job_title_nature.iterator();
            Object[] obj = (Object[]) iterator_job_title_nature.next();

            String title = (String) obj[0];
            String nature = (String) obj[1];
            CurrentJob currentJob = new CurrentJob(j_id, title, nature, joining_date, null, true);

            List<Object> current_society_data = societies_hours_repositroy.get_Current_Societies_hours(rollno, j_id);
            Iterator iterator_current_society_data = current_society_data.iterator();

            //Insert all the record of the job
            while (iterator_current_society_data.hasNext()){

                Object[] current_society_data_objects = (Object[]) iterator_current_society_data.next();
                currentJob.addRow(String.valueOf((Date) current_society_data_objects[0]).split(" ")[0],
                        String.valueOf((Date) current_society_data_objects[1]).split(" ")[0], (int) current_society_data_objects[2], 0, false);
            }

            societies_current_Jobs.add(currentJob);

        }


        /*********************************************
         * Getting Current data of NIST              *
         ********************************************/

        //Get the data of NIST that he has joined
        ArrayList<CurrentJob> NIST_current_Jobs = new ArrayList<>();
        //Get all the joining datea and j_id's  in which he is working
        List<Object> NIST_current_data = current_status_societies_repository.get_Current_NIST_Record(rollno);
        Iterator iterator_NIST = NIST_current_data.iterator();

        while (iterator_NIST.hasNext()){

            //Getting first job data
            Object[] objects = (Object[]) iterator_NIST.next();
            String joining_date = String.valueOf((Date) objects[0]).split(" ")[0];
            j_id = (int) objects[1];

            //Get the post and the nature of society and make it a job
            List<Object> job_title_nature = jobsRepository.get_Title_Nature(j_id);
            Iterator iterator_job_title_nature = job_title_nature.iterator();
            Object[] obj = (Object[]) iterator_job_title_nature.next();

            String title = (String) obj[0];
            String nature = (String) obj[1];
            CurrentJob currentJob = new CurrentJob(j_id, title, nature, joining_date, null, true);

            List<Object> current_society_data = societies_hours_repositroy.get_Current_Societies_hours(rollno, j_id);
            Iterator iterator_current_society_data = current_society_data.iterator();

            //Insert all the record of the job
            while (iterator_current_society_data.hasNext()){

                Object[] current_society_data_objects = (Object[]) iterator_current_society_data.next();
                currentJob.addRow(String.valueOf((Date) current_society_data_objects[0]).split(" ")[0],
                        String.valueOf((Date) current_society_data_objects[1]).split(" ")[0], (int) current_society_data_objects[2], 0, false);
            }

            NIST_current_Jobs.add(currentJob);

        }

        //Map the current data of each society
        modelMap.put("studentname", studentname);
        modelMap.put("work_study", work_study_hour_job);//map it in .html file and check the null conditions.....
        modelMap.put("current_job", societies_current_Jobs);
        modelMap.put("NIST_current_job", NIST_current_Jobs);

        return "mystudent_societies";
    }


    public Ranking find_ranking(int student_id_, int year, int current_year) {


        List<Student> students = new ArrayList<>();
        //get students on the base of dept......
//        int current_year = mdl_user_repository.find_year(student_id_);
        List<Integer> list_students = mdl_user_repository.get_user_id(current_year);


        for(int student = 0; student < list_students.size(); student++) {
            //Needed to be looped
            int student_id = list_students.get(student);
            List<Object> list_courses_id = mdl_course_repository.getEnrolledCoursesId(student_id, year);
            Iterator iterator = list_courses_id.iterator();

            List<String> subjects_names = new ArrayList<>();
            List<Double> marks = new ArrayList<>();
//            List<Double> weitghtage = new ArrayList<>();

            while (iterator.hasNext()) {

                Object[] name_id = (Object[]) iterator.next();
                int course_id = (int) name_id[0];
                String name = (String) name_id[1];


                List<Object> assessments = null;
                if(year == current_year) {
                    assessments = mdl_grade_categories_repository.get_module_assessments_id(course_id);
                }else {
                    assessments = mdl_grade_categories_history_repository.get_module_assessments_id(course_id);
                }
                double total_obtained_marks = 0;
                double total_weightage = 0;

                Iterator assessment_iterator = assessments.iterator();
                while (assessment_iterator.hasNext()){

                    Object[] id_and_weightage = (Object[]) assessment_iterator.next();
                    int assessment_id = (int) id_and_weightage[0];
                    total_weightage += (int) id_and_weightage[1];

                    double obtained_marks = 0;
                    if(current_year == year) {
                        obtained_marks =  mdl_grade_grades_repository.assessment_grades(assessment_id, student_id);
                    }else{
                        obtained_marks = mdl_grade_grades_history_repository.assessment_grades(assessment_id, student_id);
                    }
                    total_obtained_marks += obtained_marks;
                }
                //Needed to divide total_obtained_marks with total weightage
                if(subjects_names.contains(name)){
                    int index = subjects_names.indexOf(name);
                    double first_marks = marks.get(index);
                    total_obtained_marks += first_marks;

//                    double first_weightage = weitghtage.get(index);
//                    total_weightage += first_weightage;
//
//                    total_obtained_marks /= total_weightage * 100;
//                    System.out.println("Total Marks are: " + total_obtained_marks);

//                    weitghtage.add(index, total_weightage);
                    marks.add(index, total_obtained_marks);
                }else {

//                    System.out.println("Total Marks are: " + total_obtained_marks);
                    subjects_names.add(name);
                    marks.add(total_obtained_marks);
//                    weitghtage.add(total_weightage);
                }
            }

            students.add(new Student(student_id, subjects_names, marks));
        }

        double highest_marks = 0; int index_highest_student_marks = 0;
        double lowest_marks = 0; int index_lowest_marks = 0;
        int index_your_marks = 0;

        List<Double> students_average_marks = new ArrayList<>();

        for(int i = 0; i < students.size(); i++){

            Student student = students.get(i);
            double total_marks = 0;
            for(int j = 0; j < student.getSubjects().size(); j++){
                total_marks += student.getMarks().get(j);

                if(i == 0) {
                    students_average_marks.add(student.getMarks().get(j));
                }else {
                    double average_marks1 = student.getMarks().get(j);
                    double avergae_marks2 = students_average_marks.get(j);
                    students_average_marks.add(j, (average_marks1+avergae_marks2));
                }
            }
//            student.setTotal_marks(total_marks);

            if(student.getId() == student_id_){
                index_your_marks = i;
            }

            if(i == 0){
                highest_marks = total_marks;
                index_highest_student_marks = i;
                lowest_marks = total_marks;
                index_lowest_marks = i;
            }

            if(total_marks > highest_marks){
                highest_marks = total_marks;
                index_highest_student_marks = i;
            }

            if(total_marks < lowest_marks){
                lowest_marks = total_marks;
                index_lowest_marks = i;
            }
        }

        int no_of_students = students.size();
        //Getting status of logged in student to find out his position according to every subject
        Student student = students.get(index_your_marks);
        int[] position_for_every_subject = new int[student.getSubjects().size()];
        //initialize array with zero.
        for(int i = 0; i < position_for_every_subject.length; i++){
            position_for_every_subject[i] = 1;
        }
        //finding out position according to every subject.
        for(int i = 0; i< no_of_students; i++){
            Student temp_student = students.get(i);
            for(int subject = 0; subject < student.getSubjects().size(); subject++){

                if(temp_student.getMarks().get(subject) > student.getMarks().get(subject)){
                    position_for_every_subject[subject]++;
                }
            }
        }

        for(int i = 0; i < students_average_marks.size(); i++){

            students_average_marks.set(i, students_average_marks.get(i)/no_of_students);
        }
        Student student_with_highest_marks = students.get(index_highest_student_marks);
        Student student_with_lowest_marks = students.get(index_lowest_marks);
        Student you = students.get(index_your_marks);

        Ranking ranking = new Ranking(year, you.getSubjects(), student_with_highest_marks.getMarks(),
                student_with_lowest_marks.getMarks(), you.getMarks(), students_average_marks, position_for_every_subject);
//        subjects = you.getSubjects();
//        highestmarks = student_with_highest_marks.getMarks();
//        lowestmarks = student_with_lowest_marks.getMarks();
//        avergaemarks = students_average_marks;
//        mymarks = you.getMarks();

        return ranking;
    }


    @RequestMapping (value = "/member_ship_call", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    void member_Ship_Call(HttpSession httpSession, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws IOException {

        String id_ = httpServletRequest.getParameter("id_");
        int j_id = 0;
        String due_date = null;

        try {
            if (id_.contains("president")) {

                j_id = Integer.valueOf(id_.substring(9));
                due_date = httpServletRequest.getParameter("due_date");

            } else if (id_.contains("general_secretary")) {

                j_id = Integer.valueOf(id_.substring(17));
                due_date = httpServletRequest.getParameter("due_date");

            } else if (id_.contains("finance_manager")) {

                j_id = Integer.valueOf(id_.substring(15));
                due_date = httpServletRequest.getParameter("due_date");

            } else if (id_.contains("marketing_manager")) {

                j_id = Integer.valueOf(id_.substring(17));
                due_date = httpServletRequest.getParameter("due_date");

            } else if (id_.contains("manager")) {

                j_id = Integer.valueOf(id_.substring(7));
                due_date = httpServletRequest.getParameter("due_date");

            } else if (id_.contains("member_ship")) {

                j_id = Integer.valueOf(id_.substring(11));
                due_date = httpServletRequest.getParameter("due_date");

            }
        }catch (Exception e){
            httpServletResponse.getWriter().println("Sorry, Try again");
            e.printStackTrace();
        }

        DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");
        java.util.Date utilDate = new java.util.Date();
        java.sql.Date date = new java.sql.Date(utilDate.getTime());

        try {

            Object object = vaccancies_repository.get_J_Id(j_id);
            if(object == null)
                vaccancies_repository.save(new Vaccancies(j_id, dateFormat.parse(due_date), date));
            else{
                httpServletResponse.getWriter().println("You have already opened this job");
                return;
            }

        }catch (ParseException exe){
            httpServletResponse.getWriter().println("Sorry, Try again");
            exe.printStackTrace();
        }

        httpServletResponse.getWriter().println("Mail send Successfuly");
    }

    @RequestMapping (value = "/remove_member_ship_call", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    void remove_Member_Ship_Call(HttpSession httpSession, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws IOException {

        String id_ = httpServletRequest.getParameter("id_");
        int j_id = 0;

        try {
            if (id_.contains("remove_president")) {
                j_id = Integer.valueOf(id_.substring(16));

            } else if (id_.contains("remove_general_secretary")) {
                j_id = Integer.valueOf(id_.substring(24));
            } else if (id_.contains("remove_finance_manager")) {
                j_id = Integer.valueOf(id_.substring(22));
            } else if (id_.contains("remove_marketing_manager")) {
                j_id = Integer.valueOf(id_.substring(24));
            } else if (id_.contains("remove_manager")) {
                j_id = Integer.valueOf(id_.substring(14));
            } else if (id_.contains("remove_member_ship")) {
                j_id = Integer.valueOf(id_.substring(18));
            }
        }catch (Exception e){
            httpServletResponse.getWriter().println("Sorry, Try again");
            e.printStackTrace();
        }
        vaccancies_repository.delete_Job_Vaccancy(j_id);
        httpServletResponse.getWriter().println("Job deleted Successfuly");
    }

    @Autowired
    private Societies_BodyRepository societies_bodyRepository;

//    @Autowired
//    private Societies_Hours societies_hours;

    @RequestMapping(value = "/Enter_hours")
    public String hours(ModelMap modelMap, HttpSession httpSession) {

        // Getting teacher name

        String username = (String) httpSession.getAttribute("fac_name");
        if(username == null){
            return "redirect:/";
        }

        List<Object> teacher_information_list = mdl_user_repository.get_teacher(username);
        Iterator iterator = teacher_information_list.iterator();
        Object[] teacher_information = (Object[]) iterator.next();

        Teachers_Information teachers_information = new Teachers_Information((String) teacher_information[0], (String) teacher_information[1],
                (String) teacher_information[2], (String) teacher_information[3], (String) teacher_information[4], (String) teacher_information[5],
                (String) teacher_information[6]);


        // Getting students info and total hours
        List<Object> societies_students = societies_bodyRepository.get_jid_uob_by_patron(username);
        Iterator iterator1 = societies_students.iterator();
        List<Object> student_info;
        List<Societies_Body_Data> studentsInfo = new ArrayList<>();
        while (iterator1.hasNext()) {
            Object[] uob_and_j_id = (Object[]) iterator1.next();
            int j_id = (int) uob_and_j_id[0];
//            System.out.println(j_id);

            String uob = (String) uob_and_j_id[1];
//            System.out.println(uob);

            String j_nature = jobsRepository.get_Job_Nature(j_id);
//            System.out.print("Nature " + j_nature + " and ");

            Object object = societies_hours_repositroy.get_hours(uob);
            long hours = 0;
            if(object != null){
                hours = (long) object;
            }

//            System.out.println("Hours are " + hours);

            // get student info against each uob
            student_info = mdl_user_repository.get_requested_students(uob);
            Iterator iterator2 = student_info.iterator();

            if (iterator2.hasNext()) {
                Object[] student_infos = (Object[]) iterator2.next();
                studentsInfo.add(new Societies_Body_Data((String) student_infos[0], (String) student_infos[1], (String) student_infos[2], (int) student_infos[3], (String) student_infos[4], j_nature, hours));
            }
        }

        modelMap.put("studentsInfo",studentsInfo);
        modelMap.put("teacher_information",teachers_information);
        return "Enter_hours";
    }

    // Adding students hours to the database
    @RequestMapping(value = "/Enter_hour/student_date", method = RequestMethod.POST)
    public String save_date(@RequestParam("roll_number") String roll_number, @RequestParam("from_date")String from_date,@RequestParam("to_date") String to_date,@RequestParam("nature") String nature, @RequestParam("hours") int hours ,ModelMap modelMap)  throws ParseException {

        int j_id = jobsRepository.get_j_id_by_j_nature(nature);

        DateFormat df = new SimpleDateFormat("yyyy-mm-dd");

        Date date1 = df.parse(from_date);
        Date date2 = df.parse(to_date);

        Societies_Hours societies_hours = new Societies_Hours(roll_number,j_id,date1,date2,hours);
        societies_hours_repositroy.save(societies_hours);

        return  "redirect:/Enter_hours";
    }
    @RequestMapping(value = "/Enter_hour/student_date_file", method = RequestMethod.POST)
    public String save_from_file_date(@RequestParam("file")MultipartFile[] multipartFile, ModelMap modelMap) throws Exception{

        int totalFiles = multipartFile.length;
        String file_Name = null;
        if(totalFiles > 0){

            for(int i = 0; i < totalFiles; i++){

                MultipartFile file = multipartFile[i];
                try {
                    byte[] bytes = file.getBytes();
                    file_Name = file.getOriginalFilename();

                    if(file_Name.length() > 0) {

                        String upload_File_Path = Paths.get("./HoursDataInFiles/").toString();
                        File server_File = new File(upload_File_Path);
                        if(!server_File.exists()){
                            server_File.mkdir();
                        }

                        upload_File_Path = Paths.get("./HoursDataInFiles/", file_Name).toString();
                        server_File = new File(upload_File_Path);

                        BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(server_File));
                        stream.write(bytes);
                        stream.close();
                    }

                }catch (Exception e){
                    e.printStackTrace();
                    return "Sorry!! Fail to upload file.";
                }

            }
        }
        BufferedReader br = null;
        String file1 = "./HoursDataInFiles/"+file_Name;
        String line = "";
        String SplitBy = ",";

        int j_id;
        int hours;
        Date date1;
        Date date2;

        try {
            br = new BufferedReader(new FileReader(file1));
            while ((line = br.readLine()) != null) {

                String[] data = line.split(SplitBy);
//                    System.out.println(data[0] +" "+ data[1]+" "+data[2]+" "+data[3]+" "+data[4]);

                j_id = Integer.parseInt(data[1]);
                System.out.println(j_id);

                hours = Integer.parseInt(data[4]);
                System.out.println(hours);

                DateFormat df = new SimpleDateFormat("dd/mm/yyyy");
                date1 = df.parse(data[2]);
                date2 = df.parse(data[3]);

                System.out.println(data[0]);


                Societies_Hours societies_hours = new Societies_Hours(data[0],j_id,date1,date2,hours);
                societies_hours_repositroy.save(societies_hours);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        return "redirect:/Enter_hours";
    }

}
