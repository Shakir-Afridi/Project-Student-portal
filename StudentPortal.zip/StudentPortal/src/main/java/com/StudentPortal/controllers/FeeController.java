package com.StudentPortal.controllers;

import com.StudentPortal.Data.FeeDetails;
import com.StudentPortal.model.moodleds.Fine;
import com.StudentPortal.model.moodleds.Installment;
import com.StudentPortal.repository.moodleds.FeeRepository;
import com.StudentPortal.repository.moodleds.FineRepository;
import com.StudentPortal.repository.moodleds.InstallementsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import javax.servlet.http.HttpSession;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

/**
 * Created by abdul on 3/10/17.
 */

@Controller
@SessionAttributes(value = {"username", "name", "id"})
public class FeeController {

    @Autowired
    FineRepository fineRepository;

    @Autowired
    InstallementsRepository installementsRepository;

    @Autowired
    FeeRepository feeRepository;

    //Handling Request for finance
    @RequestMapping(value = "/FeeStructure")
    public String feestructure(ModelMap modelMap, HttpSession httpSession){

        String username = (String) httpSession.getAttribute("username");
        if(username == null){
            return "redirect:/";
        }

        //getting fine details
        List<Object> fineArray = new ArrayList<>();
        List<Object> listFine = fineRepository.findByRollNumber(username);
        Iterator iterator1 = listFine.iterator();
        int total = 0;
        while (iterator1.hasNext()) {
            Object[] obj1 = (Object[]) iterator1.next();
            total = total + (int) obj1[5];
            Fine fine = new Fine((int) obj1[0], (String) obj1[1], (Date) obj1[2], (Date) obj1[3], (String) obj1[4], (int) obj1[5]);
            fineArray.add(fine);
        }
        modelMap.put("total", total);
        //      modelMap.put("student2",student2);

        modelMap.put("scholarship", 100);
        modelMap.put("payable", 0);
        modelMap.put("fineArray",fineArray);

        return "FeeStructure";
    }

    @RequestMapping(value = "/FeeDetails")
    public String fee_Details(ModelMap modelMap, HttpSession httpSession){


        String username = (String) httpSession.getAttribute("username");
        if(username == null){
            return "redirect:/";
        }


        //getting details of Fee installement details
        List<Object> feeinstallementArray = new ArrayList<Object>();
        List<Object> listFeeInstallement = installementsRepository.findByRollNumber(username);
        Iterator iterator1 = listFeeInstallement.iterator();

        while(iterator1.hasNext()) {
            Object[] obj1 = (Object[]) iterator1.next();
            if((int) obj1[0]==2) {
                FeeDetails firstinstallement = new FeeDetails((int) obj1[0], (String) obj1[1],  String.valueOf((Date) obj1[2]).split(" ")[0], String.valueOf((Date) obj1[3]).split(" ")[0], String.valueOf((Date) obj1[4]).split(" ")[0], (int) obj1[5], (String) obj1[6]);
                feeinstallementArray.add(firstinstallement);
            }
            else if((int) obj1[0]==3){
                FeeDetails sndinstallement = new FeeDetails((int) obj1[0], (String) obj1[1],  String.valueOf((Date) obj1[2]).split(" ")[0], String.valueOf((Date) obj1[3]).split(" ")[0], String.valueOf((Date) obj1[4]).split(" ")[0], (int) obj1[5], (String) obj1[6]);
                feeinstallementArray.add(sndinstallement);

            }
            else if((int) obj1[0]==4){
                FeeDetails thrdinstallement = new FeeDetails((int) obj1[0], (String) obj1[1],  String.valueOf((Date) obj1[2]).split(" ")[0], String.valueOf((Date) obj1[3]).split(" ")[0], String.valueOf((Date) obj1[4]).split(" ")[0], (int) obj1[5], (String) obj1[6]);
                feeinstallementArray.add(thrdinstallement);
            }
            else if((int) obj1[0]==5){
                FeeDetails frthinstallement = new FeeDetails((int) obj1[0], (String) obj1[1],  String.valueOf((Date) obj1[2]).split(" ")[0], String.valueOf((Date) obj1[3]).split(" ")[0], String.valueOf((Date) obj1[4]).split(" ")[0], (int) obj1[5], (String) obj1[6]);
                feeinstallementArray.add(frthinstallement);
            }
        }

        modelMap.put("feeinstallementArray",feeinstallementArray);
        return "FeeDetails";
    }
}
