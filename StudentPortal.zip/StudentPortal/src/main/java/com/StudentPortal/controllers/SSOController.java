package com.StudentPortal.controllers;

import com.StudentPortal.Data.Certificates_Requests;
import com.StudentPortal.repository.moodleds.MDL_Certificate_Request_Repository;
import com.StudentPortal.repository.moodleds.MDL_Jobs_Repository;
import com.StudentPortal.repository.moodleds.MDL_User_Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

/**
 * Created by Shakir Afridi on 4/22/2017.
 */
@Controller
@SessionAttributes(value = {"sso_name", "name", "id"})
public class SSOController {

    @Autowired
    MDL_User_Repository mdl_user_repository;

    @Autowired
    MDL_Jobs_Repository jobsRepository;

    @Autowired
    MDL_Certificate_Request_Repository mdl_certificates_requests_repository;

    @RequestMapping (value = "/sso_dashboard")
    public String SSO_Dashboard(ModelMap modelMap, HttpSession httpSession){

        String username = (String) httpSession.getAttribute("sso_name");
        if(username == null){
            return "redirect:/";
        }


        List<Object> request_certificates;
        String j_nature = null;
        List<Object> student_info = null;

        List<Certificates_Requests> student_infromation = new ArrayList<>();
        // get job id against each uob
        request_certificates = mdl_certificates_requests_repository.get_requested_j_id();
        Iterator iterator1_certificates = request_certificates.iterator();

        while (iterator1_certificates.hasNext()){
            // get job nature against job id
            Object[] objects_certificates = (Object[]) iterator1_certificates.next();
            int j_ids = (int) objects_certificates[0];
            j_nature = jobsRepository.get_job_for_requests(j_ids);
            System.out.println(j_nature);

            String request_date = String.valueOf(objects_certificates[1]).split(" ")[0];
            String student_uob = (String) objects_certificates[2];

            boolean status = (boolean) objects_certificates[3];
            String status_string = "Not Ready";
            if(status == true){
                status_string = "Ready";
            }

            // get student info against each uob
            student_info = mdl_user_repository.get_requested_students(student_uob);
            Iterator iterator1 = student_info.iterator();

            if(iterator1.hasNext()) {
                Object[] student_infos = (Object[]) iterator1.next();
                student_infromation.add(new Certificates_Requests(j_ids, (String) student_infos[0], (String) student_infos[1], (String) student_infos[2], (int) student_infos[3], (String) student_infos[4], j_nature, request_date, null, status_string));
            }
        }

        modelMap.put("student_information", student_infromation);
        return "SSO_Dashboard";
    }
    @RequestMapping(value = "/issued_certificates")
    public String ssoDate(ModelMap modelMap, HttpSession httpSession){

        String username = (String) httpSession.getAttribute("sso_name");
        if(username == null){
            return "redirect:/";
        }


        // Pending requests

        List<Object> request_certificates1;
        String j_nature1 = null;
        List<Object> student_info1 = null;

        List<Certificates_Requests> student_infromation1 = new ArrayList<>();
        // get job id against each uob
        request_certificates1 = mdl_certificates_requests_repository.get_issued_certificates_uob();
        Iterator iterator1_certificates1 = request_certificates1.iterator();

        while (iterator1_certificates1.hasNext()){
            // get job nature against job id
            Object[] objects_certificates1 = (Object[]) iterator1_certificates1.next();
            int j_ids1 = (int) objects_certificates1[0];
            j_nature1 = jobsRepository.get_job_for_requests(j_ids1);
            System.out.println(j_nature1);


            String request_date1 = String.valueOf(objects_certificates1[1]).split(" ")[0];
            String student_uob1 = (String) objects_certificates1[2];
            String recieved_date = String.valueOf(objects_certificates1[3]).split(" ")[0];

            // get student info against each uob
            student_info1 = mdl_user_repository.get_requested_students(student_uob1);
            Iterator iterator2 = student_info1.iterator();

            if(iterator2.hasNext()) {
                Object[] student_infos1 = (Object[]) iterator2.next();
                student_infromation1.add(new Certificates_Requests(j_ids1,(String) student_infos1[0], (String) student_infos1[1], (String) student_infos1[2], (int) student_infos1[3], (String) student_infos1[4], j_nature1, request_date1, recieved_date, null));
            }
        }


        modelMap.put("student_information1",student_infromation1);

        return "SSO";
    }

    @RequestMapping (value = "ready_certificate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public void certificate_Ready(HttpSession httpSession, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws IOException{

        String username = (String) httpSession.getAttribute("sso_name");
        if(username == null){
            return;
        }


        String certificate_id = (String) httpServletRequest.getParameter("certificate_id");

        String[] username_society = certificate_id.split(",");
        String text_ = (String) httpServletRequest.getParameter("text_");

        System.out.println(username_society[0] + "   " + username_society[1] + "     " + text_);

        try {
            if (text_.equals("READY")) {
                mdl_certificates_requests_repository.change_Status((String) username_society[0], Integer.parseInt(username_society[1]), true);
            } else if(text_.equals("NOT READY")){
                mdl_certificates_requests_repository.change_Status((String) username_society[0], Integer.parseInt(username_society[1]), false);
            }
        }catch (Exception e){
            httpServletResponse.getWriter().println("Try Again");
            httpServletResponse.flushBuffer();
            return;
        }
        httpServletResponse.getWriter().println("Done");
        httpServletResponse.flushBuffer();
    }

    @RequestMapping (value = "issue_certificate_clicked", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public void issue_certifiacte(HttpSession httpSession, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws IOException{

        String username = (String) httpSession.getAttribute("sso_name");
        if(username == null){
            return;
        }

        String certificate_id = (String) httpServletRequest.getParameter("certificate_id");

        String[] username_society = certificate_id.split(",");

        java.util.Date utilDate = new java.util.Date();
        java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());

        try {
                mdl_certificates_requests_repository.issue_certificate((String) username_society[0], Integer.parseInt(username_society[1]), sqlDate);
        }catch (Exception e){
            httpServletResponse.getWriter().println("Try Again");
            httpServletResponse.flushBuffer();
            return;
        }
        httpServletResponse.getWriter().println("Done");
        httpServletResponse.flushBuffer();
    }

}
