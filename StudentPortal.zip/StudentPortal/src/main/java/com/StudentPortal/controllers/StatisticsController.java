package com.StudentPortal.controllers;

import com.StudentPortal.Data.Student_Information;
import com.StudentPortal.Data.Teachers_Information;
import com.StudentPortal.repository.moodleds.MDL_Jobs_Repository;
import com.StudentPortal.repository.moodleds.MDL_User_Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.Iterator;
import java.util.List;

/**
 * Created by abdul on 3/10/17.
 */
@Controller
@SessionAttributes(value = {"username", "name", "id"})
public class StatisticsController {

    @Autowired
    MDL_User_Repository mdl_user_repository;

    @Autowired
    MDL_Jobs_Repository jobsRepository;


    @RequestMapping (value = "/statistics")
    public String statistics(ModelMap modelMap, HttpSession httpSession){

        Student_Information student_information1 = null;
        String username = (String) httpSession.getAttribute("username");
        if(username == null){
            return "redirect:/";
        }else{

            List<Object> student_information_list = mdl_user_repository.get_Student_Information(username);
            Iterator iterator = student_information_list.iterator();
            Object[] student_information = (Object[]) iterator.next();
            student_information1 = new Student_Information((String) student_information[0], (String) student_information[1], "BS",
                    (Integer) student_information[2], (Integer) student_information[3], (Integer) student_information[4], (Integer) student_information[5],
                    (Integer) student_information[6], (String) student_information[7], (String) student_information[8], (String) student_information[9], null, null);

            List<Object> teacher_information_list = mdl_user_repository.get_Teacher_Information(student_information1.getPat_id());
            iterator = teacher_information_list.iterator();
            Object[] teacher_information = (Object[]) iterator.next();
            Teachers_Information pat_information = new Teachers_Information(student_information1.getPat_id(), (String) teacher_information[0] + (String) teacher_information[1],
                    (String) teacher_information[2], (String) teacher_information[3], (String) teacher_information[4], (String) teacher_information[5],
                    (String) teacher_information[6]);

            if(student_information1.getPat_id() == student_information1.getFyp_supervisor_id()) {
                student_information1.setPat_information(pat_information);
                student_information1.setSupervisor_information(pat_information);
            }else{
                student_information1.setPat_information(pat_information);

                List<Object> teacher_information1_list = mdl_user_repository.get_Teacher_Information(student_information1.getPat_id());
                iterator = teacher_information1_list.iterator();
                Object[] teacher_information1 = (Object[]) iterator.next();
                Teachers_Information supervisor_information = new Teachers_Information(student_information1.getFyp_supervisor_id(), (String) teacher_information1[0] + (String) teacher_information1[1],
                        (String) teacher_information1[2], (String) teacher_information1[3], (String) teacher_information1[4], (String) teacher_information1[5],
                        (String) teacher_information1[6]);

                student_information1.setSupervisor_information(supervisor_information);
            }

        }

        modelMap.put("student_information", student_information1);
       return "Home";
    }
}
