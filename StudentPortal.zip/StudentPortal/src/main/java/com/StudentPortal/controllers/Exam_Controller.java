package com.StudentPortal.controllers;

import com.StudentPortal.Data.Obtained_Marks;
import com.StudentPortal.Data.Ranking;
import com.StudentPortal.Data.Student;
import com.StudentPortal.Data.Year_Result;
import com.StudentPortal.repository.moodleds.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Created by DEll1 on 3/14/2017.
 */

@Controller
@SessionAttributes(value = {"username", "name", "id"})
public class Exam_Controller {

    @Autowired
    MDL_Course_Repository mdl_course_repository;

    @Autowired
    MDL_Grade_Categories_Repository mdl_grade_categories_repository;

    @Autowired
    MDL_Grade_Grades_Repository mdl_grade_grades_repository;

    @Autowired
    MDL_User_Repository mdl_user_repository;

    @Autowired
    MDL_Grade_Categories_History_Repository mdl_grade_categories_history_repository;

    @Autowired
    MDL_Grade_Grades_History_Repository mdl_grade_grades_history_repository;


    @RequestMapping (value = "/Exam")
    public String examData(ModelMap modelMap, HttpSession httpSession){

        String username = (String) httpSession.getAttribute("username");
        if(username == null){
            return "redirect:/";
        }
        int student_id = (Integer) httpSession.getAttribute("id");
        int current_year = mdl_user_repository.find_year(student_id);

//        String username = "14031220";
//        int student_id = 23;
//        int current_year = 3;

        List<Ranking> rankings = new ArrayList<>();
        List<List<Year_Result>> all_years_results = new ArrayList<>();

        for(int year = current_year; year >= 1; year--) {

            List<Year_Result> year_results = new ArrayList<>();
            List<Object> list_courses = mdl_course_repository.getEnrolledCourses(student_id, year);
            Iterator iterator = list_courses.iterator();

            while (iterator.hasNext()) {

                Object[] courses_information = (Object[]) iterator.next();

                //Fetch all information of enrolled courses
                int course_id = (int) courses_information[0];
                String title = (String) courses_information[1];
                int credit_hour = (int) courses_information[2];

                List<Obtained_Marks> obtained_marks_detail = new ArrayList<>();
                List<Object> assessments = null;
                if(year == current_year) {
                    assessments = mdl_grade_categories_repository.get_module_assessments(course_id);
                }else {
                    assessments = mdl_grade_categories_history_repository.get_module_assessments(course_id);
                }
                Iterator assessment_iterator = assessments.iterator();

                double total_weightage = 0;
                double total_obtained_marks = 0;

                while (assessment_iterator.hasNext()) {

                    Object[] assessments_information = (Object[]) assessment_iterator.next();
                    int assessment_id = (int) assessments_information[0];
                    String assessment_type = (String) assessments_information[1];
                    double weightage = (int) assessments_information[2];
                    total_weightage += weightage;
                    double obtained_marks = 0;
                    if(year == current_year) {
                        obtained_marks = mdl_grade_grades_repository.assessment_grades(assessment_id, student_id);
                    }else{
                        obtained_marks = mdl_grade_grades_history_repository.assessment_grades(assessment_id, student_id);

                    }
                    total_obtained_marks += obtained_marks;

                    boolean status = true;
                    if (((obtained_marks / weightage) * 100) < 33) {
                        status = false;
                    }
                    obtained_marks_detail.add(new Obtained_Marks(assessment_type, weightage, obtained_marks, status, assessment_id, year));
                }

                boolean status = true;

                if (((total_obtained_marks / total_weightage) * 100) < 33) {
                    status = false;
                }

                Year_Result year_result = new Year_Result(title, total_weightage, total_obtained_marks, credit_hour, status, obtained_marks_detail, year);
                year_results.add(year_result);
            }

            all_years_results.add(year_results);
            rankings.add(find_ranking(student_id, year, current_year));
        }

        modelMap.put("rankings", rankings);
        modelMap.put("courses_data", all_years_results);
        return "Exam";
    }

//    @RequestMapping(value = "/ranking")
    public Ranking find_ranking(int student_id_, int year, int current_year) {


        List<Student> students = new ArrayList<>();
        //get students on the base of dept......
//        int current_year = mdl_user_repository.find_year(student_id_);
        List<Integer> list_students = mdl_user_repository.get_user_id(current_year);


        for(int student = 0; student < list_students.size(); student++) {
            //Needed to be looped
            int student_id = list_students.get(student);
            List<Object> list_courses_id = mdl_course_repository.getEnrolledCoursesId(student_id, year);
            Iterator iterator = list_courses_id.iterator();

            List<String> subjects_names = new ArrayList<>();
            List<Double> marks = new ArrayList<>();
//            List<Double> weitghtage = new ArrayList<>();

            while (iterator.hasNext()) {

                Object[] name_id = (Object[]) iterator.next();
                int course_id = (int) name_id[0];
                String name = (String) name_id[1];


                List<Object> assessments = null;
                if(year == current_year) {
                    assessments = mdl_grade_categories_repository.get_module_assessments_id(course_id);
                }else {
                    assessments = mdl_grade_categories_history_repository.get_module_assessments_id(course_id);
                }
                double total_obtained_marks = 0;
                double total_weightage = 0;

                Iterator assessment_iterator = assessments.iterator();
                while (assessment_iterator.hasNext()){

                    Object[] id_and_weightage = (Object[]) assessment_iterator.next();
                    int assessment_id = (int) id_and_weightage[0];
                    total_weightage += (int) id_and_weightage[1];

                    double obtained_marks = 0;
                    if(current_year == year) {
                       obtained_marks =  mdl_grade_grades_repository.assessment_grades(assessment_id, student_id);
                    }else{
                        obtained_marks = mdl_grade_grades_history_repository.assessment_grades(assessment_id, student_id);
                    }
                    total_obtained_marks += obtained_marks;
                }
                //Needed to divide total_obtained_marks with total weightage
                if(subjects_names.contains(name)){
                    int index = subjects_names.indexOf(name);
                    double first_marks = marks.get(index);
                    total_obtained_marks += first_marks;

//                    double first_weightage = weitghtage.get(index);
//                    total_weightage += first_weightage;
//
//                    total_obtained_marks /= total_weightage * 100;
//                    System.out.println("Total Marks are: " + total_obtained_marks);

//                    weitghtage.add(index, total_weightage);
                    marks.add(index, total_obtained_marks);
                }else {

//                    System.out.println("Total Marks are: " + total_obtained_marks);
                    subjects_names.add(name);
                    marks.add(total_obtained_marks);
//                    weitghtage.add(total_weightage);
                }
            }

            students.add(new Student(student_id, subjects_names, marks));
        }

        double highest_marks = 0; int index_highest_student_marks = 0;
        double lowest_marks = 0; int index_lowest_marks = 0;
        int index_your_marks = 0;

        List<Double> students_average_marks = new ArrayList<>();

        for(int i = 0; i < students.size(); i++){

            Student student = students.get(i);
            double total_marks = 0;
            for(int j = 0; j < student.getSubjects().size(); j++){
                total_marks += student.getMarks().get(j);

                if(i == 0) {
                    students_average_marks.add(student.getMarks().get(j));
                }else {
                    double average_marks1 = student.getMarks().get(j);
                    double avergae_marks2 = students_average_marks.get(j);
                    students_average_marks.add(j, (average_marks1+avergae_marks2));
                }
            }
//            student.setTotal_marks(total_marks);

            if(student.getId() == student_id_){
                index_your_marks = i;
            }

            if(i == 0){
                highest_marks = total_marks;
                index_highest_student_marks = i;
                lowest_marks = total_marks;
                index_lowest_marks = i;
            }

            if(total_marks > highest_marks){
                highest_marks = total_marks;
                index_highest_student_marks = i;
            }

            if(total_marks < lowest_marks){
                lowest_marks = total_marks;
                index_lowest_marks = i;
            }
        }

        int no_of_students = students.size();
        //Getting status of logged in student to find out his position according to every subject
        Student student = students.get(index_your_marks);
        int[] position_for_every_subject = new int[student.getSubjects().size()];
        //initialize array with zero.
        for(int i = 0; i < position_for_every_subject.length; i++){
            position_for_every_subject[i] = 1;
        }
        //finding out position according to every subject.
        for(int i = 0; i< no_of_students; i++){
            Student temp_student = students.get(i);
            for(int subject = 0; subject < student.getSubjects().size(); subject++){

                if(temp_student.getMarks().get(subject) > student.getMarks().get(subject)){
                    position_for_every_subject[subject]++;
                }
            }
        }

        for(int i = 0; i < students_average_marks.size(); i++){

            students_average_marks.set(i, students_average_marks.get(i)/no_of_students);
        }
        Student student_with_highest_marks = students.get(index_highest_student_marks);
        Student student_with_lowest_marks = students.get(index_lowest_marks);
        Student you = students.get(index_your_marks);

        Ranking ranking = new Ranking(year, you.getSubjects(), student_with_highest_marks.getMarks(),
                student_with_lowest_marks.getMarks(), you.getMarks(), students_average_marks, position_for_every_subject);
//        subjects = you.getSubjects();
//        highestmarks = student_with_highest_marks.getMarks();
//        lowestmarks = student_with_lowest_marks.getMarks();
//        avergaemarks = students_average_marks;
//        mymarks = you.getMarks();

        return ranking;
    }
}
