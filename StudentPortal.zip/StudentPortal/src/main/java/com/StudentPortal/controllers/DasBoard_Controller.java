package com.StudentPortal.controllers;

import com.StudentPortal.Data.Message_Mimes;
import com.StudentPortal.repository.moodleds.MDL_User_Repository;
import com.StudentPortal.repository.moodleds.Messages_Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.SystemEnvironmentPropertySource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Created by abdul on 4/23/17.
 */
@Controller
@SessionAttributes(value = {"username", "name", "id"})
public class DasBoard_Controller {

    @Autowired
    private Messages_Repository messages_repository;

    @Autowired
    MDL_User_Repository mdl_user_repository;

    @RequestMapping(value = "/dashboard", method = RequestMethod.GET)
    public String dashBoard(ModelMap modelMap, HttpSession httpSession){

        String username = (String) httpSession.getAttribute("username");
        if(username == null){
            return "redirect:/";
        }

        String email_id = (String) mdl_user_repository.get_Email_Id(username);
        List<Object> unread_Messages = messages_repository.messages_mime(email_id);
        List<Message_Mimes>  message_mimes = new ArrayList<>();

        Iterator unread_messages_Iterator = unread_Messages.iterator();

        while (unread_messages_Iterator.hasNext()){

            Object[] objects = (Object[]) unread_messages_Iterator.next();
            message_mimes.add(new Message_Mimes((String) objects[0], (String) objects[1]));
        }

        modelMap.put("message_mimes", message_mimes);
        System.out.println("I am IN");

        return "dashboard";
    }
}
