package com.StudentPortal.controllers;

import com.StudentPortal.Data.Item;
import com.StudentPortal.Data.Items;
import com.StudentPortal.Data.User_Issued_Items_Information;
import com.StudentPortal.model.papercutds.Issued_Items;
import com.StudentPortal.model.papercutds.Tbl_User;
import com.StudentPortal.repository.papercutds.Issued_Items_Repository;
import com.StudentPortal.repository.papercutds.Items_Repository;
import com.StudentPortal.repository.papercutds.Tbl_User_Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.SystemEnvironmentPropertySource;
import org.springframework.http.MediaType;
import org.springframework.jca.cci.core.InteractionCallback;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import sun.util.calendar.LocalGregorianCalendar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by abdul on 4/19/17.
 */
@Controller
@SessionAttributes(value = {"itsc", "name", "id"})
public class ITSC_Home_Controller {

    @Autowired
    Issued_Items_Repository issued_items_repository;

    @Autowired
    Items_Repository items_repository;

    @Autowired
    Tbl_User_Repository tbl_user_repository;


    @RequestMapping (value = "/ITSC_Dashboard", method = RequestMethod.GET)
    public String ITSC_Dashboard(ModelMap modelMap, HttpSession httpSession){

        String username = (String) httpSession.getAttribute("itsc");
        if(username == null){
            return "redirect:/";
        }

        List<Items> all_items_names = new ArrayList<>();
        List<Object> all_items = items_repository.get_All_Items();
        Iterator iterator_all_items = all_items.iterator();

        while (iterator_all_items.hasNext()){

            Object[] items_objects = (Object[]) iterator_all_items.next();
            all_items_names.add(new Items((int) items_objects[0], (String) items_objects[1], (String) items_objects[2]));
        }

        modelMap.put("all_items", all_items_names);
        return "ITSC_Dashboard";
    }
    @RequestMapping(value = "/itsc_items", method = RequestMethod.GET)
    public String log_in(ModelMap modelMap, HttpSession httpSession){

        String username = (String) httpSession.getAttribute("itsc");
        if(username == null){
            return "redirect:/";
        }

        List<User_Issued_Items_Information> user_issued_items_information = new ArrayList<>();
        List<Object> issued_items = issued_items_repository.get_Issued_Items();
        Iterator issued_items_iterator = issued_items.iterator();

        while (issued_items_iterator.hasNext()){

            Object[] objects_issued_items = (Object[]) issued_items_iterator.next();
            int item_id = (int) objects_issued_items[0];
            String issued_date = String.valueOf((Date) objects_issued_items[1]).split(" ")[0];
            String due_date = String.valueOf((Date) objects_issued_items[2]).split(" ")[0];
            int user_id = (int) objects_issued_items[3];
            int quantity = (int) objects_issued_items[4];

            List<Object> item = items_repository.get_Items(item_id);
            Iterator iterator_item = item.iterator();
            Object[] item_object = (Object[]) iterator_item.next();
            String item_name = item_object[0] + "  " + item_object[1];

            List<Object> user_information = tbl_user_repository.get_User_Information(user_id);
            Iterator iterator_user_information = user_information.iterator();

            Object[] user_info = (Object[]) iterator_user_information.next();
            String full_name = (String) user_info[0];
            String user_name = (String) user_info[1];
            String email = (String) user_info[2];


            user_issued_items_information.add(new User_Issued_Items_Information(item_id, full_name, user_name, email, item_name, quantity, issued_date, due_date));

        }


        List<Item> items_details_ = new ArrayList<>();
        List<Object> all_items_ = items_repository.get_Items();
        Iterator iterator_all_items_ = all_items_.iterator();

        while (iterator_all_items_.hasNext()){

            Object[] objects = (Object[]) iterator_all_items_.next();
            String item_name = (String) objects[0];
            String item_model = (String) objects[1];
            int quantity = (int) objects[2];
            int issued_items_ = (int) objects[3];
            int remaining_items_ = (int) objects[4];
            int items_id_ = (int) objects[5];

            items_details_.add(new Item(items_id_, item_name, item_model, quantity, issued_items_, remaining_items_));
        }


        modelMap.put("items_detail", items_details_);
        modelMap.put("user_issued_items", user_issued_items_information);

        return "issue_items";
    }

    @RequestMapping (value = "add_item", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody void add_item(HttpSession httpSession, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws IOException{

        String item_name = httpServletRequest.getParameter("item_name");
        String item_model = httpServletRequest.getParameter("model");
        int quantity = 0;
        try {
            quantity = Integer.valueOf(httpServletRequest.getParameter("quantity"));
        }catch (Exception e){
            e.printStackTrace();
            httpServletResponse.getWriter().println("There is a problem with quantity input");
            httpServletResponse.flushBuffer();
            return;
        }


        items_repository.save(new com.StudentPortal.model.papercutds.Items(item_name, item_model, quantity, 0, quantity));
        httpServletResponse.getWriter().println("Item has been added");
        httpServletResponse.flushBuffer();
    }
    @RequestMapping (value = "issue_item", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    void issue_Item_Request(HttpSession httpSession, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws IOException {

        String name = String.valueOf(httpServletRequest.getParameter("name_"));
        String rollno = String.valueOf(httpServletRequest.getParameter("rollno_"));
        int selected_item = 0;
        int quantity = 0;
        try {
            selected_item = Integer.valueOf(httpServletRequest.getParameter("selected_item_"));
            quantity = Integer.valueOf(httpServletRequest.getParameter("quantity_"));
        }catch (Exception e){
            e.printStackTrace();
            httpServletResponse.getWriter().println("Sorry! Try again");
            httpServletResponse.flushBuffer();
            return;
        }
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String due_date_string = String.valueOf(httpServletRequest.getParameter("due_date_"));
        Date due_date;
        try {
             due_date = dateFormat.parse(due_date_string);
        }catch (Exception e){
            e.printStackTrace();
            httpServletResponse.getWriter().println("Sorry! There is a problem with your date");
            httpServletResponse.flushBuffer();
            return;
        }

        List<Object>  items = items_repository.get_Item_Quantity(selected_item);
        Iterator iterator_items = items.iterator();
        Object[] objects_items = (Object[]) iterator_items.next();
        int remaining_items = (int) objects_items[0];
        int issued_items = (int) objects_items[1]   ;

        if(quantity > remaining_items){
            httpServletResponse.getWriter().println("There 0 such item in database");
            httpServletResponse.flushBuffer();
            return;
        }else{

            //set update query and issued item.........problems
            int remaining_quantity = remaining_items - quantity;
            issued_items += quantity;


            items_repository.update_items(issued_items, remaining_quantity, selected_item);

            int user_id = tbl_user_repository.get_User_Id(rollno);
            String user_email = tbl_user_repository.get_Email(user_id);
            List<Object> item = items_repository.get_Items(selected_item);
            Iterator iterator = item.iterator();
            Object[] objects = (Object[]) iterator.next();

            String item_name = objects[0] + " " + objects[1];
            java.util.Date utilDate = new java.util.Date();
            java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());

            issued_items_repository.save(new Issued_Items(selected_item, user_id, new Date(), due_date, quantity));
            httpServletResponse.getWriter().println("Item Issued Successfuly");
            httpServletResponse.flushBuffer();

//            System.out.println("I am here5");
//            return;
        }
    }

    @RequestMapping (value = "/return_item", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    List<Item> return_Item_Request(HttpSession httpSession, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws IOException {

        List<Item> items_details_ = new ArrayList<>();
        String username = (String) httpSession.getAttribute("itsc");
        if(username == null){
            items_details_.add(new Item(0, "Server error please try again", null, 0, 0, 0));
            return items_details_;
        }

        String id_ = httpServletRequest.getParameter("id_");
        int id = Integer.parseInt(id_.substring(10, id_.length()));

        String date_ = id_.substring(0, 10);
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date date = null;

        try {
             date =  dateFormat.parse(date_);
        }catch (ParseException e){

            items_details_.add(new Item(0, "Server error please try again", null, 0, 0, 0));
            return items_details_;
        }

        int quantity = issued_items_repository.get_Quantity(id, date);
        items_repository.returned_Item(id, quantity);
        issued_items_repository.delete_Record(id, date);

//        List<Item> items_details_ = new ArrayList<>();
        List<Object> all_items_ = items_repository.get_Items();
        Iterator iterator_all_items_ = all_items_.iterator();

        while (iterator_all_items_.hasNext()){

            Object[] objects_ = (Object[]) iterator_all_items_.next();
            String item_name_ = (String) objects_[0];
            String item_model_ = (String) objects_[1];
            int quantity_ = (int) objects_[2];
            int issued_items_ = (int) objects_[3];
            int remaining_items_ = (int) objects_[4];
            int item_id_ = (int) objects_[5];

            items_details_.add(new Item(item_id_, item_name_, item_model_, quantity_, issued_items_, remaining_items_));
        }

        return items_details_;
    }


    @RequestMapping (value = "/update_quantity", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public void update_Item_Quantity(HttpSession httpSession, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws IOException{

        String username = (String) httpSession.getAttribute("itsc");
        if(username == null){
            httpServletResponse.getWriter().println("Please try again");
            return;
        }

        int item_quantity = 0; int item_id = 0;
        try {
            item_id = Integer.valueOf(httpServletRequest.getParameter("item_id"));
            item_quantity = Integer.valueOf(httpServletRequest.getParameter("item_quantity"));
        }catch (Exception e){

            httpServletResponse.getWriter().println("Please try again");
            httpServletResponse.flushBuffer();
            return;
        }

        System.out.println(item_id + "   " + item_quantity);
        items_repository.update_Quantity(item_quantity, item_id);
//        int remaining_item = items_repository.get_Remaining_Items(item_id);

        httpServletResponse.getWriter().println("Updated Items Successfuly");
        httpServletResponse.flushBuffer();
    }

    @RequestMapping (value = "/delete_item/{item_id}")
    public String delete_Item(@PathVariable("item_id") int id, HttpSession httpSession){

        String username = (String) httpSession.getAttribute("itsc");
        if(username == null){
            return "redirect:/";
        }
        items_repository.delete_Item(id);
        return "redirect:/ITSC_items";
    }

}
