package com.StudentPortal.controllers;

import com.StudentPortal.Data.Courses_Sessions;
import com.StudentPortal.Data.Module;
import com.StudentPortal.repository.moodleds.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.SystemEnvironmentPropertySource;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import javax.servlet.http.HttpSession;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by abdul on 3/10/17.
 */
@Controller
@SessionAttributes(value = {"username", "name", "id"})
public class AttendanceController {

    @Autowired
    MDL_Course_Repository mdl_course_repository;

    @Autowired
    MDL_Attendance_Repository mdl_attendance_repository;

    @Autowired
    MDL_Attendance_Sessions_Repository mdl_attendance_sessions_repository;

    @Autowired
    MDL_Attendance_Statuses_Repository mdl_attendance_statuses_repository;

    @Autowired
    MDL_Attendance_Log_Repository mdl_attendance_log_repository;

    @Autowired
    MDL_User_Repository mdl_user_repository;

    @RequestMapping(value = "/attendance")
    public String attendance(ModelMap modelMap, HttpSession httpSession) {


        String username = (String) httpSession.getAttribute("username");
        if(username == null){
            return "redirect:/";
        }
        int user_id = (Integer) httpSession.getAttribute("id");

        int current_year = mdl_user_repository.find_year(user_id);
        List<Module> year1 = new ArrayList<>();
        List<Module> year2 = new ArrayList<>();
        List<Module> year3 = new ArrayList<>();
        List<Module> year4 = new ArrayList<>();

        for (int i = 1; i <= current_year; i++) {

            List<Object> all_Courses_Enrolled = mdl_course_repository.get_CourseOffering_By_Year(i, user_id);
            Iterator iterator = all_Courses_Enrolled.iterator();

            while (iterator.hasNext()) {

                Object[] objects = (Object[]) iterator.next();
                int course_id = (int) objects[0];
                String title = (String) objects[1];
                String short_name = (String) objects[2];
                int attendance_id = mdl_attendance_repository.get_attendance_id(course_id);

                int present_status_id = mdl_attendance_statuses_repository.get_present_status_id(attendance_id);
                int absent_status_id = mdl_attendance_statuses_repository.get_absent_status_id(attendance_id);

                int count_of_presents = mdl_attendance_log_repository.count_Present(user_id, attendance_id, present_status_id);
                int count_of_absents = mdl_attendance_log_repository.count_Present(user_id, attendance_id, absent_status_id);
                int total_sessions = mdl_attendance_sessions_repository.count_sessions(attendance_id);

                double attendance_Percentage = count_of_presents / (double) total_sessions * 100;
                List<Object> sessions = mdl_attendance_sessions_repository.sessions_information(attendance_id);
                Iterator sessions_iterator = sessions.iterator();
                List<Courses_Sessions> courses_sessionses = new ArrayList<>();

                while (sessions_iterator.hasNext()) {

                    Object[] session_details = (Object[]) sessions_iterator.next();
                    int sessio_id = (int) session_details[0];

                    int session_Date = (int) session_details[1];
                    Date date = new Date(session_Date);

                    String dateStr = "Mon Jun 18 00:00:00 GMT 2012";
                    DateFormat formatter = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
                    Calendar cal = Calendar.getInstance();
                    try {
                        Date date_ = (Date) formatter.parse(String.valueOf(date));
                        cal.setTime(date_);
                    }catch (Exception e){
                        e.printStackTrace();

                    }

                    String formatedDate = cal.get(Calendar.DATE) + "/" + (cal.get(Calendar.MONTH) + 1) + "/" +         cal.get(Calendar.YEAR);


                    String time = cal.get(Calendar.HOUR) + ":" + cal.get(Calendar.MINUTE);

                    int status_id = mdl_attendance_log_repository.status_attendance(user_id, sessio_id);
                    String status_String = mdl_attendance_statuses_repository.get_Status(status_id);

                    courses_sessionses.add(new Courses_Sessions(time, formatedDate, status_String));
                }

                if(i == 1) {
                    if ((title).contains("(Semester-1)")) {
                        year1.add(new Module(short_name + " (S1)", attendance_Percentage, 1, courses_sessionses));
                    } else if ((title).contains("(Semester-2)")) {
                        year1.add(new Module(short_name + " (S2)", attendance_Percentage, 2, courses_sessionses));
                    }
                }

                if(i == 2) {
                    if ((title).contains("(Semester-1)")) {
                        year2.add(new Module(short_name + " (S1)", attendance_Percentage, 1, courses_sessionses));
                    } else if ((title).contains("(Semester-2)")) {
                        year2.add(new Module(short_name + " (S2)", attendance_Percentage, 2, courses_sessionses));
                    }
                }

                if(i == 3) {
                    if ((title).contains("(Semester-1)")) {
                        year3.add(new Module(short_name + " (S1)", attendance_Percentage, 1, courses_sessionses));
                    } else if ((title).contains("(Semester-2)")) {
                        year3.add(new Module(short_name + " (S2)", attendance_Percentage, 2, courses_sessionses));
                    }
                }

                if(i == 4) {
                    if ((title).contains("(Semester-1)")) {
                        year4.add(new Module(short_name + " (S1)", attendance_Percentage, 1, courses_sessionses));
                    } else if ((title).contains("(Semester-2)")) {
                        year4.add(new Module(short_name + " (S2)", attendance_Percentage, 2, courses_sessionses));
                    }
                }
            }
        }
        if(current_year == 1) {
            modelMap.put("current_year", current_year);
            modelMap.put("current_year_module", year1);
        }

        if(current_year == 2) {
            modelMap.put("current_year", current_year);
            modelMap.put("current_year_module", year2);
            modelMap.put("past_year1", year1);
        }

        if(current_year == 3) {
            modelMap.put("current_year", current_year);
            modelMap.put("current_year_module", year3);
            modelMap.put("past_year1", year1);
            modelMap.put("past_year2", year2);
        }

        if(current_year == 4) {
            modelMap.put("current_year", current_year);
            modelMap.put("current_year_module", year4);
            modelMap.put("past_year1", year1);
            modelMap.put("past_year2", year2);
            modelMap.put("past_year3", year3);
        }
        return "Attendance";
    }
}
