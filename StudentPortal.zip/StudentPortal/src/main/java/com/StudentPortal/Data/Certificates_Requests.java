package com.StudentPortal.Data;

import java.util.Date;

/**
 * Created by Shakir Afridi on 4/22/2017.
 */
public class Certificates_Requests {

    private int j_id;
    private String firstname;
    private String lastname;
    private String username;
    private int currently_enrolled;
    private String department;
    private String certificate_of;
    private String request_date;
    private String received_date;
    private String status;


    public Certificates_Requests(int j_id, String firstname,String lastname, String username, int currently_enrolled, String department,String certificate_of,String request_date, String received_date, String status){
        this.j_id = j_id;
        this.firstname = firstname;
        this.lastname = lastname;
        this.username = username;
        this.currently_enrolled = currently_enrolled;
        this.department = department;
        this.certificate_of = certificate_of;
        this.request_date = request_date;
        this.received_date = received_date;
        this.status = status;
    }

    public int getJ_id() {
        return j_id;
    }

    public void setJ_id(int j_id) {
        this.j_id = j_id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getReceived_date() {
        return received_date;
    }

    public void setReceived_date(String received_date) {
        this.received_date = received_date;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getCurrently_enrolled() {
        return currently_enrolled;
    }

    public void setCurrently_enrolled(int currently_enrolled) {
        this.currently_enrolled = currently_enrolled;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public int getYear() {
        return currently_enrolled;
    }

    public void setYear(int year) {
        this.currently_enrolled = year;
    }

    public String getDept() {
        return department;
    }

    public void setDept(String dept) {
        this.department = dept;
    }

    public String getCertificate_of() {
        return certificate_of;
    }

    public void setCertificate_of(String certificate_of) {
        this.certificate_of = certificate_of;
    }

    public String getRequest_date() {
        return request_date;
    }

    public void setRequest_date(String request_date) {
        this.request_date = request_date;
    }
}
