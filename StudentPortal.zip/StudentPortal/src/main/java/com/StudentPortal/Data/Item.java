package com.StudentPortal.Data;

/**
 * Created by abdul on 4/22/17.
 */
public class Item {

    private int item_id;
    private String item_name;
    private String item_model;
    private int quantity;
    private int issued_item;
    private int remaining_item;

    public Item(int item_id, String item_name, String item_model, int quantity, int issued_item, int remaining_item) {
        this.item_id = item_id;
        this.item_name = item_name;
        this.item_model = item_model;
        this.quantity = quantity;
        this.issued_item = issued_item;
        this.remaining_item = remaining_item;
    }

    public int getItem_id() {
        return item_id;
    }

    public void setItem_id(int item_id) {
        this.item_id = item_id;
    }

    public String getItem_name() {
        return item_name;
    }

    public void setItem_name(String item_name) {
        this.item_name = item_name;
    }

    public String getItem_model() {
        return item_model;
    }

    public void setItem_model(String item_model) {
        this.item_model = item_model;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getIssued_item() {
        return issued_item;
    }

    public void setIssued_item(int issued_item) {
        this.issued_item = issued_item;
    }

    public int getRemaining_item() {
        return remaining_item;
    }

    public void setRemaining_item(int remaining_item) {
        this.remaining_item = remaining_item;
    }
}
