package com.StudentPortal.Data;

/**
 * Created by abdul on 3/29/17.
 */
public class Teachers_Information {

    private int id;
    private String name;
    private String email;
    private String address;
    private String dept;
    private String phone1;
    private String phone2;

    private String firstname;
    private String lastname;
    private String fullname;
    private int year;


    public Teachers_Information(int id, String name, String email, String address, String dept, String phone1, String phone2) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.address = address;
        this.dept = dept;
        this.phone1 = phone1;
        this.phone2 = phone2;
    }

    public Teachers_Information(String firstname, String lastname,String email,String phone1,String phone2,String dept,String address){
        this.firstname = firstname;
        this.lastname = lastname;
        this.email = email;
        this.phone1 = phone1;
        this.phone2 = phone2;
        this.dept = dept;
        this.address = address;
    }


    public Teachers_Information(String fullname, int year){
        this.fullname = fullname;
        this.year = year;
    }


    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public String getPhone1() {
        return phone1;
    }

    public void setPhone1(String phone1) {
        this.phone1 = phone1;
    }

    public String getPhone2() {
        return phone2;
    }

    public void setPhone2(String phone2) {
        this.phone2 = phone2;
    }
}
