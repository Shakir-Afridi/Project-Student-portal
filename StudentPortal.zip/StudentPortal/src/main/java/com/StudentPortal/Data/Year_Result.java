package com.StudentPortal.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by DEll1 on 3/14/2017.
 */
public class Year_Result {


    private  String title;
    private double weightage;
    private double obtained_marks;
    private int credit_hour;
    private boolean status;

    public int year;
    private List<Obtained_Marks> asses_Obtained_Marks = new ArrayList<>();

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public double getWeightage() {
        return weightage;
    }

    public void setWeightage(double weightage) {
        this.weightage = weightage;
    }

    public double getObtained_marks() {
        return obtained_marks;
    }

    public void setObtained_marks(long obtained_marks) {
        this.obtained_marks = obtained_marks;
    }

    public int getCredit_hour() {
        return credit_hour;
    }

    public void setCredit_hour(int credit_hour) {
        this.credit_hour = credit_hour;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public List<Obtained_Marks> getAsses_Obtained_Marks() {
        return asses_Obtained_Marks;
    }

    public void setAsses_Obtained_Marks(ArrayList<Obtained_Marks> asses_Obtained_Marks) {
        this.asses_Obtained_Marks = asses_Obtained_Marks;
    }

    public Year_Result(String title, double weightage, double obtained_marks, int credit_hour, boolean status, List<Obtained_Marks> asses_Obtained_Marks, int year) {

        this.year = year;
        this.title = title;
        this.weightage = weightage;
        this.obtained_marks = obtained_marks;
        this.credit_hour = credit_hour;
        this.status = status;
        this.asses_Obtained_Marks = asses_Obtained_Marks;
    }
}
