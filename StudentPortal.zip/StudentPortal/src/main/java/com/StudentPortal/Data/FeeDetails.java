package com.StudentPortal.Data;

import org.springframework.data.repository.query.Param;

/**
 * Created by abdul on 5/1/17.
 */
public class FeeDetails {

    private int amount;
    private String paid_on;
    private int fee_id;
    private String installment_type;
    private String from_date;
    private String date_to;
    private String due_for;


    public FeeDetails(int fee_id, String installment_type, String from_date, String date_to, String paid_on, int amount, String due_for) {
        this.amount = amount;
        this.paid_on = paid_on;
        this.fee_id = fee_id;
        this.installment_type = installment_type;
        this.from_date = from_date;
        this.date_to = date_to;
        this.due_for = due_for;
    }



    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public String getPaid_on() {
        return paid_on;
    }

    public void setPaid_on(String paid_on) {
        this.paid_on = paid_on;
    }

    public int getFee_id() {
        return fee_id;
    }

    public void setFee_id(int fee_id) {
        this.fee_id = fee_id;
    }


    public String getInstallment_type() {
        return installment_type;
    }

    public void setInstallment_type(String installment_type) {
        this.installment_type = installment_type;
    }

    public String getFrom_date() {
        return from_date;
    }

    public void setFrom_date(String from_date) {
        this.from_date = from_date;
    }

    public String getDate_to() {
        return date_to;
    }

    public void setDate_to(String date_to) {
        this.date_to = date_to;
    }

    public String getDue_for() {
        return due_for;
    }

    public void setDue_for(String due_for) {
        this.due_for = due_for;
    }
}
