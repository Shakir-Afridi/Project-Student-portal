package com.StudentPortal.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by abdul on 3/26/17.
 */
public class Student {

    private int id;
    private List<String> subjects = new ArrayList<>();
    private List<Double> marks = new ArrayList<>();
    double total_marks;

    public Student(int id, List<String> subjects, List<Double> marks) {
        this.id = id;
        this.subjects = subjects;
        this.marks = marks;
    }

    public double getTotal_marks() {
        return total_marks;
    }

    public void setTotal_marks(double total_marks) {
        this.total_marks = total_marks;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public List<String> getSubjects() {
        return subjects;
    }

    public void setSubjects(List<String> subjects) {
        this.subjects = subjects;
    }

    public List<Double> getMarks() {
        return marks;
    }

    public void setMarks(List<Double> marks) {
        this.marks = marks;
    }
}
