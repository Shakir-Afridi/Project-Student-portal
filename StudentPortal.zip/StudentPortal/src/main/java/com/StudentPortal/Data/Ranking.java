package com.StudentPortal.Data;

import java.util.List;

/**
 * Created by abdul on 4/7/17.
 */
public class Ranking {

    private int year;
    private List<String> subjects;
    private List<Double> highest_marks;
    private List<Double> lowest_marks;
    private List<Double> my_marks;
    private List<Double> average_marks;
    private int[] position_for_every_subject;

    public Ranking(int year, List<String> subjects, List<Double> highest_marks, List<Double> lowest_marks, List<Double> my_marks, List<Double> average_marks, int[] position_for_every_subject) {
        this.year = year;
        this.subjects = subjects;
        this.highest_marks = highest_marks;
        this.lowest_marks = lowest_marks;
        this.my_marks = my_marks;
        this.average_marks = average_marks;
        this.position_for_every_subject = position_for_every_subject;
    }

    public int[] getPosition_for_every_subject() {
        return position_for_every_subject;
    }

    public void setPosition_for_every_subject(int[] position_for_every_subject) {
        this.position_for_every_subject = position_for_every_subject;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public List<String> getSubjects() {
        return subjects;
    }

    public void setSubjects(List<String> subjects) {
        this.subjects = subjects;
    }

    public List<Double> getHighest_marks() {
        return highest_marks;
    }

    public void setHighest_marks(List<Double> highest_marks) {
        this.highest_marks = highest_marks;
    }

    public List<Double> getLowest_marks() {
        return lowest_marks;
    }

    public void setLowest_marks(List<Double> lowest_marks) {
        this.lowest_marks = lowest_marks;
    }

    public List<Double> getMy_marks() {
        return my_marks;
    }

    public void setMy_marks(List<Double> my_marks) {
        this.my_marks = my_marks;
    }

    public List<Double> getAverage_marks() {
        return average_marks;
    }

    public void setAverage_marks(List<Double> average_marks) {
        this.average_marks = average_marks;
    }
}
