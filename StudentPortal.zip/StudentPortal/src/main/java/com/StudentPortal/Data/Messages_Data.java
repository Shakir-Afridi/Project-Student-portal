package com.StudentPortal.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by abdul on 2/25/17.
 */
public class Messages_Data {

    private int thread_id;
    private String sender_email_id;
    private String receiver_email_id;
    private String sender_name;
    private String message;
    private List<String> files_Names = new ArrayList<>();
//    private List<Integer> attachment_id = new ArrayList<>();

    public int getThread_id() {
        return thread_id;
    }

    public void setThread_id(int thread_id) {
        this.thread_id = thread_id;
    }

    public String getSender_email_id() {
        return sender_email_id;
    }

    public void setSender_email_id(String sender_email_id) {
        this.sender_email_id = sender_email_id;
    }

    public String getReceiver_email_id() {
        return receiver_email_id;
    }

    public void setReceiver_email_id(String receiver_email_id) {
        this.receiver_email_id = receiver_email_id;
    }

    public String getSender_name() {
        return sender_name;
    }

    public void setSender_name(String sender_name) {
        this.sender_name = sender_name;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<String> getFiles_Names() {
        return files_Names;
    }

    public void setFiles_Names(List<String> attachment_path) {
        this.files_Names = attachment_path;
    }

//    public List<Integer> getAttachment_id() {
//        return attachment_id;
//    }
//
//    public void setAttachment_id(List<Integer> attachment_id) {
//        this.attachment_id = attachment_id;
//    }
//
    public Messages_Data(int thread_id, String sender_email_id, String receiver_email_id, String sender_name, String message) {
        this.thread_id = thread_id;
        this.sender_email_id = sender_email_id;
        this.receiver_email_id = receiver_email_id;

        this.sender_name = sender_name;
        this.message = message;
    }


}
