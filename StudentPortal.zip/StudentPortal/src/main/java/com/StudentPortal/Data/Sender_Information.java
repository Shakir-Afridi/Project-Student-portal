package com.StudentPortal.Data;

/**
 * Created by abdul on 2/25/17.
 */
public class Sender_Information {

    private int thread_id;
    private String sender_name;
    private String date;
    private String time;

    public Sender_Information(int thread_id, String sender_name, String date, String time) {
        this.thread_id = thread_id;
        this.sender_name = sender_name;
        this.date = date;
        this.time = time;
    }

    public int getThread_id() {
        return thread_id;
    }

    public void setThread_id(int thread_id) {
        this.thread_id = thread_id;
    }

    public String getSender_name() {
        return sender_name;
    }

    public void setSender_name(String sender_name) {
        this.sender_name = sender_name;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
