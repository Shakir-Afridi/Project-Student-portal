package com.StudentPortal.Data;

import java.util.ArrayList;

/**
 * Created by abdul on 2/13/17.
 */
public class ModuleAttendance {

    private String module_title;
    private int module_percentage;
    private String module_semester;
    private ArrayList<SessionsRecord> sessionsRecords = new ArrayList<>();

    public ModuleAttendance(String module_title, int module_percentage, String module_semester) {
        this.module_title = module_title;
        this.module_percentage = module_percentage;
        this.module_semester = module_semester;
    }

    public String getModule_title() {
        return module_title;
    }

    public void setModule_title(String module_title) {
        this.module_title = module_title;
    }

    public int getModule_percentage() {
        return module_percentage;
    }

    public void setModule_percentage(int module_percentage) {
        this.module_percentage = module_percentage;
    }

    public String getModule_semester() {
        return module_semester;
    }

    public void setModule_semester(String module_semester) {
        this.module_semester = module_semester;
    }
}
