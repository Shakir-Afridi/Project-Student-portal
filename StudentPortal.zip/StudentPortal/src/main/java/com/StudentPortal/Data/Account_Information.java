package com.StudentPortal.Data;

/**
 * Created by abdul on 4/23/17.
 */
public class Account_Information {

    private String date;
    private int pages;
    private float bill;

    public Account_Information(String date, int pages, float bill) {
        this.date = date;
        this.pages = pages;
        this.bill = bill;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getPages() {
        return pages;
    }

    public void setPages(int pages) {
        this.pages = pages;
    }

    public float getBill() {
        return bill;
    }

    public void setBill(float bill) {
        this.bill = bill;
    }
}
