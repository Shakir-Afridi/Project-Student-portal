package com.StudentPortal.Data;

/**
 * Created by DEll1 on 2/23/2017.
 */
public class Obtained_Marks {

    private String assessment_type;
    private double assessment_percentage;
    private double obtained_marks;
    private int id;
    private int year;
    private boolean status;



    public void setAssessment_type(String assessment_type) {
        this.assessment_type = assessment_type;
    }

    public String getAssessment_type() {
        return assessment_type;

    }

    public double getAssessment_percentage() {
        return assessment_percentage;
    }

    public void setAssessment_percentage(double assessment_percentage) {
        this.assessment_percentage = assessment_percentage;
    }

    public double getObtained_marks() {

        return obtained_marks;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public int getId(){
        return  id;
    }

    public void setObtained_marks(int obtained_marks) {
        this.obtained_marks = obtained_marks;
    }

    public void setId(int id){
        this.id=id;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public Obtained_Marks(String assessment_type, double assessment_percentage, double obtained_marks, boolean status, int id, int year) {
        this.assessment_type = assessment_type;
        this.assessment_percentage = assessment_percentage;
        this.obtained_marks = obtained_marks;
        this.status = status;
        this.id = id;
        this.year=year;
    }

}
