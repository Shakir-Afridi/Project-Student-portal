package com.StudentPortal.Data;

/**
 * Created by abdul on 4/28/17.
 */
public class Societies_Body_History_Data {

    private String name;
    private String roll_no;
    private String status;
    private String joining_date;
    private String leaving_date;

    public Societies_Body_History_Data(String name, String roll_no, String status, String joining_date, String leaving_date) {
        this.name = name;
        this.roll_no = roll_no;
        this.status = status;
        this.joining_date = joining_date;
        this.leaving_date = leaving_date;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRoll_no() {
        return roll_no;
    }

    public void setRoll_no(String roll_no) {
        this.roll_no = roll_no;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getJoining_date() {
        return joining_date;
    }

    public void setJoining_date(String joining_date) {
        this.joining_date = joining_date;
    }

    public String getLeaving_date() {
        return leaving_date;
    }

    public void setLeaving_date(String leaving_date) {
        this.leaving_date = leaving_date;
    }
}
