package com.StudentPortal.Data;

/**
 * Created by abdul on 4/11/17.
 */
public class Jobs_Vaccancies {

    private int v_id;
    private String job_nature;
    private String job_title;
    private String date;
    private String due_date;

    public Jobs_Vaccancies(int v_id, String job_nature, String job_title, String date, String due_date) {
        this.v_id = v_id;
        this.job_nature = job_nature;
        this.job_title = job_title;
        this.date = date;
        this.due_date = due_date;
    }

    public int getV_id() {
        return v_id;
    }

    public void setV_id(int v_id) {
        this.v_id = v_id;
    }

    public String getJob_nature() {
        return job_nature;
    }

    public void setJob_nature(String job_nature) {
        this.job_nature = job_nature;
    }

    public String getJob_title() {
        return job_title;
    }

    public void setJob_title(String job_title) {
        this.job_title = job_title;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDue_date() {
        return due_date;
    }

    public void setDue_date(String due_date) {
        this.due_date = due_date;
    }
}
