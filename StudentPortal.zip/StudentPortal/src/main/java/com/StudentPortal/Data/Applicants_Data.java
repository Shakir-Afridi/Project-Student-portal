package com.StudentPortal.Data;

/**
 * Created by abdul on 4/28/17.
 */
public class Applicants_Data {

    private String name;
    private String uob;
    private String date;
    private String society;
    private String status;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUob() {
        return uob;
    }

    public void setUob(String uob) {
        this.uob = uob;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getSociety() {
        return society;
    }

    public void setSociety(String society) {
        this.society = society;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Applicants_Data(String name, String uob, String date, String society, String status) {

        this.name = name;
        this.uob = uob;
        this.date = date;
        this.society = society;
        this.status = status;
    }
}
