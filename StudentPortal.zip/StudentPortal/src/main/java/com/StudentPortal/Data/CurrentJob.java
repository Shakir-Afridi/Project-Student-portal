package com.StudentPortal.Data;

import java.util.ArrayList;

/**
 * Created by abdul on 2/10/17.
 */
public class CurrentJob {

    private int id;
    private String societies_Nature;
    private String job_title;
    private String joining_Date;
    private String leaving_Date;
    private boolean status;
    private ArrayList<SocietyTableData> societyTableData;

    public ArrayList<SocietyTableData> getSocietyTableData() {
        return societyTableData;
    }

    public void setSocietyTableData(ArrayList<SocietyTableData> societyTableData) {
        this.societyTableData = societyTableData;
    }

    public CurrentJob(int id, String job_title, String societies_Nature, String joining_date, String leaving_date, boolean status){
        this.id = id;
        this.joining_Date = joining_date;
        this.leaving_Date = leaving_date;
        this.status = status;
        this.societies_Nature = societies_Nature;
        this.job_title = job_title;
        societyTableData = new ArrayList<>();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void addRow(String startDate, String endDate, int working_hour, int pay, boolean paid){
        societyTableData.add(new SocietyTableData(startDate, endDate, working_hour, pay, paid));
    }

    public String getJoining_Date() {
        return joining_Date;
    }

    public void setJoining_Date(String joining_Date) {
        this.joining_Date = joining_Date;
    }

    public String getLeaving_Date() {
        return leaving_Date;
    }

    public void setLeaving_Date(String leaving_Date) {
        this.leaving_Date = leaving_Date;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getSocieties_Nature() {
        return societies_Nature;
    }

    public void setSocieties_Nature(String societies_Nature) {
        this.societies_Nature = societies_Nature;
    }

    public String getJob_title() {
        return job_title;
    }

    public void setJob_title(String job_title) {
        this.job_title = job_title;
    }
}
