package com.StudentPortal.Data;

/**
 * Created by abdul on 4/23/17.
 */
public class Message_Mimes {

    private String name;
    private String message;

    public Message_Mimes(String name, String message) {
        this.name = name;

        if(message.length() <= 30)
            this.message = message;
        else {
            this.message = message.substring(0, 30);
            this.message += "...";
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {

        this.message = message;
    }
}
