package com.StudentPortal.Data;

/**
 * Created by abdul on 4/29/17.
 */
public class Societies_Body_Data {


    private String firstname;
    private String lastname;
    private String username;
    private int year;
    private String dept;
    private String nature;
    private long hours;

    public Societies_Body_Data(String firstname, String lastname, String username, int year, String dept, String nature, long hours){
        this.firstname = firstname;
        this.lastname = lastname;
        this.username = username;
        this.year = year;
        this.dept = dept;
        this.nature = nature;
        this.hours = hours;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public String getNature() {
        return nature;
    }

    public void setNature(String nature) {
        this.nature = nature;
    }

    public long getHours() {
        return hours;
    }

    public void setHours(long hours) {
        this.hours = hours;
    }

}
