package com.StudentPortal.Data;

/**
 * Created by abdul on 2/10/17.
 */
public class SocietyTableData {

    private String start_date;
    private String end_date;
    private int working_hour;
    private int pay;
    private boolean paid;

    public int getPay() {
        return pay;
    }

    public void setPay(int pay) {
        this.pay = pay;
    }

    public boolean isPaid() {
        return paid;
    }

    public void setPaid(boolean paid) {
        this.paid = paid;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String date;

    public SocietyTableData (String start_date, String end_date, int working_hour, int pay, boolean paid){
        this.start_date = start_date;
        this.end_date = end_date;
        this.working_hour = working_hour;
        date = String.valueOf(start_date);
        this.paid = paid;
        this.pay = pay;
    }

    public String getStart_date() {
        return start_date;
    }

    public void setStart_date(String start_date) {
        this.start_date = start_date;
    }

    public String getEnd_date() {
        return end_date;
    }

    public void setEnd_date(String end_date) {
        this.end_date = end_date;
    }

    public int getWorking_hour() {
        return working_hour;
    }

    public void setWorking_hour(int working_hour) {
        this.working_hour = working_hour;
    }
}
