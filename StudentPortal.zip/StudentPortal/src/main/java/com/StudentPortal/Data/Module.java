package com.StudentPortal.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by abdul on 2/17/17.
 */
public class Module {

    private String module_Title;
    private double attendance_Percentage;
    private int semester;
    List<Courses_Sessions> courses_sessions = new ArrayList<>();

    public String getModule_Title() {
        return module_Title;
    }

    public void setModule_Title(String modue_Title) {
        this.module_Title = modue_Title;
    }

    public double getAttendance_Percentage() {
        return attendance_Percentage;
    }

    public void setAttendance_Percentage(double attendance_Percentage) {
        this.attendance_Percentage = attendance_Percentage;
    }

    public int getSemester() {
        return semester;
    }

    public void setSemester(int semester) {
        this.semester = semester;
    }

    public List<Courses_Sessions> getCourses_sessions() {
        return courses_sessions;
    }

    public void setCourses_sessions(List<Courses_Sessions> courses_sessions) {
        this.courses_sessions = courses_sessions;
    }

    public Module(String module_Title, double attendance_Percentage, int semester, List<Courses_Sessions> courses_sessions) {

        this.module_Title = module_Title;
        this.attendance_Percentage = attendance_Percentage;
        this.semester = semester;
        this.courses_sessions = courses_sessions;
    }
}
