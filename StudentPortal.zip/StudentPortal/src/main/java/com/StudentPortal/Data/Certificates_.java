package com.StudentPortal.Data;

/**
 * Created by abdul on 4/17/17.
 */
public class Certificates_ {

    private String request_date;
    private String job_title;
    private String job_nature;
    private String status;
    private String recieved_date;

    public Certificates_(String request_date, String job_title, String job_nature, String status, String recieved_date) {
        this.request_date = request_date;
        this.job_title = job_title;
        this.job_nature = job_nature;
        this.status = status;
        this.recieved_date = recieved_date;
    }


    public String getJob_title() {
        return job_title;
    }

    public void setJob_title(String job_title) {
        this.job_title = job_title;
    }

    public String getJob_nature() {
        return job_nature;
    }

    public void setJob_nature(String job_nature) {
        this.job_nature = job_nature;
    }

    public String getRequest_date() {
        return request_date;
    }

    public void setRequest_date(String request_date) {
        this.request_date = request_date;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getRecieved_date() {
        return recieved_date;
    }

    public void setRecieved_date(String recieved_date) {
        this.recieved_date = recieved_date;
    }
}
