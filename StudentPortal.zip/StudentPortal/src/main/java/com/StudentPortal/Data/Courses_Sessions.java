package com.StudentPortal.Data;

/**
 * Created by abdul on 2/17/17.
 */
public class Courses_Sessions {

    private String time;
    private String date;
    private String status;

    public Courses_Sessions(String time, String date, String status) {
        this.time = time;
        this.date = date;
        this.status = status;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
