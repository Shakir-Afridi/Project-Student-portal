package com.StudentPortal.Data;

/**
 * Created by abdul on 3/29/17.
 */
public class Student_Information {

    private String email_address;
    private String dept;
    private String programe;
    private int enrollment_year;
    private int graduating_year;
    private int currently_enrolled;
    private int pat_id;
    private int fyp_supervisor_id;
    private String address;
    private String phone1;
    private String phone2;
//    private Teachers_Information pat_information;
//    private Teachers_Information supervisor_information;
    private Teachers_Information pat_information;
    private Teachers_Information supervisor_information;

    private String username;
    private String firstname;
    private String lastname;
    private int obtain_markd;

    public Student_Information(String email_address, String dept, String programe, int enrollment_year, int graduating_year, int currently_enrolled, int pat_id, int fyp_supervisor_id,
                                String address, String phone1, String phone2, Teachers_Information pat_information, Teachers_Information supervisor_information) {
        this.email_address = email_address;
        this.dept = dept;
        this.programe = programe;
        this.enrollment_year = enrollment_year;
        this.graduating_year = graduating_year;
        this.currently_enrolled = currently_enrolled;
        this.pat_id = pat_id;
        this.fyp_supervisor_id = fyp_supervisor_id;
        this.address = address;
        this.phone1 = phone1;
        this.phone2 = phone2;
        this.pat_information = pat_information;
        this.supervisor_information = supervisor_information;
    }

    public Student_Information(String username, String firstname, String lastname, int currently_enrolled){
        this.username = username;
        this.firstname = firstname;
        this.lastname = lastname;
        this.currently_enrolled = currently_enrolled;
    }

    public Student_Information(String username, String firstname, String lastname){
        this.username = username;
        this.firstname = firstname;
        this.lastname = lastname;
//        this.currently_enrolled = currently_enrolled;
//        this.pat_id = pat_id;

    }
    public Student_Information(String firstname,String lastname,int obtain_marks){

        this.firstname = firstname;
        this.lastname = lastname;
        this.obtain_markd = obtain_marks;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public int getObtain_markd() {
        return obtain_markd;
    }

    public void setObtain_markd(int obtain_markd) {
        this.obtain_markd = obtain_markd;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone1() {
        return phone1;
    }

    public void setPhone1(String phone1) {
        this.phone1 = phone1;
    }

    public String getPhone2() {
        return phone2;
    }

    public void setPhone2(String phone2) {
        this.phone2 = phone2;
    }

    public Teachers_Information getSupervisor_information() {
        return supervisor_information;
    }

    public void setSupervisor_information(Teachers_Information supervisor_information) {
        this.supervisor_information = supervisor_information;
    }

    public Teachers_Information getPat_information() {
        return pat_information;
    }

    public void setPat_information(Teachers_Information pat_information) {
        this.pat_information = pat_information;
    }

    public String getEmail_address() {
        return email_address;
    }

    public void setEmail_address(String email_address) {
        this.email_address = email_address;
    }

    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public String getPrograme() {
        return programe;
    }

    public void setPrograme(String programe) {
        this.programe = programe;
    }

    public int getEnrollment_year() {
        return enrollment_year;
    }

    public void setEnrollment_year(int enrollment_year) {
        this.enrollment_year = enrollment_year;
    }

    public int getGraduating_year() {
        return graduating_year;
    }

    public void setGraduating_year(int graduating_year) {
        this.graduating_year = graduating_year;
    }

    public int getCurrently_enrolled() {
        return currently_enrolled;
    }

    public void setCurrently_enrolled(int currently_enrolled) {
        this.currently_enrolled = currently_enrolled;
    }

    public int getPat_id() {
        return pat_id;
    }

    public void setPat_id(int pat_id) {
        this.pat_id = pat_id;
    }

    public int getFyp_supervisor_id() {
        return fyp_supervisor_id;
    }

    public void setFyp_supervisor_id(int fyp_supervisor_id) {
        this.fyp_supervisor_id = fyp_supervisor_id;
    }
}
