package com.StudentPortal.Data;

import java.util.ArrayList;

/**
 * Created by abdul on 2/9/17.
 */
public class Societies {

//    private String name;
//    private String nature;
//    private String position;
//    private Date joiningDate;
    private ArrayList<String> allSocieties;

    public ArrayList<String> getAllSocieties() {
        return allSocieties;
    }

    public void setAllSocieties(ArrayList<String> societies) {
        this.allSocieties = societies;
    }
}
