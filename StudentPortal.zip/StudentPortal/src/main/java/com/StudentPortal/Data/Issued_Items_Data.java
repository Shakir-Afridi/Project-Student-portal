package com.StudentPortal.Data;

import java.util.Date;

/**
 * Created by abdul on 4/23/17.
 */
public class Issued_Items_Data {

    private String item;
    private String model;
    private int quantity;
    private String issued_date;
    private String due_date;

    public Issued_Items_Data(String item, String model, int quantity, String issued_date, String due_date) {
        this.item = item;
        this.model = model;
        this.quantity = quantity;
        this.issued_date = issued_date;
        this.due_date = due_date;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getIssued_date() {
        return issued_date;
    }

    public void setIssued_date(String issued_date) {
        this.issued_date = issued_date;
    }

    public String getDue_date() {
        return due_date;
    }

    public void setDue_date(String due_date) {
        this.due_date = due_date;
    }
}
