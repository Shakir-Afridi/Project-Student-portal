package com.StudentPortal.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by abdul on 4/21/17.
 */
public class User_Issued_Items_Information {

    private int item_id;
    private String full_name;
    private String user_name;
    private String email;
    private String item;
    private int quantity;
    private String issued_date;
    private String due_date;

    private List<Item> items_detail = new ArrayList<>();

    public User_Issued_Items_Information(int item_id, String full_name, String user_name, String email, String item, int quantity, String issued_date, String due_date) {
        this.item_id = item_id;
        this.full_name = full_name;
        this.user_name = user_name;
        this.email = email;
        this.item = item;
        this.quantity = quantity;
        this.issued_date = issued_date;
        this.due_date = due_date;
    }

    public int getItem_id() {
        return item_id;
    }

    public void setItem_id(int item_id) {
        this.item_id = item_id;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getFull_name() {
        return full_name;
    }

    public void setFull_name(String full_name) {
        this.full_name = full_name;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getIssued_date() {
        return issued_date;
    }

    public void setIssued_date(String issued_date) {
        this.issued_date = issued_date;
    }

    public String getDue_date() {
        return due_date;
    }

    public void setDue_date(String due_date) {
        this.due_date = due_date;
    }

    public List<Item> getItems_detail() {
        return items_detail;
    }

    public void setItems_detail(List<Item> items_detail) {
        this.items_detail = items_detail;
    }
}
