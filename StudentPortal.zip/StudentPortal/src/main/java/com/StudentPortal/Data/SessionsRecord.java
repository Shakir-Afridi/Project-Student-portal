package com.StudentPortal.Data;

/**
 * Created by abdul on 2/14/17.
 */
public class SessionsRecord {

    private int session_number;
    private String session_date;
    private String session_status;

    public SessionsRecord(int session_number, String session_date, String session_status) {
        this.session_number = session_number;
        this.session_date = session_date;
        this.session_status = session_status;
    }

    public int getSession_number() {
        return session_number;
    }

    public void setSession_number(int session_number) {
        this.session_number = session_number;
    }

    public String getSession_date() {
        return session_date;
    }

    public void setSession_date(String session_date) {
        this.session_date = session_date;
    }

    public String getSession_status() {
        return session_status;
    }

    public void setSession_status(String session_status) {
        this.session_status = session_status;
    }
}
