package com.StudentPortal.model.papercutds;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by abdul on 4/21/17.
 */
@Entity
@Table (name = "tbl_user", schema = "papercut")
public class Tbl_User {


    @Id
    @Column (name = "user_id")
    @GeneratedValue (generator = "increment")
    @GenericGenerator (name = "increment", strategy = "increment")
    private int user_id;

    @Column (name = "user_name")
    private String user_name;

    @Column (name = "external_user_name")
    private String external_user_name;

    @Column (name = "full_name")
    private String full_name;

    @Column (name = "email")
    private String email;

    @Column (name = "notes")
    private String notes;

    @Column (name = "total_jobs")
    private int total_jobs;

    @Column (name = "total_pages")
    private int total_pages;

    @Column (name = "total_sheets")
    private int total_sheets;

    @Column (name = "reset_by")
    private String reset_by;

    @Column (name = "reset_date")
    private Date reset_date;

    @Column (name = "deleted")
    private boolean deleted;

    @Column (name = "deleted_date")
    private Date deleted_date;

    @Column (name = "created_date")
    private Date created_date;

    @Column (name = "created_by")
    private String created_by;

    @Column (name = "modified_date")
    private Date modified_date;

    @Column (name = "modified_by")
    private String modified_by;

    @Column (name = "department")
    private String department;

    @Column (name = "office")
    private String office;

    @Column (name = "card_number")
    private String card_number;

    @Column (name = "disabled_printing")
    private boolean disabled_printing;

    @Column (name = "disabled_printing_by")
    private Date disabled_printing_by;

    @Column (name = "net_reset_by")
    private String net_reset_by;

    @Column (name = "net_reset_date")
    private Date net_reset_date;

    @Column (name = "net_total_megabytes")
    private double net_total_megabytes;

    @Column (name = "net_total_time_hours")
    private double net_total_time_hours;

    @Column (name = "disabled_net")
    private boolean disabled_net;

    @Column (name = "disabled_net_until")
    private Date disabled_net_until;

    @Column (name = "internal")
    private boolean internal;

    @Column (name = "last_user_activity")
    private Date last_user_activity;

    @Column (name = "card_number2")
    private String card_number2;

    public Tbl_User(String user_name, String external_user_name, String full_name, String email, String notes, int total_jobs, int total_pages, int total_sheets, String reset_by, Date reset_date, boolean deleted, Date deleted_date, Date created_date, String created_by, Date modified_date, String modified_by, String department, String office, String card_number, boolean disabled_printing, Date disabled_printing_by, String net_reset_by, Date net_reset_date, double net_total_megabytes, double net_total_time_hours, boolean disabled_net, Date disabled_net_until, boolean internal, Date last_user_activity, String card_number2) {
        this.user_name = user_name;
        this.external_user_name = external_user_name;
        this.full_name = full_name;
        this.email = email;
        this.notes = notes;
        this.total_jobs = total_jobs;
        this.total_pages = total_pages;
        this.total_sheets = total_sheets;
        this.reset_by = reset_by;
        this.reset_date = reset_date;
        this.deleted = deleted;
        this.deleted_date = deleted_date;
        this.created_date = created_date;
        this.created_by = created_by;
        this.modified_date = modified_date;
        this.modified_by = modified_by;
        this.department = department;
        this.office = office;
        this.card_number = card_number;
        this.disabled_printing = disabled_printing;
        this.disabled_printing_by = disabled_printing_by;
        this.net_reset_by = net_reset_by;
        this.net_reset_date = net_reset_date;
        this.net_total_megabytes = net_total_megabytes;
        this.net_total_time_hours = net_total_time_hours;
        this.disabled_net = disabled_net;
        this.disabled_net_until = disabled_net_until;
        this.internal = internal;
        this.last_user_activity = last_user_activity;
        this.card_number2 = card_number2;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getExternal_user_name() {
        return external_user_name;
    }

    public void setExternal_user_name(String external_user_name) {
        this.external_user_name = external_user_name;
    }

    public String getFull_name() {
        return full_name;
    }

    public void setFull_name(String full_name) {
        this.full_name = full_name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public int getTotal_jobs() {
        return total_jobs;
    }

    public void setTotal_jobs(int total_jobs) {
        this.total_jobs = total_jobs;
    }

    public int getTotal_pages() {
        return total_pages;
    }

    public void setTotal_pages(int total_pages) {
        this.total_pages = total_pages;
    }

    public int getTotal_sheets() {
        return total_sheets;
    }

    public void setTotal_sheets(int total_sheets) {
        this.total_sheets = total_sheets;
    }

    public String getReset_by() {
        return reset_by;
    }

    public void setReset_by(String reset_by) {
        this.reset_by = reset_by;
    }

    public Date getReset_date() {
        return reset_date;
    }

    public void setReset_date(Date reset_date) {
        this.reset_date = reset_date;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    public Date getDeleted_date() {
        return deleted_date;
    }

    public void setDeleted_date(Date deleted_date) {
        this.deleted_date = deleted_date;
    }

    public Date getCreated_date() {
        return created_date;
    }

    public void setCreated_date(Date created_date) {
        this.created_date = created_date;
    }

    public String getCreated_by() {
        return created_by;
    }

    public void setCreated_by(String created_by) {
        this.created_by = created_by;
    }

    public Date getModified_date() {
        return modified_date;
    }

    public void setModified_date(Date modified_date) {
        this.modified_date = modified_date;
    }

    public String getModified_by() {
        return modified_by;
    }

    public void setModified_by(String modified_by) {
        this.modified_by = modified_by;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getOffice() {
        return office;
    }

    public void setOffice(String office) {
        this.office = office;
    }

    public String getCard_number() {
        return card_number;
    }

    public void setCard_number(String card_number) {
        this.card_number = card_number;
    }

    public boolean isDisabled_printing() {
        return disabled_printing;
    }

    public void setDisabled_printing(boolean disabled_printing) {
        this.disabled_printing = disabled_printing;
    }

    public Date getDisabled_printing_by() {
        return disabled_printing_by;
    }

    public void setDisabled_printing_by(Date disabled_printing_by) {
        this.disabled_printing_by = disabled_printing_by;
    }

    public String getNet_reset_by() {
        return net_reset_by;
    }

    public void setNet_reset_by(String net_reset_by) {
        this.net_reset_by = net_reset_by;
    }

    public Date getNet_reset_date() {
        return net_reset_date;
    }

    public void setNet_reset_date(Date net_reset_date) {
        this.net_reset_date = net_reset_date;
    }

    public double getNet_total_megabytes() {
        return net_total_megabytes;
    }

    public void setNet_total_megabytes(double net_total_megabytes) {
        this.net_total_megabytes = net_total_megabytes;
    }

    public double getNet_total_time_hours() {
        return net_total_time_hours;
    }

    public void setNet_total_time_hours(double net_total_time_hours) {
        this.net_total_time_hours = net_total_time_hours;
    }

    public boolean isDisabled_net() {
        return disabled_net;
    }

    public void setDisabled_net(boolean disabled_net) {
        this.disabled_net = disabled_net;
    }

    public Date getDisabled_net_until() {
        return disabled_net_until;
    }

    public void setDisabled_net_until(Date disabled_net_until) {
        this.disabled_net_until = disabled_net_until;
    }

    public boolean isInternal() {
        return internal;
    }

    public void setInternal(boolean internal) {
        this.internal = internal;
    }

    public Date getLast_user_activity() {
        return last_user_activity;
    }

    public void setLast_user_activity(Date last_user_activity) {
        this.last_user_activity = last_user_activity;
    }

    public String getCard_number2() {
        return card_number2;
    }

    public void setCard_number2(String card_number2) {
        this.card_number2 = card_number2;
    }
}
