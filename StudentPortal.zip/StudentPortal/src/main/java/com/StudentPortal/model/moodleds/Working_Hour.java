package com.StudentPortal.model.moodleds;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by abdul on 2/2/17.
 */

@Entity
@Table (name = "working_hour", schema = "moodle")
public class Working_Hour implements Serializable{

    @Id
    @Column (name = "id")
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    private int id;

    @Column (name = "username")
    private String username;

    @Column (name = "j_id")
    private int job;

    @Column (name = "to_date")
    private Date to_date;

    @Column (name = "from_date")
    private Date from_date;

    @Column (name = "hours")
    private int hours;

    @Column (name = "pay")
    private int pay;

    @Column (name = "paid")
    private boolean paid;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username= username;
    }

    public int getJob() {
        return job;
    }

    public void setJob(int job) {
        this.job = job;
    }

    public Date getTo_date() {
        return to_date;
    }

    public void setTo_date(Date to_date) {
        this.to_date = to_date;
    }

    public Date getFrom_date() {
        return from_date;
    }

    public void setFrom_date(Date from_date) {
        this.from_date = from_date;
    }

    public int gethours() {
        return hours;
    }

    public void sethours(int working_hours) {
        this.hours = working_hours;
    }

    public int getPay() {
        return pay;
    }

    public void setPay(int pay) {
        this.pay = pay;
    }

    public boolean isPaid() {
        return paid;
    }

    public void setPaid(boolean paid) {
        this.paid = paid;
    }

    public Working_Hour(String username, int job, Date to_date, Date from_date, int working_hours, int pay, boolean paid) {

        this.username = username;
        this.job = job;
        this.to_date = to_date;
        this.from_date = from_date;
        this.hours = working_hours;
        this.pay = pay;
        this.paid = paid;
    }
}
