package com.StudentPortal.model.moodleds;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by abdul on 2/11/17.
 */

@Entity
@Table (name = "mdl_user_enrolments", schema = "moodle")
public class MDL_User_Enrollments implements Serializable {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "id")
    private int id;

    @Column (name = "status")
    private int status;

    @Column (name = "enrolid")
    private int enrolid;

    @Column (name = "userid")
    private int userid;

    @Column (name = "timestart")
    private int timestart;

    @Column (name = "timeend")
    private int timeend;

    @Column (name = "modifierid")
    private int modifierid;

    @Column (name = "timecreated")
    private int timecreated;

    @Column (name = "timemodified")
    private int timemodified;

    public MDL_User_Enrollments(int status, int enrolid, int userid, int timestart, int timeend, int modifierid, int timecreated, int timemodified) {
        this.status = status;
        this.enrolid = enrolid;
        this.userid = userid;
        this.timestart = timestart;
        this.timeend = timeend;
        this.modifierid = modifierid;
        this.timecreated = timecreated;
        this.timemodified = timemodified;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getEnrolid() {
        return enrolid;
    }

    public void setEnrolid(int enrolid) {
        this.enrolid = enrolid;
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public int getTimestart() {
        return timestart;
    }

    public void setTimestart(int timestart) {
        this.timestart = timestart;
    }

    public int getTimeend() {
        return timeend;
    }

    public void setTimeend(int timeend) {
        this.timeend = timeend;
    }

    public int getModifierid() {
        return modifierid;
    }

    public void setModifierid(int modifierid) {
        this.modifierid = modifierid;
    }

    public int getTimecreated() {
        return timecreated;
    }

    public void setTimecreated(int timecreated) {
        this.timecreated = timecreated;
    }

    public int getTimemodified() {
        return timemodified;
    }

    public void setTimemodified(int timemodified) {
        this.timemodified = timemodified;
    }
}
