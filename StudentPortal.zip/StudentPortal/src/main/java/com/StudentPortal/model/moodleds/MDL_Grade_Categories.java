package com.StudentPortal.model.moodleds;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.*;

/**
 * Created by abdul on 2/2/17.
 */

//@GeneratedValue(generator = "increment")
//@GenericGenerator(name = "increment", strategy = "increment")

@Entity
@Table(name = "mdl_grade_categories", schema = "moodle")
public class MDL_Grade_Categories {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "id")
    private int id;

    @Column(name = "courseid")
    private int courseid;

    @Column(name = "parent")
    private int parent;

    @Column(name = "depth")
    private int depth;

    @Column(name = "path")
    private String path;

    @Column(name = "fullname")
    private String fullname;

    @Column(name = "aggragation")
    private int aggregation;

    @Column(name = "keephigh")
    private int keephigh;

    @Column(name = "droplow")
    private int droplow;

    @Column(name = "aggregateonlygraded")
    private int aggregateonlygraded;

    @Column(name = "aggregateoutcomes")
    private int aggregateoutcomes;

    @Column(name = "timecreated")
    private int timecreated;

    @Column(name = "timemodified")
    private int timemodified;

    @Column(name = "hidden")
    private int hidden;

    @Column(name = "weightage")
    private int weightage;

    public MDL_Grade_Categories(int courseid, int parent, int depth, String path, String fullname, int aggregation, int keephigh, int droplow, int aggregateonlygraded, int aggregateoutcomes, int timecreated, int timemodified, int hidden, int weightage) {
        this.courseid = courseid;
        this.weightage = weightage;
        this.parent = parent;
        this.depth = depth;
        this.path = path;
        this.fullname = fullname;
        this.aggregation = aggregation;
        this.keephigh = keephigh;
        this.droplow = droplow;
        this.aggregateonlygraded = aggregateonlygraded;
        this.aggregateoutcomes = aggregateoutcomes;
        this.timecreated = timecreated;
        this.timemodified = timemodified;
        this.hidden = hidden;
    }

    public int getWeightage() {
        return weightage;
    }

    public void setWeightage(int weightage) {
        this.weightage = weightage;
    }

    public int getCourseid() {
        return courseid;
    }

    public void setCourseid(int courseid) {
        this.courseid = courseid;
    }

    public int getParent() {
        return parent;
    }

    public void setParent(int parent) {
        this.parent = parent;
    }

    public int getDepth() {
        return depth;
    }

    public void setDepth(int depth) {
        this.depth = depth;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public int getAggregation() {
        return aggregation;
    }

    public void setAggregation(int aggregation) {
        this.aggregation = aggregation;
    }

    public int getKeephigh() {
        return keephigh;
    }

    public void setKeephigh(int keephigh) {
        this.keephigh = keephigh;
    }

    public int getDroplow() {
        return droplow;
    }

    public void setDroplow(int droplow) {
        this.droplow = droplow;
    }

    public int getAggregateonlygraded() {
        return aggregateonlygraded;
    }

    public void setAggregateonlygraded(int aggregateonlygraded) {
        this.aggregateonlygraded = aggregateonlygraded;
    }

    public int getAggregateoutcomes() {
        return aggregateoutcomes;
    }

    public void setAggregateoutcomes(int aggregateoutcomes) {
        this.aggregateoutcomes = aggregateoutcomes;
    }

    public int getTimecreated() {
        return timecreated;
    }

    public void setTimecreated(int timecreated) {
        this.timecreated = timecreated;
    }

    public int getTimemodified() {
        return timemodified;
    }

    public void setTimemodified(int timemodified) {
        this.timemodified = timemodified;
    }

    public int getHidden() {
        return hidden;
    }

    public void setHidden(int hidden) {
        this.hidden = hidden;
    }
}