package com.StudentPortal.model.moodleds;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by abdul on 2/24/17.
 */

@Entity
@Table (name = "message_reply", schema = "moodle")
public class Messages_Reply {

    @Id
    @Column (name = "reply_id")
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    private int reply_id;

    @Column (name = "thread_id")
    private int thread_id;

    @Column(name = "sender_emailid")
    private String sender_emailid;

    @Column (name = "sender_name")
    private String sender_name;

    @Column (name = "receiver_name")
    private String receiver_name;

    @Column (name = "reciever_emailid")
    private String reciever_emailid;

    @Column (name = "date")
    private Date date;

    @Column (name = "time")
    private String time;

    @Column (name = "message")
    private String message;

    @Column (name = "read_unread")
    private boolean read_unread;

    public Messages_Reply(int thread_id, String sender_emailid, String sender_name, String receiver_name, String reciever_id, Date date, String time, String message, boolean read_unread) {
        this.thread_id = thread_id;
        this.sender_emailid = sender_emailid;
        this.sender_name = sender_name;
        this.receiver_name = receiver_name;
        this.reciever_emailid = reciever_id;
        this.date = date;
        this.time = time;
        this.message = message;
        this.read_unread = read_unread;
    }

    public int getReply_id(){
        return reply_id;
    }

    public String getReceiver_name() {
        return receiver_name;
    }

    public void setReceiver_name(String receiver_name) {
        this.receiver_name = receiver_name;
    }

    public int getThread_id() {
        return thread_id;
    }

    public void setThread_id(int thread_id) {
        this.thread_id = thread_id;
    }

    public String getSender_name() {
        return sender_name;
    }

    public void setSender_name(String sender_name) {
        this.sender_name = sender_name;
    }

    public String getReciever_emailid() {
        return reciever_emailid;
    }

    public void setReciever_emailid(String reciever_emailid) {
        this.reciever_emailid = reciever_emailid;
    }

    public String getSender_emailid() {
        return sender_emailid;
    }

    public void setSender_emailid(String sender_emailid) {
        this.sender_emailid = sender_emailid;
    }

    public String getReciever_id() {
        return reciever_emailid;
    }

    public void setReciever_id(String reciever_id) {
        this.reciever_emailid = reciever_id;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isRead_unread() {
        return read_unread;
    }

    public void setRead_unread(boolean read_unread) {
        this.read_unread = read_unread;
    }
}
