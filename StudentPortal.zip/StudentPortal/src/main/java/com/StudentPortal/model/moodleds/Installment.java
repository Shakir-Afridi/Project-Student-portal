package com.StudentPortal.model.moodleds;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlAccessorOrder;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by Shakir Afridi on 2/20/17.
 */
@Entity
@Table(name = "installments", schema = "moodle")

public class Installment implements Serializable{

    @Id
    @Column (name = "i_id")
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    private int id;

    @Column (name = "rollno")
    private String rollno;

    @Column (name = "amount")
    private int amount;

    @Column (name = "paid_on")
    private Date paid_on;

    @Column (name = "fee_id")
    private int fee_id;

    @Column (name = "due_for")
    private String due_for;

//    @Transient
//    private String stringinstallement_type;

    public Installment(int fee_id, String rollno, Date paid_on, int amount){
        // this.paid_on = paid_on;
        this.amount = amount;
        this.rollno = rollno;
        this.fee_id = fee_id;
    }

    public String getDue_for() {
        return due_for;
    }

    public void setDue_for(String due_for) {
        this.due_for = due_for;
    }

    public int getFee_id() {
        return fee_id;
    }

    public void setFee_id(int fee_id) {
        this.fee_id = fee_id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAmount() {
        return amount;
    }

    public String getRollno() {
        return rollno;
    }

    public void setRollno(String rollno) {
        this.rollno = rollno;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public Date getPaid_on() {
        return paid_on;
    }

    public void setPaid_on(Date paid_on) {
        this.paid_on = paid_on;
    }
}