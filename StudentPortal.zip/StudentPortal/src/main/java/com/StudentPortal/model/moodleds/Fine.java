package com.StudentPortal.model.moodleds;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by Shakir Afridi on 2/17/17.
 */
@Entity
@Table (name = "fine")
public class Fine implements Serializable{

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column (name = "f_id")
    private int f_id;

    @Column (name = "rollno")
    private String rollno;

    @Column (name = "submission_date")
    private Date submission_date;

    @Column (name = "due_date")
    private Date due_date;

    @Column (name = "fining_authority")
    private String fining_authority;

    @Column (name = "amount")
    private int amount;

    @Transient
    private String submissiondateString;

    @Transient
    private String duedateString;


    public Fine (int f_id, String rollno, Date submission_date, Date due_date, String fining_authority, int amount){
        this.f_id = f_id;
        this.rollno = rollno;
//        this.submission_date = submission_date;
//        this.due_date = due_date;
        this.fining_authority = fining_authority;
        this.amount = amount;
        this.submissiondateString = String.valueOf(submission_date).split(" ")[0];
        this.duedateString = String.valueOf(due_date).split(" ")[0];

    }


    public String getSubmissiondateString() {
        return submissiondateString;
    }

    public void setSubmissiondateString(String submissiondateString) {
        this.submissiondateString = submissiondateString;
    }

    public String getDuedateString() {
        return duedateString;
    }

    public void setDuedateString(String duedateString) {
        this.duedateString = duedateString;
    }

    public int getF_id() {
        return f_id;
    }

    public void setF_id(int f_id) {
        this.f_id = f_id;
    }

    public String getRollno() {
        return rollno;
    }

    public void setRollno(String rollno) {
        this.rollno = rollno;
    }

    public Date getSubmission_date() {
        return submission_date;
    }

    public void setSubmission_date(Date submission_date) {
        this.submission_date = submission_date;
    }

    public Date getDue_date() {
        return due_date;
    }

    public void setDue_date(Date due_date) {
        this.due_date = due_date;
    }

    public String getFining_authority() {
        return fining_authority;
    }

    public void setFining_authority(String fining_authority) {
        this.fining_authority = fining_authority;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }
}