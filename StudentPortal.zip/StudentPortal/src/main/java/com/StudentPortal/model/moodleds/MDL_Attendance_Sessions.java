package com.StudentPortal.model.moodleds;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by abdul on 3/28/17.
 */
@Entity
@Table(name = "mdl_attendance_sessions", schema = "moodle")
public class MDL_Attendance_Sessions implements Serializable{

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "id")
    private int id;

    @Column(name = "groupid")
    private int groupid;

    @Column(name = "sessdate")
    private int sessdate;

    @Column(name = "duration")
    private int duration;

    @Column(name = "lasttaken")
    private int lasttaken;

    @Column(name = "lasttakenby")
    private int lasttakenby;

    @Column(name = "timemodified")
    private int timemodified;

    @Column(name = "description")
    private String description;

    @Column(name = "attendanceid")
    private int attendanceid;

    @Column(name = "descriptionformat")
    private int descriptionformat;

    @Column(name = "studentscanmark")
    private int studentcanmark;

    @Column(name = "statusset")
    private int statusset;

    @Column(name = "caleventid")
    private int caleventid;

    public MDL_Attendance_Sessions(int groupid, int sessdate, int duration, int lasttaken, int lasttakenby, int timemodified, String description, int attendanceid, int descriptionformat, int studentcanmark, int statusset, int caleventid) {

        this.groupid = groupid;
        this.sessdate = sessdate;
        this.duration = duration;
        this.lasttaken = lasttaken;
        this.lasttakenby = lasttakenby;
        this.timemodified = timemodified;
        this.description = description;
        this.attendanceid = attendanceid;
        this.descriptionformat = descriptionformat;
        this.studentcanmark = studentcanmark;
        this.statusset = statusset;
        this.caleventid = caleventid;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getGroupid() {
        return groupid;
    }

    public void setGroupid(int groupid) {
        this.groupid = groupid;
    }

    public int getSessdate() {
        return sessdate;
    }

    public void setSessdate(int sessdate) {
        this.sessdate = sessdate;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public int getLasttaken() {
        return lasttaken;
    }

    public void setLasttaken(int lasttaken) {
        this.lasttaken = lasttaken;
    }

    public int getLasttakenby() {
        return lasttakenby;
    }

    public void setLasttakenby(int lasttakenby) {
        this.lasttakenby = lasttakenby;
    }

    public int getTimemodified() {
        return timemodified;
    }

    public void setTimemodified(int timemodified) {
        this.timemodified = timemodified;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getAttendanceid() {
        return attendanceid;
    }

    public void setAttendanceid(int attendanceid) {
        this.attendanceid = attendanceid;
    }

    public int getDescriptionformat() {
        return descriptionformat;
    }

    public void setDescriptionformat(int descriptionformat) {
        this.descriptionformat = descriptionformat;
    }

    public int getStudentcanmark() {
        return studentcanmark;
    }

    public void setStudentcanmark(int studentcanmark) {
        this.studentcanmark = studentcanmark;
    }

    public int getStatusset() {
        return statusset;
    }

    public void setStatusset(int statusset) {
        this.statusset = statusset;
    }

    public int getCaleventid() {
        return caleventid;
    }

    public void setCaleventid(int caleventid) {
        this.caleventid = caleventid;
    }
}
