package com.StudentPortal.model.moodleds;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by abdul on 3/28/17.
 */
@Entity
@Table(name = "mdl_attendance", schema = "moodle")
public class MDL_Attendance implements Serializable {
    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "id")
    private int id;

    @Column(name = "course")
    private int course;


    @Column(name = "name")
    private String name;

    @Column(name = "grade")
    private int grade;

    @Column(name = "timemodified")
    private int timemodified;

    @Column(name = "subnet")
    private int subnet;

    @Column(name = "sessiondetailspos")
    private String sessiondetailspos;

    @Column(name = "showsessiondetails")
    private int showsessiondetails;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCourse() {
        return course;
    }

    public void setCourse(int course) {
        this.course = course;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getGrade() {
        return grade;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }

    public int getTimemodified() {
        return timemodified;
    }

    public void setTimemodified(int timemodified) {
        this.timemodified = timemodified;
    }

    public int getSubnet() {
        return subnet;
    }

    public void setSubnet(int subnet) {
        this.subnet = subnet;
    }

    public String getSessiondetailspos() {
        return sessiondetailspos;
    }

    public void setSessiondetailspos(String sessiondetailspos) {
        this.sessiondetailspos = sessiondetailspos;
    }

    public int getShowsessiondetails() {
        return showsessiondetails;
    }

    public void setShowsessiondetails(int showsessiondetails) {
        this.showsessiondetails = showsessiondetails;
    }

    public MDL_Attendance(int course, String name, int grade, int timemodified, int subnet, String sessiondetailspos, int showsessiondetails) {
        this.course = course;
        this.name = name;
        this.grade = grade;
        this.timemodified = timemodified;
        this.subnet = subnet;
        this.sessiondetailspos = sessiondetailspos;
        this.showsessiondetails = showsessiondetails;
    }
}
