package com.StudentPortal.model.moodleds;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

/**
 * Created by abdul on 3/7/17.
 */
@Entity
@Table(name = "mdl_user", schema = "moodle")
public class MDL_User {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "id")
    private int id;

    @Column(name = "auth")
    private String auth;

    @Column(name = "confirmed")
    private int confirmed;

    @Column(name = "policyagreed")
    private int policyagreed;

    @Column(name = "deleted")
    private int delted;

    @Column(name = "suspended")
    private int suspended;

    @Column(name = "mnethostid")
    private int mnethostid;

    @Column(name = "username")
    private String username;

    @Column(name = "password")
    private String password;

    @Column(name = "idnumber")
    private int idnumber;

    @Column(name = "firstname")
    private String firstname;

    @Column(name = "lastname")
    private String lastname;

    @Column(name = "email")
    private String email;

    @Column(name = "emailstop")
    private int emailstop;

    @Column(name = "icq")
    private String icq;

    @Column(name = "skype")
    private String skype;

    @Column(name = "yahoo")
    private String yahoo;

    @Column(name = "aim")
    private String aim;

    @Column(name = "msn")
    private String msn;

    @Column(name = "phone1")
    private String phone1;

    @Column(name = "phone2")
    private String phone2;

    @Column(name = "institution")
    private String institution;

    @Column(name = "department")
    private String department;

    @Column(name = "address")
    private String address;

    @Column(name = "city")
    private String city;

    @Column(name = "country")
    private String country;

    @Column(name = "lang")
    private String lang;

    @Column(name = "calendartype")
    private String calendartype;

    @Column(name = "theme")
    private String theme;

    @Column(name = "timezone")
    private String timezone;

    @Column(name = "firstaccess")
    private int firstaccess;

    @Column(name = "lastaccess")
    private int lastaccess;

    @Column(name = "lastlogin")
    private int lastlogin;

    @Column(name = "currentlogin")
    private int currentlogin;

    @Column(name = "lastip")
    private String lastip;

    @Column(name = "secret")
    private String secret;

    @Column(name = "picture")
    private int picture;

    @Column(name = "url")
    private String url;

    @Column(name = "description")
    private String description;

    @Column(name = "descriptionformat")
    private int descriptionformat;

    @Column(name = "mailformat")
    private int mailformat;

    @Column(name = "maildigest")
    private int maildigest;

    @Column(name = "maildisplay")
    private int maildisplay;

    @Column(name = "autosubscribe")
    private int autosubscribe;

    @Column(name = "trackforums")
    private int trackforums;

    @Column(name = "timecreated")
    private int timecreated;

    @Column(name = "timemodified")
    private int timemodified;

    @Column(name = "trustbitmask")
    private int trustbitmask;

    @Column(name = "imagealt")
    private String imagealt;

    @Column(name = "lastnamephonetic")
    private String lastnamephonetic;

    @Column(name = "firstnamephonetic")
    private String firstnamephonetic;

    @Column(name = "middlename")
    private String middlename;

    @Column(name = "alternatename")
    private String alternatename;

    @Column(name = "status")
    private boolean status;

    @Column(name = "enrolmentyear")
    private int enrollmentYear;

    @Column(name = "graduating_year")
    private int graduating_year;

    @Column(name = "currentlyenrolled")
    private int currently_enrolled;

    @Column(name = "pat")
    private int pat;

    @Column(name = "fypsupervisor")
    private int fyp_supervisor;

    public MDL_User(String auth, int confirmed, int policyagreed, int delted, int suspended, int mnethostid, String username, String password, int idnumber, String firstname, String lastname, String email, int emailstop, String icq, String skype, String yahoo, String aim, String msn, String phone1, String phone2, String institution, String department, String address, String city, String country, String lang, String calendartype, String theme, String timezone, int firstaccess, int lastaccess, int lastlogin, int currentlogin, String lastip, String secret, int picture, String url, String description, int descriptionformat, int mailformat, int maildigest, int maildisplay, int autosubscribe, int trackforums, int timecreated, int timemodified, int trustbitmask, String imagealt, String lastnamephonetic, String firstnamephonetic, String middlename, String alternatename, boolean status, int enrollmentYear, int currently_enrolled, int pat, int fyp_supervisor, int graduating_year) {
        this.auth = auth;
        this.confirmed = confirmed;
        this.policyagreed = policyagreed;
        this.delted = delted;
        this.suspended = suspended;
        this.mnethostid = mnethostid;
        this.username = username;
        this.password = password;
        this.idnumber = idnumber;
        this.firstname = firstname;
        this.lastname = lastname;
        this.email = email;
        this.emailstop = emailstop;
        this.icq = icq;
        this.skype = skype;
        this.yahoo = yahoo;
        this.aim = aim;
        this.msn = msn;
        this.phone1 = phone1;
        this.phone2 = phone2;
        this.institution = institution;
        this.department = department;
        this.address = address;
        this.city = city;
        this.country = country;
        this.lang = lang;
        this.calendartype = calendartype;
        this.theme = theme;
        this.timezone = timezone;
        this.firstaccess = firstaccess;
        this.lastaccess = lastaccess;
        this.lastlogin = lastlogin;
        this.currentlogin = currentlogin;
        this.lastip = lastip;
        this.secret = secret;
        this.picture = picture;
        this.url = url;
        this.description = description;
        this.descriptionformat = descriptionformat;
        this.mailformat = mailformat;
        this.maildigest = maildigest;
        this.maildisplay = maildisplay;
        this.autosubscribe = autosubscribe;
        this.trackforums = trackforums;
        this.timecreated = timecreated;
        this.timemodified = timemodified;
        this.trustbitmask = trustbitmask;
        this.imagealt = imagealt;
        this.lastnamephonetic = lastnamephonetic;
        this.firstnamephonetic = firstnamephonetic;
        this.middlename = middlename;
        this.alternatename = alternatename;
        this.status = status;
        this.enrollmentYear = enrollmentYear;
        this.graduating_year = graduating_year;
        this.currently_enrolled = currently_enrolled;
        this.pat = pat;
        this.fyp_supervisor = fyp_supervisor;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAuth() {
        return auth;
    }

    public void setAuth(String auth) {
        this.auth = auth;
    }

    public int getConfirmed() {
        return confirmed;
    }

    public void setConfirmed(int confirmed) {
        this.confirmed = confirmed;
    }

    public int getPolicyagreed() {
        return policyagreed;
    }

    public void setPolicyagreed(int policyagreed) {
        this.policyagreed = policyagreed;
    }

    public int getDelted() {
        return delted;
    }

    public void setDelted(int delted) {
        this.delted = delted;
    }

    public int getSuspended() {
        return suspended;
    }

    public void setSuspended(int suspended) {
        this.suspended = suspended;
    }

    public int getMnethostid() {
        return mnethostid;
    }

    public void setMnethostid(int mnethostid) {
        this.mnethostid = mnethostid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getIdnumber() {
        return idnumber;
    }

    public void setIdnumber(int idnumber) {
        this.idnumber = idnumber;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getEmailstop() {
        return emailstop;
    }

    public void setEmailstop(int emailstop) {
        this.emailstop = emailstop;
    }

    public String getIcq() {
        return icq;
    }

    public void setIcq(String icq) {
        this.icq = icq;
    }

    public String getSkype() {
        return skype;
    }

    public void setSkype(String skype) {
        this.skype = skype;
    }

    public String getYahoo() {
        return yahoo;
    }

    public void setYahoo(String yahoo) {
        this.yahoo = yahoo;
    }

    public String getAim() {
        return aim;
    }

    public void setAim(String aim) {
        this.aim = aim;
    }

    public String getMsn() {
        return msn;
    }

    public void setMsn(String msn) {
        this.msn = msn;
    }

    public String getPhone1() {
        return phone1;
    }

    public void setPhone1(String phone1) {
        this.phone1 = phone1;
    }

    public String getPhone2() {
        return phone2;
    }

    public void setPhone2(String phone2) {
        this.phone2 = phone2;
    }

    public String getInstitution() {
        return institution;
    }

    public void setInstitution(String institution) {
        this.institution = institution;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getLang() {
        return lang;
    }

    public void setLang(String lang) {
        this.lang = lang;
    }

    public String getCalendartype() {
        return calendartype;
    }

    public void setCalendartype(String calendartype) {
        this.calendartype = calendartype;
    }

    public String getTheme() {
        return theme;
    }

    public void setTheme(String theme) {
        this.theme = theme;
    }

    public String getTimezone() {
        return timezone;
    }

    public void setTimezone(String timezone) {
        this.timezone = timezone;
    }

    public int getFirstaccess() {
        return firstaccess;
    }

    public void setFirstaccess(int firstaccess) {
        this.firstaccess = firstaccess;
    }

    public int getLastaccess() {
        return lastaccess;
    }

    public void setLastaccess(int lastaccess) {
        this.lastaccess = lastaccess;
    }

    public int getLastlogin() {
        return lastlogin;
    }

    public void setLastlogin(int lastlogin) {
        this.lastlogin = lastlogin;
    }

    public int getCurrentlogin() {
        return currentlogin;
    }

    public void setCurrentlogin(int currentlogin) {
        this.currentlogin = currentlogin;
    }

    public String getLastip() {
        return lastip;
    }

    public void setLastip(String lastip) {
        this.lastip = lastip;
    }

    public String getSecret() {
        return secret;
    }

    public void setSecret(String secret) {
        this.secret = secret;
    }

    public int getPicture() {
        return picture;
    }

    public void setPicture(int picture) {
        this.picture = picture;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getDescriptionformat() {
        return descriptionformat;
    }

    public void setDescriptionformat(int descriptionformat) {
        this.descriptionformat = descriptionformat;
    }

    public int getMailformat() {
        return mailformat;
    }

    public void setMailformat(int mailformat) {
        this.mailformat = mailformat;
    }

    public int getMaildigest() {
        return maildigest;
    }

    public void setMaildigest(int maildigest) {
        this.maildigest = maildigest;
    }

    public int getMaildisplay() {
        return maildisplay;
    }

    public void setMaildisplay(int maildisplay) {
        this.maildisplay = maildisplay;
    }

    public int getAutosubscribe() {
        return autosubscribe;
    }

    public void setAutosubscribe(int autosubscribe) {
        this.autosubscribe = autosubscribe;
    }

    public int getTrackforums() {
        return trackforums;
    }

    public void setTrackforums(int trackforums) {
        this.trackforums = trackforums;
    }

    public int getTimecreated() {
        return timecreated;
    }

    public void setTimecreated(int timecreated) {
        this.timecreated = timecreated;
    }

    public int getTimemodified() {
        return timemodified;
    }

    public void setTimemodified(int timemodified) {
        this.timemodified = timemodified;
    }

    public int getTrustbitmask() {
        return trustbitmask;
    }

    public void setTrustbitmask(int trustbitmask) {
        this.trustbitmask = trustbitmask;
    }

    public String getImagealt() {
        return imagealt;
    }

    public void setImagealt(String imagealt) {
        this.imagealt = imagealt;
    }

    public String getLastnamephonetic() {
        return lastnamephonetic;
    }

    public void setLastnamephonetic(String lastnamephonetic) {
        this.lastnamephonetic = lastnamephonetic;
    }

    public String getFirstnamephonetic() {
        return firstnamephonetic;
    }

    public void setFirstnamephonetic(String firstnamephonetic) {
        this.firstnamephonetic = firstnamephonetic;
    }

    public String getMiddlename() {
        return middlename;
    }

    public void setMiddlename(String middlename) {
        this.middlename = middlename;
    }

    public String getAlternatename() {
        return alternatename;
    }

    public void setAlternatename(String alternatename) {
        this.alternatename = alternatename;
    }

    public boolean getStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public int getEnrollmentYear() {
        return enrollmentYear;
    }

    public void setEnrollmentYear(int enrollmentYear) {
        this.enrollmentYear = enrollmentYear;
    }

    public int getCurrently_enrolled() {
        return currently_enrolled;
    }

    public void setCurrently_enrolled(int currently_enrolled) {
        this.currently_enrolled = currently_enrolled;
    }

    public int getPat() {
        return pat;
    }

    public void setPat(int pat) {
        this.pat = pat;
    }

    public int getFyp_supervisor() {
        return fyp_supervisor;
    }

    public void setFyp_supervisor(int fyp_supervisor) {
        this.fyp_supervisor = fyp_supervisor;
    }
}
