package com.StudentPortal.model.moodleds;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by abdul on 3/28/17.
 */
@Entity
@Table(name = "mdl_attendance_statuses", schema = "moodle")
public class MDL_Attendance_Statuses implements Serializable{

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "id")
    private int id;


    @Column(name = "attendanceid")
    private int attendanceid;


    @Column(name = "acronym")
    private String acronym;


    @Column(name = "description")
    private String description;


    @Column(name = "grade")
    private double grade;


    @Column(name = "visible")
    private int visible;


    @Column(name = "deleted")
    private int deleted;


    @Column(name = "setnumber")
    private int setnumber;

    public MDL_Attendance_Statuses(int attendanceid, String acronym, String description, double grade, int visible, int deleted, int setnumber) {

        this.attendanceid = attendanceid;
        this.acronym = acronym;
        this.description = description;
        this.grade = grade;
        this.visible = visible;
        this.deleted = deleted;
        this.setnumber = setnumber;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAttendanceid() {
        return attendanceid;
    }

    public void setAttendanceid(int attendanceid) {
        this.attendanceid = attendanceid;
    }

    public String getAcronym() {
        return acronym;
    }

    public void setAcronym(String acronym) {
        this.acronym = acronym;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getGrade() {
        return grade;
    }

    public void setGrade(double grade) {
        this.grade = grade;
    }

    public int getVisible() {
        return visible;
    }

    public void setVisible(int visible) {
        this.visible = visible;
    }

    public int getDeleted() {
        return deleted;
    }

    public void setDeleted(int deleted) {
        this.deleted = deleted;
    }

    public int getSetnumber() {
        return setnumber;
    }

    public void setSetnumber(int setnumber) {
        this.setnumber = setnumber;
    }
}
