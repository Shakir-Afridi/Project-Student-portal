package com.StudentPortal.model.moodleds;

import javax.persistence.*;

/**
 * Created by abdul on 3/23/17.
 */
@Entity
@Table (name = "mdl_course_completion", schema = "moodle")
public class MDL_Course_Completion {

    @Id
    private int id;

    @Column(name = "userid")
    private int userid;

    @Column(name = "course")
    private int course;

    @Column(name = "timeenrolled")
    private int timeenrolled;

    @Column(name = "timestarted")
    private int timestarted;

    @Column(name = "timecompleted")
    private int timecompleted;

    @Column(name = "reaggregate")
    private int reaggregate;

    @Column(name = "year")
    private int year;

    @Column(name = "credithour")
    private int credithour;


    public MDL_Course_Completion(int userid, int course, int timeenrolled, int timestarted, int timecompleted, int reaggregate, int year, int credithour) {
        this.userid = userid;
        this.course = course;
        this.timeenrolled = timeenrolled;
        this.timestarted = timestarted;
        this.timecompleted = timecompleted;
        this.reaggregate = reaggregate;
        this.year = year;
        this.credithour = credithour;
    }


    public int getCredithour() {
        return credithour;
    }

    public void setCredithour(int credithour) {
        this.credithour = credithour;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public int getCourse() {
        return course;
    }

    public void setCourse(int course) {
        this.course = course;
    }

    public int getTimeenrolled() {
        return timeenrolled;
    }

    public void setTimeenrolled(int timeenrolled) {
        this.timeenrolled = timeenrolled;
    }

    public int getTimestarted() {
        return timestarted;
    }

    public void setTimestarted(int timestarted) {
        this.timestarted = timestarted;
    }

    public int getTimecompleted() {
        return timecompleted;
    }

    public void setTimecompleted(int timecompleted) {
        this.timecompleted = timecompleted;
    }

    public int getReaggregate() {
        return reaggregate;
    }

    public void setReaggregate(int reaggregate) {
        this.reaggregate = reaggregate;
    }
}
