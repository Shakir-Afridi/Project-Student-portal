package com.StudentPortal.model.moodleds;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by abdul on 2/2/17.
 */

@Entity
@Table (name = "mdl_course", schema = "moodle")
public class MDL_Course implements Serializable{

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "id")
    private int id;

    @Column(name = "category")
    private int category;

    @Column(name = "sortorder")
    private int sortorder;

    @Column(name = "fullname")
    private String fullname;

    @Column(name = "shortname")
    private String shortname;

    @Column(name = "idnumber")
    private String idnumber;

    @Column(name = "summary")
    private String summary;

    @Column(name = "summaryformat")
    private int summaryformat;

    @Column(name = "format")
    private String format;

    @Column(name = "showgrades")
    private int showgrades;

    @Column(name = "newsitems")
    private int newsitems;

    @Column(name = "startdate")
    private int startdate;

    @Column(name = "enddate")
    private int enddate;

    @Column(name = "marker")
    private int marker;

    @Column(name = "maxbytes")
    private int maxbytes;

    @Column(name = "legacyfiles")
    private int legacyfiles;

    @Column(name = "showreports")
    private int showreports;

    @Column(name = "visible")
    private int visible;

    @Column(name = "visibleold")
    private int visibleold;

    @Column(name = "groupmode")
    private int groupmode;

    @Column(name = "groupmodeforce")
    private int groupmodeforce;

    @Column(name = "defaultgroupingid")
    private int defaultgroupingid;

    @Column(name = "lang")
    private String lang;

    @Column(name = "calendartype")
    private String calendartype;

    @Column(name = "theme")
    private String theme;

    @Column(name = "timecreated")
    private int timecreated;

    @Column(name = "timemodified")
    private int timemodified;

    @Column(name = "requested")
    private int requested;

    @Column(name = "enablecompletion")
    private int enablecompletion;

    @Column(name = "completionnotify")
    private int completionnotify;

    @Column(name = "caherev")
    private int cacherev;

    @Column(name = "year")
    private int year;

    @Column(name = "credithour")
    private int credithour;

    public MDL_Course(int category, int sortorder, String fullname, String shortname, String idnumber, String summary, int summaryformat, String format, int showgrades, int newsitems, int startdate, int enddate, int marker, int maxbytes, int legacyfiles, int showreports, int visible, int visibleold, int groupmode, int groupmodeforce, int defaultgroupingid, String lang, String calendartype, String theme, int timecreated, int timemodified, int requested, int enablecompletion, int completionnotify, int cacherev, int year, int credithour) {
        this.category = category;
        this.credithour = credithour;
        this.sortorder = sortorder;
        this.fullname = fullname;
        this.shortname = shortname;
        this.idnumber = idnumber;
        this.summary = summary;
        this.summaryformat = summaryformat;
        this.format = format;
        this.showgrades = showgrades;
        this.newsitems = newsitems;
        this.startdate = startdate;
        this.enddate = enddate;
        this.marker = marker;
        this.maxbytes = maxbytes;
        this.legacyfiles = legacyfiles;
        this.showreports = showreports;
        this.visible = visible;
        this.visibleold = visibleold;
        this.groupmode = groupmode;
        this.groupmodeforce = groupmodeforce;
        this.defaultgroupingid = defaultgroupingid;
        this.lang = lang;
        this.calendartype = calendartype;
        this.theme = theme;
        this.timecreated = timecreated;
        this.timemodified = timemodified;
        this.requested = requested;
        this.enablecompletion = enablecompletion;
        this.completionnotify = completionnotify;
        this.cacherev = cacherev;
        this.year = year;
    }

    public int getCredithour() {
        return credithour;
    }

    public void setCredithour(int credithour) {
        this.credithour = credithour;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getCategory() {
        return category;
    }

    public void setCategory(int category) {
        this.category = category;
    }

    public int getSortorder() {
        return sortorder;
    }

    public void setSortorder(int sortorder) {
        this.sortorder = sortorder;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getShortname() {
        return shortname;
    }

    public void setShortname(String shortname) {
        this.shortname = shortname;
    }

    public String getIdnumber() {
        return idnumber;
    }

    public void setIdnumber(String idnumber) {
        this.idnumber = idnumber;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public int getSummaryformat() {
        return summaryformat;
    }

    public void setSummaryformat(int summaryformat) {
        this.summaryformat = summaryformat;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public int getShowgrades() {
        return showgrades;
    }

    public void setShowgrades(int showgrades) {
        this.showgrades = showgrades;
    }

    public int getNewsitems() {
        return newsitems;
    }

    public void setNewsitems(int newsitems) {
        this.newsitems = newsitems;
    }

    public int getStartdate() {
        return startdate;
    }

    public void setStartdate(int startdate) {
        this.startdate = startdate;
    }

    public int getEnddate() {
        return enddate;
    }

    public void setEnddate(int enddate) {
        this.enddate = enddate;
    }

    public int getMarker() {
        return marker;
    }

    public void setMarker(int marker) {
        this.marker = marker;
    }

    public int getMaxbytes() {
        return maxbytes;
    }

    public void setMaxbytes(int maxbytes) {
        this.maxbytes = maxbytes;
    }

    public int getLegacyfiles() {
        return legacyfiles;
    }

    public void setLegacyfiles(int legacyfiles) {
        this.legacyfiles = legacyfiles;
    }

    public int getShowreports() {
        return showreports;
    }

    public void setShowreports(int showreports) {
        this.showreports = showreports;
    }

    public int getVisible() {
        return visible;
    }

    public void setVisible(int visible) {
        this.visible = visible;
    }

    public int getVisibleold() {
        return visibleold;
    }

    public void setVisibleold(int visibleold) {
        this.visibleold = visibleold;
    }

    public int getGroupmode() {
        return groupmode;
    }

    public void setGroupmode(int groupmode) {
        this.groupmode = groupmode;
    }

    public int getGroupmodeforce() {
        return groupmodeforce;
    }

    public void setGroupmodeforce(int groupmodeforce) {
        this.groupmodeforce = groupmodeforce;
    }

    public int getDefaultgroupingid() {
        return defaultgroupingid;
    }

    public void setDefaultgroupingid(int defaultgroupingid) {
        this.defaultgroupingid = defaultgroupingid;
    }

    public String getLang() {
        return lang;
    }

    public void setLang(String lang) {
        this.lang = lang;
    }

    public String getCalendartype() {
        return calendartype;
    }

    public void setCalendartype(String calendartype) {
        this.calendartype = calendartype;
    }

    public String getTheme() {
        return theme;
    }

    public void setTheme(String theme) {
        this.theme = theme;
    }

    public int getTimecreated() {
        return timecreated;
    }

    public void setTimecreated(int timecreated) {
        this.timecreated = timecreated;
    }

    public int getTimemodified() {
        return timemodified;
    }

    public void setTimemodified(int timemodified) {
        this.timemodified = timemodified;
    }

    public int getRequested() {
        return requested;
    }

    public void setRequested(int requested) {
        this.requested = requested;
    }

    public int getEnablecompletion() {
        return enablecompletion;
    }

    public void setEnablecompletion(int enablecompletion) {
        this.enablecompletion = enablecompletion;
    }

    public int getCompletionnotify() {
        return completionnotify;
    }

    public void setCompletionnotify(int completionnotify) {
        this.completionnotify = completionnotify;
    }

    public int getCacherev() {
        return cacherev;
    }

    public void setCacherev(int cacherev) {
        this.cacherev = cacherev;
    }
}
