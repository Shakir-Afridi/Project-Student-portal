package com.StudentPortal.model.moodleds;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by abdul on 2/2/17.
 */

@Entity
@Table (name = "job", schema = "moodle")
public class Jobs implements Serializable{

    @Id
    @Column (name = "j_id")
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    private int j_id;

    @Column (name = "j_title")
    private String j_title;

    @Column (name = "j_nature")
    private String j_nature;

    @Column (name = "j_society")
    private String j_socity;

    public String getJ_socity() {
        return j_socity;
    }

    public void setJ_socity(String j_socity) {
        this.j_socity = j_socity;
    }

    public Jobs(int j_id, String j_title, String j_nature, String j_socity) {
        this.j_id = j_id;
        this.j_title = j_title;
        this.j_nature = j_nature;
        this.j_socity = j_socity;
    }

    public int getJ_id() {
        return j_id;
    }

    public void setJ_id(int j_id) {
        this.j_id = j_id;
    }

    public String getJ_title() {
        return j_title;
    }

    public void setJ_title(String j_title) {
        this.j_title = j_title;
    }

    public String getJ_nature() {
        return j_nature;
    }

    public void setJ_nature(String j_nature) {
        this.j_nature = j_nature;
    }
}
