package com.StudentPortal.model.moodleds;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

/**
 * Created by abdul on 2/25/17.
 */
@Entity
@Table (name = "attachments", schema = "moodle")
public class Attachments {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    private int id;

    @Column (name = "thread_id")
    private int thread_id;

    @Column (name = "reply_id")
    private int reply_id;

    @Column (name = "file_name")
    private String file_name;

    public Attachments(int thread_id, int reply_id, String file_name) {
        this.thread_id = thread_id;
        this.reply_id = reply_id;
        this.file_name = file_name;
    }

    public int getThread_id() {
        return this.thread_id;
    }

    public void setThread_id(int thread_id) {
        this.thread_id = thread_id;
    }

    public int getReply_id() {
        return this.reply_id;
    }

    public void setReply_id(int reply_id) {
        this.reply_id = reply_id;
    }

    public String getFile_name() {
        return file_name;
    }

    public void setFile_name(String file_name) {
        this.file_name = file_name;
    }
}
