package com.StudentPortal.model.papercutds;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;
import java.security.Timestamp;
import java.sql.Time;
import java.util.Date;

/**
 * Created by abdul on 4/23/17.
 */
@Entity
@Table (name = "tbl_printer_usage_log", schema = "papercut")
public class Tbl_Printer_Usage_Log implements Serializable {

    @Id
    @Column (name = "printer_usage_log_id")
    @GeneratedValue (generator = "increment")
    @GenericGenerator (name = "increment", strategy = "increment")
    private int printer_usage_log_id;

    @Column (name = "user_id")
    private int user_id;

    @Column (name = "usage_date")
    private Date usage_date;

    @Column (name = "usage_cost")
    private float usage_cost;

    @Column (name = "total_pages")
    private int total_pages;

    public Tbl_Printer_Usage_Log(Date usage_date, float usage_cost, int total_pages) {
        this.usage_date = usage_date;
        this.usage_cost = usage_cost;
        this.total_pages = total_pages;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public int getPrinter_usage_log_id() {
        return printer_usage_log_id;
    }

    public void setPrinter_usage_log_id(int printer_usage_log_id) {
        this.printer_usage_log_id = printer_usage_log_id;
    }

    public Date getUsage_date() {
        return usage_date;
    }

    public void setUsage_date(Date usage_date) {
        this.usage_date = usage_date;
    }

    public float getUsage_cost() {
        return usage_cost;
    }

    public void setUsage_cost(float usage_cost) {
        this.usage_cost = usage_cost;
    }

    public int getTotal_pages() {
        return total_pages;
    }

    public void setTotal_pages(int total_pages) {
        this.total_pages = total_pages;
    }
}
