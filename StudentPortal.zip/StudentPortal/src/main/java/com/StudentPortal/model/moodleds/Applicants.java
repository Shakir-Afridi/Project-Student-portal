package com.StudentPortal.model.moodleds;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by abdul on 4/12/17.
 */
@Entity
@Table (name = "applicants", schema = "moodle")
public class Applicants implements Serializable{

    @Id
    @Column (name = "a_id")
    @GeneratedValue (generator = "increment")
    @GenericGenerator (name = "increment", strategy = "increment")
    private int a_id;

    @Column (name = "v_id")
    private int v_id;

    @Column (name = "username")
    private String username;

    @Column (name = "date")
    private Date date;

    public Applicants(int v_id, String username, Date date) {
        this.v_id = v_id;
        this.username = username;
        this.date = date;
    }

    public int getA_id() {
        return a_id;
    }

    public void setA_id(int a_id) {
        this.a_id = a_id;
    }

    public int getV_id() {
        return v_id;
    }

    public void setV_id(int v_id) {
        this.v_id = v_id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

}
