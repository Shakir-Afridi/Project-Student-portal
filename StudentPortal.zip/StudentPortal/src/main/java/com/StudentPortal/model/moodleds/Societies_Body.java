package com.StudentPortal.model.moodleds;

import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import javax.persistence.*;


/**
 * Created by Shakir Afridi on 4/16/2017.
 */
@Entity
@Table(name = "societies_body")
public class Societies_Body {
    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "id")
    private int id;

    @Column (name = "uob")
    private String uob;

    @Column(name = "patron")
    private String patron;

    @Column(name = "s_id")
    private int s_id;

    @Column(name = "j_id")
    private int j_id;
;

    public Societies_Body(int j_id,String uob,String patron,int s_id){
        this.j_id = j_id;
        this.uob = uob;
        this.patron = patron;
        this.s_id = s_id;
    }

    public String getPatron() {
        return patron;
    }

    public void setPatron(String patron) {
        this.patron = patron;
    }

    public int getS_id() {
        return s_id;
    }

    public void setS_id(int s_id) {
        this.s_id = s_id;
    }

    public int getJ_id() {
        return j_id;
    }

    public void setJ_id(int j_id) {
        this.j_id = j_id;
    }

    public String getUob() {
        return uob;
    }

    public void setUob(String uob) {
        this.uob = uob;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

}
