package com.StudentPortal.model.papercutds;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by abdul on 4/20/17.
 */
@Entity
@Table (name = "items_issued", schema = "papercut")
public class Issued_Items {

    @Id
    @Column (name = "id")
    @GeneratedValue (generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    private int id;

    @Column (name = "item_id")
    private int item_id;

    @Column (name = "user_id")
    private int user_id;

    @Column (name = "issue_date")
    private Date issue_date;

    @Column (name = "due_date")
    private Date due_date;

    @Column (name = "quantity")
    private int quantity;

    public Issued_Items(int item_id, int user_id, Date issue_date, Date due_date, int quantity) {
        this.item_id = item_id;
        this.user_id = user_id;
        this.issue_date = issue_date;
        this.due_date = due_date;
        this.quantity = quantity;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getItem_id() {
        return item_id;
    }

    public void setItem_id(int items_id) {
        this.item_id = items_id;
    }

    public int getUsername() {
        return user_id;
    }

    public void setUsername(int user_id) {
        this.user_id = user_id;
    }

    public Date getIssue_date() {
        return issue_date;
    }

    public void setIssue_date(Date issue_date) {
        this.issue_date = issue_date;
    }

    public Date getDue_date() {
        return due_date;
    }

    public void setDue_date(Date due_date) {
        this.due_date = due_date;
    }
}
