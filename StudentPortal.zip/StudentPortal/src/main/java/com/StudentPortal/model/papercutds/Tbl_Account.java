package com.StudentPortal.model.papercutds;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by abdul on 4/20/17.
 */
@Entity
@Table (name = "tbl_account", schema = "papercut")
public class Tbl_Account {

    @Id
    @Column (name = "account_id")
    @GeneratedValue (generator = "increment")
    @GenericGenerator (name = "increment", strategy = "increment")
    private int account_id;

    @Column (name = "account_type")
    private String account_type;

    @Column (name = "account_name")
    private String account_name;

    @Column (name = "balance")
    private double balance;

    @Column (name = "restricted")
    private boolean restricted;

    @Column (name = "overdraft")
    private double overdraft;

    @Column (name = "pin")
    private String pin;

    @Column (name = "use_global_overdraft")
    private boolean use_global_overdraft;

    @Column (name = "notes")
    private String notes;

    @Column (name = "deleted")
    private boolean deleted;

    @Column (name = "deleted_date")
    private Date deleted_date;

    @Column (name = "created_date")
    private Date created_date;

    @Column (name = "created_by")
    private String created_by;

    @Column (name = "modified_date")
    private Date modified_date;

    @Column (name = "modified_by")
    private String modified_by;

    @Column (name = "parent_id")
    private int parent_id;

    @Column (name = "account_name_lower")
    private String account_name_lower;

    @Column (name = "sub_name")
    private String sub_name;

    @Column (name = "sub_name_lower")
    private String sub_name_lower;

    @Column (name = "disabled")
    private boolean disabled;

    @Column (name = "disabled_until")
    private Date disabled_until;

    @Column (name = "comments")
    private String comments;

    @Column (name = "invoicing")
    private String invoicing;

    @Column (name = "sub_pin")
    private String sub_pin;

    public Tbl_Account(String account_type, String account_name, double balance, boolean restricted, double overdraft, String pin, boolean use_global_overdraft, String notes, boolean deleted, Date deleted_date, Date created_date, String created_by, Date modified_date, String modified_by, int parent_id, String account_name_lower, String sub_name, String sub_name_lower, boolean disabled, Date disabled_until, String comments, String invoicing, String sub_pin) {
        this.account_type = account_type;
        this.account_name = account_name;
        this.balance = balance;
        this.restricted = restricted;
        this.overdraft = overdraft;
        this.pin = pin;
        this.use_global_overdraft = use_global_overdraft;
        this.notes = notes;
        this.deleted = deleted;
        this.deleted_date = deleted_date;
        this.created_date = created_date;
        this.created_by = created_by;
        this.modified_date = modified_date;
        this.modified_by = modified_by;
        this.parent_id = parent_id;
        this.account_name_lower = account_name_lower;
        this.sub_name = sub_name;
        this.sub_name_lower = sub_name_lower;
        this.disabled = disabled;
        this.disabled_until = disabled_until;
        this.comments = comments;
        this.invoicing = invoicing;
        this.sub_pin = sub_pin;
    }

    public int getAccount_id() {
        return account_id;
    }

    public void setAccount_id(int account_id) {
        this.account_id = account_id;
    }

    public String getAccount_type() {
        return account_type;
    }

    public void setAccount_type(String account_type) {
        this.account_type = account_type;
    }

    public String getAccount_name() {
        return account_name;
    }

    public void setAccount_name(String account_name) {
        this.account_name = account_name;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public boolean isRestricted() {
        return restricted;
    }

    public void setRestricted(boolean restricted) {
        this.restricted = restricted;
    }

    public double getOverdraft() {
        return overdraft;
    }

    public void setOverdraft(double overdraft) {
        this.overdraft = overdraft;
    }

    public String getPin() {
        return pin;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }

    public boolean isUse_global_overdraft() {
        return use_global_overdraft;
    }

    public void setUse_global_overdraft(boolean use_global_overdraft) {
        this.use_global_overdraft = use_global_overdraft;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    public Date getDeleted_date() {
        return deleted_date;
    }

    public void setDeleted_date(Date deleted_date) {
        this.deleted_date = deleted_date;
    }

    public Date getCreated_date() {
        return created_date;
    }

    public void setCreated_date(Date created_date) {
        this.created_date = created_date;
    }

    public String getCreated_by() {
        return created_by;
    }

    public void setCreated_by(String created_by) {
        this.created_by = created_by;
    }

    public Date getModified_date() {
        return modified_date;
    }

    public void setModified_date(Date modified_date) {
        this.modified_date = modified_date;
    }

    public String getModified_by() {
        return modified_by;
    }

    public void setModified_by(String modified_by) {
        this.modified_by = modified_by;
    }

    public int getParent_id() {
        return parent_id;
    }

    public void setParent_id(int parent_id) {
        this.parent_id = parent_id;
    }

    public String getAccount_name_lower() {
        return account_name_lower;
    }

    public void setAccount_name_lower(String account_name_lower) {
        this.account_name_lower = account_name_lower;
    }

    public String getSub_name() {
        return sub_name;
    }

    public void setSub_name(String sub_name) {
        this.sub_name = sub_name;
    }

    public String getSub_name_lower() {
        return sub_name_lower;
    }

    public void setSub_name_lower(String sub_name_lower) {
        this.sub_name_lower = sub_name_lower;
    }

    public boolean isDisabled() {
        return disabled;
    }

    public void setDisabled(boolean disabled) {
        this.disabled = disabled;
    }

    public Date getDisabled_until() {
        return disabled_until;
    }

    public void setDisabled_until(Date disabled_until) {
        this.disabled_until = disabled_until;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getInvoicing() {
        return invoicing;
    }

    public void setInvoicing(String invoicing) {
        this.invoicing = invoicing;
    }

    public String getSub_pin() {
        return sub_pin;
    }

    public void setSub_pin(String sub_pin) {
        this.sub_pin = sub_pin;
    }
}
