package com.StudentPortal.model.moodleds;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

/**
 * Created by abdul on 3/23/17.
 */
@Entity
@Table (name = "mdl_grade_categories_history", schema = "moodle")
public class MDL_Grade_Categories_History {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "id")
    private int id;

    @Column(name = "action")
    private int action;

    @Column(name = "oldid")
    private int oldid;

    @Column(name = "source")
    private String source;

    @Column(name = "timemodified")
    private int timemodified;

    @Column(name = "loggeduser")
    private int loggeduser;

    @Column(name = "courseid")
    private int courseid;

    @Column(name = "parent")
    private int parent;

    @Column(name = "depth")
    private int depth;

    @Column(name = "path")
    private String path;

    @Column(name = "fullname")
    private String fullname;

    @Column(name = "aggragation")
    private int aggregation;

    @Column(name = "keephigh")
    private int keephigh;

    @Column(name = "droplow")
    private int droplow;

    @Column(name = "aggregateonlygraded")
    private int aggregateonlygraded;

    @Column(name = "aggregateoutcomes")
    private int aggregateoutcomes;

    @Column(name = "aggregatesubcats")
    private int aggregatesubcats;

    @Column(name = "hidden")
    private int hidden;

    @Column(name = "weightage")
    private int weightage;

    public MDL_Grade_Categories_History(int action, int oldid, String source, int timemodified, int loggeduser, int courseid, int parent, int depth, String path, String fullname, int aggregation, int keephigh, int droplow, int aggregateonlygraded, int aggregateoutcomes, int aggregatesubcats, int hidden, int weightage) {
        this.action = action;
        this.oldid = oldid;
        this.source = source;
        this.timemodified = timemodified;
        this.loggeduser = loggeduser;
        this.courseid = courseid;
        this.parent = parent;
        this.depth = depth;
        this.path = path;
        this.fullname = fullname;
        this.aggregation = aggregation;
        this.keephigh = keephigh;
        this.droplow = droplow;
        this.aggregateonlygraded = aggregateonlygraded;
        this.aggregateoutcomes = aggregateoutcomes;
        this.aggregatesubcats = aggregatesubcats;
        this.hidden = hidden;
        this.weightage = weightage;
    }

    public int getAction() {
        return action;
    }

    public void setAction(int action) {
        this.action = action;
    }

    public int getOldid() {
        return oldid;
    }

    public void setOldid(int oldid) {
        this.oldid = oldid;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public int getTimemodified() {
        return timemodified;
    }

    public void setTimemodified(int timemodified) {
        this.timemodified = timemodified;
    }

    public int getLoggeduser() {
        return loggeduser;
    }

    public void setLoggeduser(int loggeduser) {
        this.loggeduser = loggeduser;
    }

    public int getCourseid() {
        return courseid;
    }

    public void setCourseid(int courseid) {
        this.courseid = courseid;
    }

    public int getParent() {
        return parent;
    }

    public void setParent(int parent) {
        this.parent = parent;
    }

    public int getDepth() {
        return depth;
    }

    public void setDepth(int depth) {
        this.depth = depth;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public int getAggregation() {
        return aggregation;
    }

    public void setAggregation(int aggregation) {
        this.aggregation = aggregation;
    }

    public int getKeephigh() {
        return keephigh;
    }

    public void setKeephigh(int keephigh) {
        this.keephigh = keephigh;
    }

    public int getDroplow() {
        return droplow;
    }

    public void setDroplow(int droplow) {
        this.droplow = droplow;
    }

    public int getAggregateonlygraded() {
        return aggregateonlygraded;
    }

    public void setAggregateonlygraded(int aggregateonlygraded) {
        this.aggregateonlygraded = aggregateonlygraded;
    }

    public int getAggregateoutcomes() {
        return aggregateoutcomes;
    }

    public void setAggregateoutcomes(int aggregateoutcomes) {
        this.aggregateoutcomes = aggregateoutcomes;
    }

    public int getAggregatesubcats() {
        return aggregatesubcats;
    }

    public void setAggregatesubcats(int aggregatesubcats) {
        this.aggregatesubcats = aggregatesubcats;
    }

    public int getHidden() {
        return hidden;
    }

    public void setHidden(int hidden) {
        this.hidden = hidden;
    }
}

