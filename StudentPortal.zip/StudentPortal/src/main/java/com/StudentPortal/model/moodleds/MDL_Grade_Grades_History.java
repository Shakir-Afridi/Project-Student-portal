package com.StudentPortal.model.moodleds;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

/**
 * Created by abdul on 3/23/17.
 */
@Entity
@Table(name = "mdl_grade_grades_history", schema = "moodle")
public class MDL_Grade_Grades_History {


    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "id")
    private int id;

    @Column(name = "action")
    private int action;

    @Column(name = "oldid")
    private int oldid;

    @Column(name = "source")
    private String source;

    @Column(name = "timemodified")
    private int timemodified;

    @Column(name = "loggeduser")
    private int loggeduser;

    @Column(name = "itemid")
    private int itemid;

    @Column(name = "userid")
    private int userid;

    @Column(name = "rawgrade")
    private int rawgrade;

    @Column(name = "rawgrademax")
    private int rawgrademax;

    @Column(name = "rawgrademin")
    private int rawgrademin;

    @Column(name = "rawscaleid")
    private int rawscaleid;

    @Column(name = "usermodified")
    private int usermodified;

    @Column(name = "finalgrade")
    private int finalgrade;

    @Column(name = "hidden")
    private int hidden;

    @Column(name = "locked")
    private int locked;

    @Column(name = "locktime")
    private int locktime;

    @Column(name = "exported")
    private int exported;

    @Column(name = "overriden")
    private int overriden;

    @Column(name = "excluded")
    private int excluded;

    @Column(name = "feedback")
    private String feedback;

    @Column(name = "feedbackformat")
    private int feedbackformat;

    @Column(name = "information")
    private String information;

    @Column(name = "informationformat")
    private int informationformat;

    public MDL_Grade_Grades_History(int action, int oldid, String source, int timemodified, int loggeduser, int itemid, int userid, int rawgrade, int rawgrademax, int rawgrademin, int rawscaleid, int usermodified, int finalgrade, int hidden, int locked, int locktime, int exported, int overriden, int excluded, String feedback, int feedbackformat, String information, int informationformat) {
        this.action = action;
        this.oldid = oldid;
        this.source = source;
        this.timemodified = timemodified;
        this.loggeduser = loggeduser;
        this.itemid = itemid;
        this.userid = userid;
        this.rawgrade = rawgrade;
        this.rawgrademax = rawgrademax;
        this.rawgrademin = rawgrademin;
        this.rawscaleid = rawscaleid;
        this.usermodified = usermodified;
        this.finalgrade = finalgrade;
        this.hidden = hidden;
        this.locked = locked;
        this.locktime = locktime;
        this.exported = exported;
        this.overriden = overriden;
        this.excluded = excluded;
        this.feedback = feedback;
        this.feedbackformat = feedbackformat;
        this.information = information;
        this.informationformat = informationformat;
    }

    public int getAction() {
        return action;
    }

    public void setAction(int action) {
        this.action = action;
    }

    public int getOldid() {
        return oldid;
    }

    public void setOldid(int oldid) {
        this.oldid = oldid;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public int getTimemodified() {
        return timemodified;
    }

    public void setTimemodified(int timemodified) {
        this.timemodified = timemodified;
    }

    public int getItemid() {
        return itemid;
    }

    public void setItemid(int itemid) {
        this.itemid = itemid;
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public int getRawgrade() {
        return rawgrade;
    }

    public void setRawgrade(int rawgrade) {
        this.rawgrade = rawgrade;
    }

    public int getRawgrademax() {
        return rawgrademax;
    }

    public void setRawgrademax(int rawgrademax) {
        this.rawgrademax = rawgrademax;
    }

    public int getRawgrademin() {
        return rawgrademin;
    }

    public void setRawgrademin(int rawgrademin) {
        this.rawgrademin = rawgrademin;
    }

    public int getRawscaleid() {
        return rawscaleid;
    }

    public void setRawscaleid(int rawscaleid) {
        this.rawscaleid = rawscaleid;
    }

    public int getUsermodified() {
        return usermodified;
    }

    public void setUsermodified(int usermodified) {
        this.usermodified = usermodified;
    }

    public int getFinalgrade() {
        return finalgrade;
    }

    public void setFinalgrade(int finalgrade) {
        this.finalgrade = finalgrade;
    }

    public int getHidden() {
        return hidden;
    }

    public void setHidden(int hidden) {
        this.hidden = hidden;
    }

    public int getLocked() {
        return locked;
    }

    public void setLocked(int locked) {
        this.locked = locked;
    }

    public int getLocktime() {
        return locktime;
    }

    public void setLocktime(int locktime) {
        this.locktime = locktime;
    }

    public int getExported() {
        return exported;
    }

    public void setExported(int exported) {
        this.exported = exported;
    }

    public int getOverriden() {
        return overriden;
    }

    public void setOverriden(int overriden) {
        this.overriden = overriden;
    }

    public int getExcluded() {
        return excluded;
    }

    public void setExcluded(int excluded) {
        this.excluded = excluded;
    }

    public String getFeedback() {
        return feedback;
    }

    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }

    public int getFeedbackformat() {
        return feedbackformat;
    }

    public void setFeedbackformat(int feedbackformat) {
        this.feedbackformat = feedbackformat;
    }

    public String getInformation() {
        return information;
    }

    public void setInformation(String information) {
        this.information = information;
    }

    public int getInformationformat() {
        return informationformat;
    }

    public void setInformationformat(int informationformat) {
        this.informationformat = informationformat;
    }
}
