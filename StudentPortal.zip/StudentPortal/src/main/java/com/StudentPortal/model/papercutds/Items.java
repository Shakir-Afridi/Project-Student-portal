package com.StudentPortal.model.papercutds;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

/**
 * Created by abdul on 4/20/17.
 */
@Entity
@Table (name = "items", schema = "papercut")
public class Items {

    @Id
    @Column (name = "item_id")
    @GeneratedValue (generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    private int id;

    @Column (name = "item_name")
    private String item_name;

    @Column (name = "item_model")
    private String item_model;

    @Column (name = "quantity")
    private int quantity;

    @Column (name = "issued_items")
    private int issued_items;

    @Column (name = "remaining_items")
    private int remaining_items;

    public Items(String item_name, String item_model, int quantity, int issued_items, int remaining_items) {
        this.item_name = item_name;
        this.item_model = item_model;
        this.quantity = quantity;
        this.issued_items = issued_items;
        this.remaining_items = remaining_items;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getItem_name() {
        return item_name;
    }

    public void setItem_name(String item_name) {
        this.item_name = item_name;
    }

    public String getItem_model() {
        return item_model;
    }

    public void setItem_model(String item_model) {
        this.item_model = item_model;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getIssued_items() {
        return issued_items;
    }

    public void setIssued_items(int issued_items) {
        this.issued_items = issued_items;
    }

    public int getRemaining_items() {
        return remaining_items;
    }

    public void setRemaining_items(int remaining_items) {
        this.remaining_items = remaining_items;
    }
}
