package com.StudentPortal.model.moodleds;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by abdul on 4/11/17.
 */
@Entity
@Table (name = "vaccancies", schema = "moodle")
public class Vaccancies implements Serializable{

    @Id
    @Column (name = "v_id")
    @GeneratedValue (generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    private int v_id;

    @Column (name = "j_id")
    private int j_id;

    @Column (name = "date")
    private Date date;

    @Column (name = "due_date")
    private Date due_date;

    public Vaccancies(int j_id, Date date, Date due_date) {
        this.j_id = j_id;
        this.date = date;
        this.due_date = due_date;
    }

    public int getJ_id() {
        return j_id;
    }

    public void setJ_id(int j_id) {
        this.j_id = j_id;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Date getDue_date() {
        return due_date;
    }

    public void setDue_date(Date due_date) {
        this.due_date = due_date;
    }
}
