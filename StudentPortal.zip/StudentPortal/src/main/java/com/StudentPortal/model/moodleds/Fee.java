package com.StudentPortal.model.moodleds;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by Shakir Afridi on 2/17/17.
 */
@Entity
@Table (name = "fee")
public class Fee implements Serializable{

    @Id
    @Column (name = "fee_id")
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    private int fee_id;

    @Column (name = "installement_type")
    private String installement_type;

    @Column (name = "due_for")
    private String due_for;

    @Column (name = "amount")
    private int amount;

    @Column (name = "duration_from")
    private Date duration_from;

    @Column (name = "duration_to")
    private Date duration_to;

    public Fee (int fee_id, String installement_type, String due_for,int amount, Date duration_from, Date duration_to ){
        this.fee_id = fee_id;
        this.installement_type = installement_type;
        this.due_for = due_for;
        this.amount = amount;
        this.duration_from = duration_from;
        this.duration_to = duration_to;
    }

    public Fee (int amount){
        this.amount = amount;
    }

    public int getFee_id() {
        return fee_id;
    }

    public void setFee_id(int fee_id) {
        this.fee_id = fee_id;
    }

    public String getInstallement_type() {
        return installement_type;
    }

    public void setInstallement_type(String installement_type) {
        this.installement_type = installement_type;
    }

    public String getDue_for() {
        return due_for;
    }

    public void setDue_for(String due_for) {
        this.due_for = due_for;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public Date getDuration_from() {
        return duration_from;
    }

    public void setDuration_from(Date duration_from) {
        this.duration_from = duration_from;
    }

    public Date getDuration_to() {
        return duration_to;
    }

    public void setDuration_to(Date duration_to) {
        this.duration_to = duration_to;
    }
}