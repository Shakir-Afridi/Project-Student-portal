package com.StudentPortal.model.moodleds;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by abdul on 4/28/17.
 */
@Entity
@Table (name = "societies_body_history")
public class Societies_Body_History implements Serializable {

    @Id
    @Column (name = "s_id")
    @GeneratedValue (generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    private int s_id;

    @Column (name = "j_id")
    private int j_id;

    @Column (name = "uob")
    private String uob;

    @Column (name = "patron")
    private String patron;

    public Societies_Body_History(int j_id, String uob, String patron) {
        this.j_id = j_id;
        this.uob = uob;
        this.patron = patron;
    }

    public int getS_id() {

        return s_id;
    }

    public void setS_id(int s_id) {
        this.s_id = s_id;
    }

    public int getJ_id() {
        return j_id;
    }

    public void setJ_id(int j_id) {
        this.j_id = j_id;
    }

    public String getUob() {
        return uob;
    }

    public void setUob(String uob) {
        this.uob = uob;
    }

    public String getPatron() {
        return patron;
    }

    public void setPatron(String patron) {
        this.patron = patron;
    }
}
