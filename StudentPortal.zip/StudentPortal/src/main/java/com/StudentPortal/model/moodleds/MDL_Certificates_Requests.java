package com.StudentPortal.model.moodleds;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by abdul on 4/11/17.
 */
@Entity
@Table (name = "mdl_certificates_requests", schema = "moodle")
public class MDL_Certificates_Requests implements Serializable{

    @Id
    @GeneratedValue (generator = "increment")
    @GenericGenerator (name = "increment", strategy = "increment")
    private int id;

    @Column (name = "username")
    private String username;

    @Column (name = "request_date")
    private Date request_date;

    @Column (name = "recieved_date")
    private Date recieved_date;

    @Column (name = "j_id")
    private int j_id;

    @Column (name = "status")
    private boolean status;

    public MDL_Certificates_Requests(String username, Date request_date, Date recieved_date, int j_id, boolean status) {
        this.username = username;
        this.request_date = request_date;
        this.recieved_date = recieved_date;
        this.j_id = j_id;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Date getRequest_date() {
        return request_date;
    }

    public void setRequest_date(Date request_date) {
        this.request_date = request_date;
    }

    public Date getRecieved_date() {
        return recieved_date;
    }

    public void setRecieved_date(Date recieved_date) {
        this.recieved_date = recieved_date;
    }

    public int getJ_id() {
        return j_id;
    }

    public void setJ_id(int j_id) {
        this.j_id = j_id;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }
}
