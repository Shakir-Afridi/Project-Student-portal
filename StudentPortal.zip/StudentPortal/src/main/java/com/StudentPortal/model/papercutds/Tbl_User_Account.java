package com.StudentPortal.model.papercutds;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by abdul on 4/21/17.
 */
@Entity
@Table (name = "tbl_user_account", schema = "papercut")
public class Tbl_User_Account {

    @Id
    @GeneratedValue (generator = "increment")
    @GenericGenerator (name = "increment", strategy = "increment")
    @Column (name = "user_account_id")
    private int user_account_id;

    @Column (name = "user_id")
    private int user_id;

    @Column (name = "account_id")
    private int account_id;

    @Column (name = "created_date")
    private Date created_date;

    @Column (name = "created_by")
    private String created_by;

    @Column (name = "modified_date")
    private Date modified_date;

    @Column (name = "modified_by")
    private String modified_by;

    public Tbl_User_Account(int user_id, int account_id, Date created_date, String created_by, Date modified_date, String modified_by) {
        this.user_id = user_id;
        this.account_id = account_id;
        this.created_date = created_date;
        this.created_by = created_by;
        this.modified_date = modified_date;
        this.modified_by = modified_by;
    }

    public int getUser_account_id() {
        return user_account_id;
    }

    public void setUser_account_id(int user_account_id) {
        this.user_account_id = user_account_id;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public int getAccount_id() {
        return account_id;
    }

    public void setAccount_id(int account_id) {
        this.account_id = account_id;
    }

    public Date getCreated_date() {
        return created_date;
    }

    public void setCreated_date(Date created_date) {
        this.created_date = created_date;
    }

    public String getCreated_by() {
        return created_by;
    }

    public void setCreated_by(String created_by) {
        this.created_by = created_by;
    }

    public Date getModified_date() {
        return modified_date;
    }

    public void setModified_date(Date modified_date) {
        this.modified_date = modified_date;
    }

    public String getModified_by() {
        return modified_by;
    }

    public void setModified_by(String modified_by) {
        this.modified_by = modified_by;
    }
}
