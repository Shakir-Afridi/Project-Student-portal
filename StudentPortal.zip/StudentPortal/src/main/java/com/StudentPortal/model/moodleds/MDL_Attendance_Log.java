package com.StudentPortal.model.moodleds;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by abdul on 3/28/17.
 */
@Entity
@Table(name = "mdl_attendance_log", schema = "moodle")
public class MDL_Attendance_Log implements Serializable {

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name = "increment", strategy = "increment")
    @Column(name = "id")
    private int id;

    @Column(name = "sessionid")
    private int sessionid;

    @Column(name = "studentid")
    private int studentid;

    @Column(name = "statusid")
    private int statusid;

    @Column(name = "statusset")
    private String statusset;

    @Column(name = "timetaken")
    private int timetaken;

    @Column(name = "takenby")
    private int takenby;

    @Column(name = "remarks")
    private int remarks;

    public MDL_Attendance_Log(int sessionid, int studentid, int statusid, String statusset, int timetaken, int takenby, int remarks) {

        this.sessionid = sessionid;
        this.studentid = studentid;
        this.statusid = statusid;
        this.statusset = statusset;
        this.timetaken = timetaken;
        this.takenby = takenby;
        this.remarks = remarks;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getSessionid() {
        return sessionid;
    }

    public void setSessionid(int sessionid) {
        this.sessionid = sessionid;
    }

    public int getStudentid() {
        return studentid;
    }

    public void setStudentid(int studentid) {
        this.studentid = studentid;
    }

    public int getStatusid() {
        return statusid;
    }

    public void setStatusid(int statusid) {
        this.statusid = statusid;
    }

    public String getStatusset() {
        return statusset;
    }

    public void setStatusset(String statusset) {
        this.statusset = statusset;
    }

    public int getTimetaken() {
        return timetaken;
    }

    public void setTimetaken(int timetaken) {
        this.timetaken = timetaken;
    }

    public int getTakenby() {
        return takenby;
    }

    public void setTakenby(int takenby) {
        this.takenby = takenby;
    }

    public int getRemarks() {
        return remarks;
    }

    public void setRemarks(int remarks) {
        this.remarks = remarks;
    }
}
