package com.StudentPortal.model.moodleds;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

/**
 * Created by abdul on 4/9/17.
 */
@Entity
@Table (name = "societies_hour_history", schema = "moodle")
public class Societies_Hour_History {

    @Id
    private int id;

    @Column (name = "username")
    private String username;

    @Column (name = "j_id")
    private int j_id;

    @Column (name = "from_date")
    private Date from_date;

    @Column (name = "to_date")
    private Date to_date;

    @Column (name = "hours")
    private int hours;

    public Societies_Hour_History(String username, int j_id, Date from_date, Date to_date, int hours) {
        this.username = username;
        this.j_id = j_id;
        this.from_date = from_date;
        this.to_date = to_date;
        this.hours = hours;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getJ_id() {
        return j_id;
    }

    public void setJ_id(int j_id) {
        this.j_id = j_id;
    }

    public Date getFrom_date() {
        return from_date;
    }

    public void setFrom_date(Date from_date) {
        this.from_date = from_date;
    }

    public Date getTo_date() {
        return to_date;
    }

    public void setTo_date(Date to_date) {
        this.to_date = to_date;
    }

    public int getHours() {
        return hours;
    }

    public void setHours(int hours) {
        this.hours = hours;
    }
}
