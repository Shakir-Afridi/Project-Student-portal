package com.StudentPortal.controllers;

import com.StudentPortal.repository.moodleds.Attachments_Repository;
import com.StudentPortal.repository.moodleds.MDL_User_Repository;
import com.StudentPortal.repository.moodleds.Messages_Reply_Repository;
import com.StudentPortal.repository.moodleds.Messages_Repository;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

/**
 * Created by abdul on 5/1/17.
 */
public class InboxControllerTest {


    @Mock
    MDL_User_Repository mdl_user_repository;

    @Mock
    Messages_Repository messages_repository;

    @Mock
    Messages_Reply_Repository messages_reply_repository;

    @Mock
    Attachments_Repository attachments_repository;

    @InjectMocks
    InboxController inboxController;

    private MockMvc mockMvc;

    @Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
//        this.mockMvc = MockMvcBuilders.standaloneSetup(inboxController).build();
        InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
        viewResolver.setPrefix("/WEB-INF/jsp/view/");
        viewResolver.setSuffix(".jsp");

        mockMvc = MockMvcBuilders.standaloneSetup(inboxController)
                .setViewResolvers(viewResolver)
                .build();
    }

    @Test
    public void inbox() throws Exception {


        Mockito.when(mdl_user_repository.get_Email_Id("14031220")).thenReturn("ajabba42014@namal.edu.pk");

        List<Object> messages = new ArrayList<>();
        Object[] objects = new Object[4];
        objects[0] = "Abdul Malik";
        objects[1] = "ajabbar2014@namaledu.pk";
        objects[2] = "sarmad@namal.edu.pk";
        objects[3] = "Testing service";
        messages.add(objects);

        Mockito.when(messages_repository.get_Message(1)).thenReturn(messages);

        List<String> file_names = new ArrayList<>();
        Mockito.when(attachments_repository.get_Thread_Files_Names(1)).thenReturn(file_names);

        List<Object> messages_replies = new ArrayList<>();
        Object[] message_replies = new Object[5];
        message_replies[0] = 1;
        message_replies[1] = "Abdul Malik";
        message_replies[2] = "ajabbar2014@namaledu.pk";
        message_replies[3] = "sarmadnamal.edu.pk";
        message_replies[4] = "Testing service";
        messages_replies.add(message_replies);

        Mockito.when(messages_reply_repository.get_Thread_Replies(1)).thenReturn(messages_replies);

        Mockito.when(attachments_repository.get_reply_Files_Names(1)).thenReturn(new ArrayList<String>());


        this.mockMvc.perform(get("/message/"+1).sessionAttr("username", "14031220").sessionAttr("id", 21))
                .andExpect(status().isOk())
                .andExpect(view().name("message_read"));

        this.mockMvc.perform(get("/message/1"))
                .andExpect(status().is(302))
                .andExpect(view().name("redirect:/"));

    }

    @Test
    public void read_Message() throws Exception {

        List<Object> messages_replies = new ArrayList<>();
        Object[] message_replies = new Object[4];
        message_replies[1] = "Sarmad Ali";
        message_replies[0] = "sarmad@namaledu.pk";
        message_replies[3] = "ajabbar2014@namal.edu.pk";
        message_replies[2] = "Abdul Malik";
        messages_replies.add(message_replies);

        Mockito.when(messages_repository.get_Information_For_Reply(1)).thenReturn(messages_replies);

        List<Object> messages_replies_ = new ArrayList<>();
        Object[] message_replies_ = new Object[5];
        message_replies_[0] = 1;
        message_replies_[1] = "Sarmad Ali";
        message_replies_[2] = "sarmad@namaledu.pk";
        message_replies_[3] = "ajabbar2014@namal.edu.pk";
        message_replies_[4] = "Testing service";
        messages_replies.add(message_replies_);

        Mockito.when(messages_reply_repository.get_Thread_Replies(1)).thenReturn(messages_replies_);
        List<String> file_names = new ArrayList<>();
        Mockito.when(attachments_repository.get_Thread_Files_Names(1)).thenReturn(file_names);

        List<Object> messages = new ArrayList<>();
        Object[] objects = new Object[4];
        objects[0] = "Sarmad Ali";
        objects[1] = "sarmad@namaledu.pk";
        objects[2] = "ajabbar2014@namal.edu.pk";
        objects[3] = "Testing service";
        messages.add(objects);

        Mockito.when(messages_repository.get_Message(1)).thenReturn(messages);
        Mockito.when(attachments_repository.get_reply_Files_Names(1)).thenReturn(new ArrayList<String>());


        this.mockMvc.perform(get("/send_reply/message/14031220/1").sessionAttr("username", "14031220").sessionAttr("id", 21))

                .andExpect(status().isOk())
                .andExpect(view().name("message_read"));

        this.mockMvc.perform(get("/send_reply/message/14031220/1"))
                .andExpect(status().is(302))
                .andExpect(view().name("redirect:/"));

    }

    @Test
    public void upload_Files_Handler() throws Exception {


        Mockito.when(mdl_user_repository.get_Email_Id("14031220")).thenReturn("ajabbar2014@namal.edu.pk");

        List<Object> sender_information = new ArrayList<>();
        Object[] objects_sender = new Object[4];
        objects_sender[0] = 1;
        objects_sender[1] = "Abdul Malik";
        objects_sender[2] = new Date();
        objects_sender[3] = "12:12 Am";
        sender_information.add(objects_sender);

        Mockito.when(messages_repository.get_Sender_Information("ajabbar2014@namal.edu.pk", true)).thenReturn(sender_information);
        Object[] object = new Object[0];
        Mockito.when(messages_reply_repository.get_Reply_Status(1, "sarmad@namal.edu.pk")).thenReturn(object);

        this.mockMvc.perform(get("/inbox").sessionAttr("username", "14031220").sessionAttr("id", 21))
                .andExpect(status().isOk())
                .andExpect(view().name("inbox"));
//
        this.mockMvc.perform(get("/inbox"))
                .andExpect(status().is(302))
                .andExpect(view().name("redirect:/"));

    }

}