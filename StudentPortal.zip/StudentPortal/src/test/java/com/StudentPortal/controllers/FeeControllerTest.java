package com.StudentPortal.controllers;

import com.StudentPortal.repository.moodleds.FeeRepository;
import com.StudentPortal.repository.moodleds.FineRepository;
import com.StudentPortal.repository.moodleds.InstallementsRepository;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import java.util.ArrayList;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

/**
 * Created by abdul on 5/2/17.
 */
public class FeeControllerTest {


    @Mock
    FineRepository fineRepository;

    @Mock
    InstallementsRepository installementsRepository;

    @Mock
    FeeRepository feeRepository;

    @InjectMocks
    private FeeController feeController;

    private MockMvc mockMvc;

    @Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
//        this.mockMvc = MockMvcBuilders.standaloneSetup(feeController).build();

        InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
        viewResolver.setPrefix("/WEB-INF/jsp/view/");
        viewResolver.setSuffix(".jsp");

        mockMvc = MockMvcBuilders.standaloneSetup(feeController)
                .setViewResolvers(viewResolver)
                .build();
    }

    @Test
    public void feestructure() throws Exception {

        Mockito.when(fineRepository.findByRollNumber("14031220")).thenReturn(new ArrayList<>());

        this.mockMvc.perform(get("/FeeStructure").sessionAttr("username", "14031220").sessionAttr("id", 21))
                .andExpect(status().isOk())
                .andExpect(view().name("FeeStructure"));

        this.mockMvc.perform(get("/FeeStructure"))
                .andExpect(status().is(302))
                .andExpect(view().name("redirect:/"));
    }

    @Test
    public void fee_Details() throws Exception {

        Mockito.when(installementsRepository.findByRollNumber("14031220")).thenReturn(new ArrayList<>());
        this.mockMvc.perform(get("/FeeDetails").sessionAttr("username", "14031220").sessionAttr("id", 21))
                .andExpect(status().isOk())
                .andExpect(view().name("FeeDetails"));

        this.mockMvc.perform(get("/FeeDetails"))
                .andExpect(status().is(302))
                .andExpect(view().name("redirect:/"));
    }
}