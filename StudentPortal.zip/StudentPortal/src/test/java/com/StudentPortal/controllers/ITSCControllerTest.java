package com.StudentPortal.controllers;

import com.StudentPortal.repository.papercutds.*;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import java.util.ArrayList;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

/**
 * Created by abdul on 5/2/17.
 */
public class ITSCControllerTest {


    @Mock
    private Issued_Items_Repository issued_items_repository;

    @Mock
    private Tbl_User_Repository tbl_user_repository;

    @Mock
    private Items_Repository items_repository;

    @Mock
    private Tbl_User_Account_Repository tbl_user_account_repository;

    @Mock
    private Tbl_Account_Repository tbl_account_repository;

    @Mock
    private Tbl_Printer_Usage_Log_Repository tbl_printer_usage_log_repository;

    @InjectMocks
    private ITSCController itscController;

    private MockMvc mockMvc;


    @Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
//        this.mockMvc = MockMvcBuilders.standaloneSetup(itscController).build();
        InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
        viewResolver.setPrefix("/WEB-INF/jsp/view/");
        viewResolver.setSuffix(".jsp");

        mockMvc = MockMvcBuilders.standaloneSetup(itscController)
                .setViewResolvers(viewResolver)
                .build();
    }

    @Test
    public void itsc() throws Exception {

        Mockito.when(tbl_user_repository.get_User_Id("14031220")).thenReturn(1);
        Mockito.when(issued_items_repository.get_Issued_Items(1)).thenReturn(new ArrayList<>());
        Mockito.when(tbl_user_account_repository.get_Account_Id(1)).thenReturn(2);
//        Mockito.when(tbl_account_repository.get_Balance(1)).thenReturn(345.3);
        Mockito.when(tbl_printer_usage_log_repository.get_Account_Information(1)).thenReturn(new ArrayList<>());

        this.mockMvc.perform(get("/ITSC").sessionAttr("username", "14031220").sessionAttr("id", 21))
                .andExpect(status().isOk())
                .andExpect(view().name("ITSC"));

        this.mockMvc.perform(get("/ITSC"))
                .andExpect(status().is(302))
                .andExpect(view().name("redirect:/"));
    }

}