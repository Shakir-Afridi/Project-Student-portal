package com.StudentPortal.controllers;

import com.StudentPortal.repository.moodleds.*;
import org.assertj.core.util.ArrayWrapperList;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import java.util.ArrayList;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

/**
 * Created by abdul on 5/2/17.
 */
public class SocietiesControllerTest {


    @Mock
    Working_HousrRepository working_housrRepository;

    @Mock
    Working_Hour_History_Repository working_hour_history_repository;

    @Mock
    Current_Status_Societies_Repository current_status_societies_repository;

    @Mock
    MDL_Jobs_Repository jobsRepository;

    @Mock
    Societies_Hours_Repositroy societies_hours_repositroy;

    @Mock
    Societies_Hour_History_Repository societies_hour_history_repository;

    @Mock
    MDL_Certificate_Request_Repository mdl_certificate_request_repository;

    @Mock
    private Vaccancies_Repository vaccancies_repository;

    @Mock
    private Applicants_Repository applicants_repository;


    @InjectMocks
    private ITSCController itscController;

    private MockMvc mockMvc;


    @Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
//        this.mockMvc = MockMvcBuilders.standaloneSetup(itscController).build();
        InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
        viewResolver.setPrefix("/WEB-INF/jsp/view/");
        viewResolver.setSuffix(".jsp");

        mockMvc = MockMvcBuilders.standaloneSetup(itscController)
                .setViewResolvers(viewResolver)
                .build();
    }

    @Test
    public void societies() throws Exception {

        Mockito.when(current_status_societies_repository.get_Current_Work_Study_Record("14031220")).thenReturn(new ArrayList<>());
        Mockito.when(working_housrRepository.get_Working_hours_details("14031220", 12)).thenReturn(new ArrayList<>());
        Mockito.when(jobsRepository.get_Job_Nature(12)).thenReturn("ITSC");
        Mockito.when(current_status_societies_repository.get_Past_Work_Study_Record("14031220")).thenReturn(new ArrayList<>());
        Mockito.when(jobsRepository.get_Title_Nature(3)).thenReturn(new ArrayList<>());

        this.mockMvc.perform(get("/societies").sessionAttr("username", "14031220").sessionAttr("id", 21))
                .andExpect(status().isOk())
                .andExpect(view().name("Socities"));

        this.mockMvc.perform(get("/societies"))
                .andExpect(status().is(302))
                .andExpect(view().name("redirect:/"));
    }
}