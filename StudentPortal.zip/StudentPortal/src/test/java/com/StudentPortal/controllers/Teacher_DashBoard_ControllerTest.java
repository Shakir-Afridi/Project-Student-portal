package com.StudentPortal.controllers;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

/**
 * Created by abdul on 5/2/17.
 */
public class Teacher_DashBoard_ControllerTest {

    @InjectMocks
    private Teacher_DashBoard_Controller teacher_dashBoard_controller;

    private MockMvc mockMvc;


    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
//        this.mockMvc = MockMvcBuilders.standaloneSetup(teacher_dashBoard_controller).build();
        InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
        viewResolver.setPrefix("/WEB-INF/jsp/view/");
        viewResolver.setSuffix(".jsp");

        mockMvc = MockMvcBuilders.standaloneSetup(teacher_dashBoard_controller)
                .setViewResolvers(viewResolver)
                .build();
    }

    @Test
    public void dash_board() throws Exception {

        this.mockMvc.perform(get("/teacher_dashboard").sessionAttr("fac_name", "sarmad").sessionAttr("id", 21))
                .andExpect(status().isOk())
                .andExpect(view().name("teacher_dashboard"));

        this.mockMvc.perform(get("/teacher_dashboard"))
                .andExpect(status().is(302))
                .andExpect(view().name("redirect:/"));
    }

}