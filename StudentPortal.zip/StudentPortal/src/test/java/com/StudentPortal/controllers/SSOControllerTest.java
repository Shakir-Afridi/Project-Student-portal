package com.StudentPortal.controllers;

import com.StudentPortal.repository.moodleds.MDL_Certificate_Request_Repository;
import com.StudentPortal.repository.moodleds.MDL_Jobs_Repository;
import com.StudentPortal.repository.moodleds.MDL_User_Repository;
import org.assertj.core.util.ArrayWrapperList;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.ArrayList;


import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

/**
 * Created by abdul on 5/2/17.
 */
public class SSOControllerTest {

    @Mock
    MDL_User_Repository mdl_user_repository;

    @Mock
    MDL_Jobs_Repository jobsRepository;


    @Mock
    MDL_Certificate_Request_Repository mdl_certificates_requests_repository;

    @InjectMocks
    private SSOController ssoController;

    private MockMvc mockMvc;


    @Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
        this.mockMvc = MockMvcBuilders.standaloneSetup(ssoController).build();
    }

    @Test
    public void SSO_Dashboard() throws Exception {

        Mockito.when(mdl_certificates_requests_repository.get_requested_j_id()).thenReturn(new ArrayList<>());
        this.mockMvc.perform(get("/sso_dashboard").sessionAttr("sso", "sso").sessionAttr("id", 13))
                .andExpect(status().isOk())
                .andExpect(view().name("SSO_Dashboard"));

        this.mockMvc.perform(get("/sso_dashboard"))
                .andExpect(status().is(302))
                .andExpect(view().name("redirect:/"));
    }

    @Test
    public void ssoDate() throws Exception {

        Mockito.when(mdl_certificates_requests_repository.get_issued_certificates_uob()).thenReturn(new ArrayList<>());
        Mockito.when(mdl_certificates_requests_repository.get_requested_j_id()).thenReturn(new ArrayList<>());
        this.mockMvc.perform(get("/issued_certificates").sessionAttr("sso", "sso").sessionAttr("id", 13))
                .andExpect(status().isOk())
                .andExpect(view().name("SSO"));

        this.mockMvc.perform(get("/issued_certificates"))
                .andExpect(status().is(302))
                .andExpect(view().name("redirect:/"));
    }
}