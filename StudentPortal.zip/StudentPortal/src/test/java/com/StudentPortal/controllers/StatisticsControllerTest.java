package com.StudentPortal.controllers;

import com.StudentPortal.repository.moodleds.MDL_Jobs_Repository;
import com.StudentPortal.repository.moodleds.MDL_User_Repository;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import java.util.ArrayList;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

/**
 * Created by abdul on 5/2/17.
 */
public class StatisticsControllerTest {

    @Mock
    MDL_User_Repository mdl_user_repository;

    @Mock
    MDL_Jobs_Repository jobsRepository;


    @InjectMocks
    private StatisticsController statisticsController;

    private MockMvc mockMvc;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        this.mockMvc = MockMvcBuilders.standaloneSetup(statisticsController).build();
    }

    @Test
    public void statistics() throws Exception {

        Mockito.when(mdl_user_repository.get_Student_Information("14031220")).thenReturn(new ArrayList<>());
        Mockito.when(mdl_user_repository.get_Teacher_Information(2)).thenReturn(new ArrayList<>());
        Mockito.when(mdl_user_repository.get_Teacher_Information(4)).thenReturn(new ArrayList<>());

        this.mockMvc.perform(get("/statistics").sessionAttr("username", "14031220").sessionAttr("id", 21))
                .andExpect(status().isOk())
                .andExpect(view().name("Home"));

        this.mockMvc.perform(get("/statistics"))
                .andExpect(status().is(302))
                .andExpect(view().name("redirect:/"));
    }

}