package com.StudentPortal.controllers;

import com.StudentPortal.repository.moodleds.Attachments_Repository;
import com.StudentPortal.repository.moodleds.MDL_User_Repository;
import com.StudentPortal.repository.moodleds.Messages_Reply_Repository;
import com.StudentPortal.repository.moodleds.Messages_Repository;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

/**
 * Created by abdul on 5/1/17.
 */
public class ITSC_InboxTest {



    @Mock
    MDL_User_Repository mdl_user_repository;

    @Mock
    Messages_Repository messages_repository;

    @Mock
    Messages_Reply_Repository messages_reply_repository;

    @Mock
    Attachments_Repository attachments_repository;

    @InjectMocks
    ITSC_Inbox itsc_inbox;

    private MockMvc mockMvc;

    @Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
//        this.mockMvc = MockMvcBuilders.standaloneSetup(itsc_inbox).build();
        InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
        viewResolver.setPrefix("/WEB-INF/jsp/view/");
        viewResolver.setSuffix(".jsp");

        mockMvc = MockMvcBuilders.standaloneSetup(itsc_inbox)
                .setViewResolvers(viewResolver)
                .build();
    }

    @Test
    public void read_Message_ITSC() throws Exception {


        Mockito.when(mdl_user_repository.get_Email_Id("itsc")).thenReturn("itsc@namal.edu.pk");

        List<Object> messages = new ArrayList<>();
        Object[] objects = new Object[4];
        objects[0] = "ITSC Namal";
        objects[1] = "itsc@namaledu.pk";
        objects[2] = "ajabbar2014@namal.edu.pk";
        objects[3] = "Testing service";
        messages.add(objects);

        Mockito.when(messages_repository.get_Message(1)).thenReturn(messages);

        List<String> file_names = new ArrayList<>();
        Mockito.when(attachments_repository.get_Thread_Files_Names(1)).thenReturn(file_names);

        List<Object> messages_replies = new ArrayList<>();
        Object[] message_replies = new Object[5];
        message_replies[0] = 1;
        message_replies[1] = "ITSC Namal";
        message_replies[2] = "itsc@namaledu.pk";
        message_replies[3] = "ajabbar2014@namal.edu.pk";
        message_replies[4] = "Testing service";
        messages_replies.add(message_replies);

        Mockito.when(messages_reply_repository.get_Thread_Replies(1)).thenReturn(messages_replies);

        Mockito.when(attachments_repository.get_reply_Files_Names(1)).thenReturn(new ArrayList<String>());


        this.mockMvc.perform(get("/message/itsc/"+1).sessionAttr("itsc", "itsc").sessionAttr("id", 21))
                .andExpect(status().isOk())
                .andExpect(view().name("itsc_message_read"));

        this.mockMvc.perform(get("/message/itsc/1"))
                .andExpect(status().is(302))
                .andExpect(view().name("redirect:/"));
    }

    @Test
    public void upload_Files_Handler() throws Exception {


        List<Object> messages_replies = new ArrayList<>();
        Object[] message_replies = new Object[4];
        message_replies[1] = "Sarmad Ali";
        message_replies[0] = "sarmad@namaledu.pk";
        message_replies[3] = "ajabbar2014@namal.edu.pk";
        message_replies[2] = "Abdul Malik";
        messages_replies.add(message_replies);

        Mockito.when(messages_repository.get_Information_For_Reply(1)).thenReturn(messages_replies);

        List<Object> messages_replies_ = new ArrayList<>();
        Object[] message_replies_ = new Object[5];
        message_replies_[0] = 1;
        message_replies_[1] = "Sarmad Ali";
        message_replies_[2] = "sarmad@namaledu.pk";
        message_replies_[3] = "ajabbar2014@namal.edu.pk";
        message_replies_[4] = "Testing service";
        messages_replies.add(message_replies_);

        Mockito.when(messages_reply_repository.get_Thread_Replies(1)).thenReturn(messages_replies_);
        List<String> file_names = new ArrayList<>();
        Mockito.when(attachments_repository.get_Thread_Files_Names(1)).thenReturn(file_names);

        List<Object> messages = new ArrayList<>();
        Object[] objects = new Object[4];
        objects[0] = "Sarmad Ali";
        objects[1] = "sarmad@namaledu.pk";
        objects[2] = "ajabbar2014@namal.edu.pk";
        objects[3] = "Testing service";
        messages.add(objects);

        Mockito.when(messages_repository.get_Message(1)).thenReturn(messages);
        Mockito.when(attachments_repository.get_reply_Files_Names(1)).thenReturn(new ArrayList<String>());


        this.mockMvc.perform(get("/send_reply/itsc/message/" + "14031220" + "/" + "1").sessionAttr("fac_name", "14031220").sessionAttr("id", 21))

                .andExpect(status().isOk())
                .andExpect(view().name("itsc_message_read"));

        this.mockMvc.perform(get("/send_reply/itsc/message/14031220/1"))
                .andExpect(status().is(302))
                .andExpect(view().name("redirect:/"));
    }

    @Test
    public void itsc_inbox() throws Exception {
//
        Mockito.when(mdl_user_repository.get_Email_Id("itsc")).thenReturn("itsc@namal.edu.pk");

        List<Object> sender_information = new ArrayList<>();
        Object[] objects_sender = new Object[4];
        objects_sender[0] = 1;
        objects_sender[1] = "ITSC Namal";
        objects_sender[2] = new Date();
        objects_sender[3] = "12:12 Am";
        sender_information.add(objects_sender);

        Mockito.when(messages_repository.get_Sender_Information("itsc@namal.edu.pk", true)).thenReturn(sender_information);
        Object[] objects = new Object[0];
        Mockito.when(messages_reply_repository.get_Reply_Status(1, "ajabbar2014@namal.edu.pk")).thenReturn(objects);

        this.mockMvc.perform(get("/itsc_inbox").sessionAttr("itsc", "itsc").sessionAttr("id", 21))
                .andExpect(status().isOk())
                .andExpect(view().name("itsc_inbox"));

        this.mockMvc.perform(get("/itsc_inbox"))
                .andExpect(status().is(302))
                .andExpect(view().name("redirect:/"));
    }

    @Test
    public void home() throws Exception {

        Mockito.when(mdl_user_repository.get_Email_Id("itsc")).thenReturn("itsc@namal.edu.pk");
        List<Object> list_names = new ArrayList<>();
        Object[] names = new Object[2];
        names[0] = "ITSC";
        names[1] = "Namal";
        list_names.add(names);

        Mockito.when(mdl_user_repository.get_Name_By_Email("itsc@namal.edu.pk")).thenReturn(list_names);


        this.mockMvc.perform(get("/itsc_send_message").sessionAttr("itsc", "itsc").sessionAttr("id", 21).requestAttr("email", "ajabbar2014@namal.edu.pk").requestAttr("message", "Here is the message"))
                .andExpect(status().isOk())
                .andExpect(view().name("redirect:/itsc_inbox"));

        this.mockMvc.perform(get("/itsc_send_message"))
                .andExpect(status().is(302))
                .andExpect(view().name("redirect:/"));
    }

    @Test
    public void itsc_sent__inbox() throws Exception {

        Mockito.when(mdl_user_repository.get_Email_Id("itsc")).thenReturn("itsc@nama.edu.pk");

        List<Object> sent_messages = new ArrayList<>();
        Object[] objects = new Object[4];
        objects[0] = 1;
        objects[1] = "ITSC Namal";
        objects[2] = new Date();
        objects[3] = "12:12 Am";
        sent_messages.add(objects);

        Mockito.when(messages_repository.get_Receiver_Information("itsc@namal.edu.pk")).thenReturn(sent_messages);
        Mockito.when(messages_reply_repository.get_Reply_Status(1, "ajabbar2014@namal.edu.pk")).thenReturn(new Object[0]);

        this.mockMvc.perform(get("/sent_itsc_inbox").sessionAttr("itsc", "itsc").sessionAttr("id", 21))
                .andExpect(status().isOk())
                .andExpect(view().name("itsc_sent_messages"));
    }

}