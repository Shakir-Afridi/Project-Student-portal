package com.StudentPortal.controllers;

import com.StudentPortal.repository.moodleds.*;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import java.util.ArrayList;


import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

/**
 * Created by abdul on 5/2/17.
 */
public class TeacherControllerTest {

    @Mock
    MDL_User_Repository mdl_user_repository;

    @Mock
    MDL_Course_Repository mdl_course_repository;

    @Mock
    MDL_Jobs_Repository jobsRepository;

    @Mock
    MDL_Grade_Categories_Repository mdl_grade_categories_repository;

    @Mock
    MDL_Grade_Grades_Repository mdl_grade_grades_repository;

    @Mock
    MDL_Grade_Categories_History_Repository mdl_grade_categories_history_repository;

    @Mock
    MDL_Grade_Grades_History_Repository mdl_grade_grades_history_repository;

    @Mock
    MDL_Attendance_Repository mdl_attendance_repository;

    @Mock
    MDL_Attendance_Sessions_Repository mdl_attendance_sessions_repository;

    @Mock
    MDL_Attendance_Statuses_Repository mdl_attendance_statuses_repository;

    @Mock
    MDL_Attendance_Log_Repository mdl_attendance_log_repository;

    @Mock
    Vaccancies_Repository vaccancies_repository;

    @Mock
    Working_HousrRepository working_housrRepository;

    @Mock
    Current_Status_Societies_Repository current_status_societies_repository;

    @Mock
    Societies_Hours_Repositroy societies_hours_repositroy;

    @Mock
    Societies_Body_History_Repository societies_body_history_repository;

    @Mock
    private MDL_Jobs_Repository mdl_jobs_repository;

    @InjectMocks
    private TeacherController teacherController;

    private MockMvc mockMvc;

    @Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
//        this.mockMvc = MockMvcBuilders.standaloneSetup(teacherController).build();
        InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
        viewResolver.setPrefix("/WEB-INF/jsp/view/");
        viewResolver.setSuffix(".jsp");

        mockMvc = MockMvcBuilders.standaloneSetup(teacherController)
                .setViewResolvers(viewResolver)
                .build();
    }

    @Test
    public void teacherdata() throws Exception {

        Mockito.when(jobsRepository.find_society_name_by_patron("sarmad")).thenReturn(new ArrayList<>());
        Mockito.when(mdl_user_repository.get_teacher("sarmad")).thenReturn(new ArrayList<>());
        Mockito.when(mdl_course_repository.get_teacher_modules("sarmad")).thenReturn(new ArrayList<>());
        Mockito.when(mdl_user_repository.getStudents("sarmad")).thenReturn(new ArrayList<>());

        this.mockMvc.perform(get("/teacher_home").sessionAttr("fac_name", "sarmad").sessionAttr("id", 21))
                .andExpect(status().isOk())
                .andExpect(view().name("teacher_home"));

        this.mockMvc.perform(get("/teacher_home"))
                .andExpect(status().is(302))
                .andExpect(view().name("redirect:/"));
    }

    @Test
    public void teachersocieties() throws Exception {

        this.mockMvc.perform(get("/TeacherSocieties").sessionAttr("fac_name", "sarmad").sessionAttr("id", 21))
                .andExpect(status().isOk())
                .andExpect(view().name("TeacherSocieties"));

        this.mockMvc.perform(get("/TeacherSocieties"))
                .andExpect(status().is(302))
                .andExpect(view().name("redirect:/"));
    }

    @Test
    public void get_Student_Performance() throws Exception {

        this.mockMvc.perform(get("/student_detail/14031220").sessionAttr("fac_name", "sarmad").sessionAttr("id", 21))
                .andExpect(status().isOk())
                .andExpect(view().name("mystudent_performance"));

        this.mockMvc.perform(get("/student_detail/14031220"))
                .andExpect(status().is(302))
                .andExpect(view().name("redirect:/"));
    }

    @Test
    public void student_Attendance() throws Exception {

        this.mockMvc.perform(get("student_attendance").sessionAttr("fac_name", "sarmad").sessionAttr("id", 21))
                .andExpect(status().isOk())
                .andExpect(view().name("mystudent_attendance"));

        this.mockMvc.perform(get("/student_attendance"))
                .andExpect(status().is(302))
                .andExpect(view().name("redirect:/"));
    }

    @Test
    public void student_Societies() throws Exception {

        this.mockMvc.perform(get("/student_societies").sessionAttr("fac_name", "sarmad").sessionAttr("id", 21))
                .andExpect(status().isOk())
                .andExpect(view().name("mystudent_societies"));

        this.mockMvc.perform(get("/student_societies"))
                .andExpect(status().is(302))
                .andExpect(view().name("redirect:/"));
    }

    @Test
    public void hours() throws Exception {

        this.mockMvc.perform(get("/Enter_hours").sessionAttr("fac_name", "sarmad").sessionAttr("id", 21))
                .andExpect(status().isOk())
                .andExpect(view().name("Enter_hours"));

        this.mockMvc.perform(get("/Enter_hours"))
                .andExpect(status().is(302))
                .andExpect(view().name("redirect:/"));
    }

}