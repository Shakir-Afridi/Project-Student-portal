package com.StudentPortal.controllers;

import com.StudentPortal.repository.moodleds.MDL_User_Repository;
import com.StudentPortal.repository.moodleds.Messages_Repository;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import java.util.ArrayList;

import java.util.List;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

/**
 * Created by abdul on 5/2/17.
 */
public class DasBoard_ControllerTest {


    @Mock
    private Messages_Repository messages_repository;

    @Mock
    MDL_User_Repository mdl_user_repository;

    @InjectMocks
    private DasBoard_Controller dasBoard_controller;

    private MockMvc mockMvc;


    @Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
//        this.mockMvc = MockMvcBuilders.standaloneSetup(dasBoard_controller).build();

        InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
        viewResolver.setPrefix("/WEB-INF/jsp/view/");
        viewResolver.setSuffix(".jsp");

        mockMvc = MockMvcBuilders.standaloneSetup(dasBoard_controller)
                .setViewResolvers(viewResolver)
                .build();
    }

    @Test
    public void dashBoard() throws Exception {

        Mockito.when(mdl_user_repository.get_Email_Id("14031220")).thenReturn("ajabbar2014@namal.edu.pk");
        List<Object> messages = new ArrayList<>();
        Object[] objects = new Object[2];

        objects[0] = "Sarmad Ali";
        objects[1] = "Any Message";
        messages.add(objects);
        Mockito.when(messages_repository.messages_mime("ajabbar2014@namal.edu.pk")).thenReturn(messages);

        this.mockMvc.perform(get("/dashboard").sessionAttr("username", "14031220").sessionAttr("id", 21))
                .andExpect(status().isOk())
                .andExpect(view().name("dashboard"));

        this.mockMvc.perform(get("/dashboard"))
                .andExpect(status().is(302))
                .andExpect(view().name("redirect:/"));
    }

}