package com.StudentPortal.controllers;

import com.StudentPortal.repository.moodleds.*;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.List;
import java.util.ArrayList;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;


/**
 * Created by abdul on 5/1/17.
 */
public class AttendanceControllerTest {

    @Mock
    MDL_User_Repository mdl_user_repository;

    @Mock
    MDL_Course_Repository mdl_course_repository;

    @Mock
    MDL_Attendance_Repository mdl_attendance_repository;

    @Mock
    MDL_Attendance_Statuses_Repository mdl_attendance_statuses_repository;

    @Mock
    MDL_Attendance_Log_Repository mdl_attendance_log_repository;

    @Mock
    MDL_Attendance_Sessions_Repository mdl_attendance_sessions_repository;

    @InjectMocks
    private AttendanceController attendanceController;

    private MockMvc mockMvc;

    @Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
        this.mockMvc = MockMvcBuilders.standaloneSetup(attendanceController).build();

    }

    @Test
    public void attendance() throws Exception {

        Mockito.when(mdl_user_repository.find_year(21)).thenReturn(1);

        List<Object> list_courses = new ArrayList<>();
        Object[] objects = new Object[3];
        objects[0] = 78;
        objects[1] = "Calculus (Semester-1)";
        objects[2] = "Cal-2018";
        list_courses.add(objects);

        Mockito.when(mdl_course_repository.get_CourseOffering_By_Year(1, 21)).thenReturn(list_courses);
        Mockito.when(mdl_attendance_repository.get_attendance_id(78)).thenReturn(38);
        Mockito.when(mdl_attendance_statuses_repository.get_absent_status_id(38)).thenReturn(1);
        Mockito.when(mdl_attendance_statuses_repository.get_absent_status_id(38)).thenReturn(2);
        Mockito.when(mdl_attendance_log_repository.count_Present(21, 38, 1)).thenReturn(20);
        Mockito.when(mdl_attendance_log_repository.count_Absents(21, 38, 2)).thenReturn(4);
        Mockito.when(mdl_attendance_sessions_repository.count_sessions(38)).thenReturn(24);

        List<Object> session_information = new ArrayList<>();

        for(int i = 1;  i<=24; i++) {
            Object[] objects_session = new Object[2];
            objects_session[0] = i;
            objects_session[1] = 1403718264;
            session_information.add(objects_session);
        }

        Mockito.when(mdl_attendance_sessions_repository.sessions_information(38)).thenReturn(session_information);
        Mockito.when(mdl_attendance_log_repository.status_attendance(21, 2)).thenReturn(2);
        Mockito.when(mdl_attendance_statuses_repository.get_Status(2)).thenReturn("Present");

        this.mockMvc.perform(get("/attendance").sessionAttr("username", "14031220").sessionAttr("id", 21))
                .andExpect(status().isOk())
                .andExpect(view().name("Attendance"))
                .andExpect(model().attribute("current_year", 1));

        this.mockMvc.perform(get("/attendance"))
                .andExpect(status().is(302))
                .andExpect(view().name("redirect:/"));
    }

}