package com.StudentPortal.controllers;

import com.StudentPortal.repository.moodleds.MDL_Certificate_Request_Repository;
import com.StudentPortal.repository.moodleds.MDL_Jobs_Repository;
import org.assertj.core.util.ArrayWrapperList;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import java.util.ArrayList;

import java.util.Date;
import java.util.List;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

/**
 * Created by abdul on 5/1/17.
 */
public class CertificatesControllerTest {


    @Mock
    MDL_Certificate_Request_Repository mdl_certificate_request_repository;

    @Mock
    MDL_Jobs_Repository mdl_jobs_repository;

    @InjectMocks
    private CertificatesController certificatesController;

    private MockMvc mockMvc;

    @Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
        this.mockMvc = MockMvcBuilders.standaloneSetup(certificatesController).build();
    }

    @Test
    public void certificates() throws Exception {

        List<Object> certificates_information = new ArrayList<>();
        Object[] objects = new Object[4];
        objects[0] = new Date();
        objects[1] = 1;
        objects[2] = new Date();
        objects[3] = false;
        certificates_information.add(objects);

        Mockito.when(mdl_certificate_request_repository.certificates_information("14031220")).thenReturn(certificates_information);

        List<Object> title_nature = new ArrayList<>();
        Object[] objects1 = new Object[2];
        objects1[0] = "NSSI";
        objects1[1] = "Society";
        title_nature.add(objects1);

        Mockito.when(mdl_jobs_repository.get_Title_Nature(1)).thenReturn(title_nature);

        this.mockMvc.perform(get("/certificates").sessionAttr("username", "14031220").sessionAttr("id", 21))
                .andExpect(status().isOk())
                .andExpect(view().name("Certificates"));

        this.mockMvc.perform(get("/certificates"))
                .andExpect(status().is(302))
                .andExpect(view().name("redirect:/"));

    }

}