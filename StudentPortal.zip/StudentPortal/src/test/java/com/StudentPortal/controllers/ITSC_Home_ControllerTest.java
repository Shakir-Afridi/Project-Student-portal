package com.StudentPortal.controllers;

import com.StudentPortal.repository.papercutds.Issued_Items_Repository;
import com.StudentPortal.repository.papercutds.Items_Repository;
import com.StudentPortal.repository.papercutds.Tbl_User_Repository;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

/**
 * Created by abdul on 5/2/17.
 */
public class ITSC_Home_ControllerTest {

    @Mock
    Issued_Items_Repository issued_items_repository;

    @Mock
    Items_Repository items_repository;

    @Mock
    Tbl_User_Repository tbl_user_repository;

    @InjectMocks
    private ITSC_Home_Controller itsc_home_controller;

    private MockMvc mockMvc;


    @Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
//        this.mockMvc = MockMvcBuilders.standaloneSetup(itsc_home_controller).build();
        InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
        viewResolver.setPrefix("/WEB-INF/jsp/view/");
        viewResolver.setSuffix(".jsp");

        mockMvc = MockMvcBuilders.standaloneSetup(itsc_home_controller)
                .setViewResolvers(viewResolver)
                .build();
    }

    @Test
    public void ITSC_Dashboard() throws Exception {


        List<Object> items = new ArrayList<>();
        Object[] objects = new Object[3];

        objects[0] = 1;
        objects[1] = "Mouse";
        objects[2] = "EUDHSI23";
        items.add(objects);

        Mockito.when(items_repository.get_All_Items()).thenReturn(items);

        this.mockMvc.perform(get("/ITSC_Dashboard").sessionAttr("itsc", "itsc").sessionAttr("id", 34))
                .andExpect(status().isOk())
                .andExpect(view().name("ITSC_Dashboard"));

        this.mockMvc.perform(get("/ITSC_Dashboard"))
                .andExpect(status().is(302))
                .andExpect(view().name("redirect:/"));
    }

    @Test
    public void log_in() throws Exception {

        Mockito.when(issued_items_repository.get_Issued_Items()).thenReturn(new ArrayList<Object>());
        Mockito.when(items_repository.get_Items()).thenReturn(new ArrayList<>());

        this.mockMvc.perform(get("/itsc_items").sessionAttr("itsc", "itsc").sessionAttr("id", 34))
                .andExpect(status().isOk())
                .andExpect(view().name("issue_items"));

        this.mockMvc.perform(get("/itsc_items"))
                .andExpect(status().is(302))
                .andExpect(view().name("redirect:/"));
    }

    @Test
    public void delete_Item() throws Exception {

        this.mockMvc.perform(get("/delete_item/1").sessionAttr("itsc", "itsc").sessionAttr("id", 34))
                .andExpect(status().is(302))
                .andExpect(view().name("redirect:/ITSC_items"));

        this.mockMvc.perform(get("/itsc_items"))
                .andExpect(status().is(302))
                .andExpect(view().name("redirect:/"));
    }

}