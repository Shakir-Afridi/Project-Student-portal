package com.StudentPortal.controllers;

import com.StudentPortal.repository.moodleds.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import java.util.ArrayList;

import java.util.List;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

/**
 * Created by abdul on 5/1/17.
 */
public class Exam_ControllerTest {

    @Mock
    MDL_Course_Repository mdl_course_repository;

    @Mock
    MDL_Grade_Categories_Repository mdl_grade_categories_repository;

    @Mock
    MDL_Grade_Grades_Repository mdl_grade_grades_repository;

    @Mock
    MDL_User_Repository mdl_user_repository;

    @Mock
    MDL_Grade_Categories_History_Repository mdl_grade_categories_history_repository;

    @Mock
    MDL_Grade_Grades_History_Repository mdl_grade_grades_history_repository;

    @InjectMocks
    Exam_Controller exam_controller;

    private MockMvc mockMvc;


    @Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
//        this.mockMvc = MockMvcBuilders.standaloneSetup(exam_controller).build();

        InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
        viewResolver.setPrefix("/WEB-INF/jsp/view/");
        viewResolver.setSuffix(".jsp");

        mockMvc = MockMvcBuilders.standaloneSetup(exam_controller)
                .setViewResolvers(viewResolver)
                .build();
    }

    @Test
    public void tearDown() throws Exception {

        Mockito.when(mdl_user_repository.find_year(21)).thenReturn(1);

        List<Object> list_courses = new ArrayList<>();
        Object[] objects = new Object[3];
        objects[0] = 78;
        objects[1] = "Calculus (Semester-1)";
        objects[2] = 20;
        list_courses.add(objects);

        List<Object> assessments = new ArrayList<>();
        Object[] objects_assessments = new Object[3];
        objects_assessments[0] = 78;
        objects_assessments[1] = "Course Work-1";
        objects_assessments[2] = 20;
        assessments.add(objects_assessments);

        Mockito.when(mdl_course_repository.getEnrolledCourses(21, 1)).thenReturn(assessments);
        Mockito.when(mdl_grade_grades_repository.assessment_grades(78, 21)).thenReturn(78);

        List<Integer> integerList = new ArrayList<>();
        integerList.add(21);
        Mockito.when(mdl_user_repository.get_user_id(1)).thenReturn(integerList);

        this.mockMvc.perform(get("/Exam").sessionAttr("username", "14031220").sessionAttr("id", 21))
                .andExpect(status().isOk())
                .andExpect(view().name("Exam"));

        this.mockMvc.perform(get("/Exam"))
                .andExpect(status().is(302))
                .andExpect(view().name("redirect:/"));
    }

}