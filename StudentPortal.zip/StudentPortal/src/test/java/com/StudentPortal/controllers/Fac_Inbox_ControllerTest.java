package com.StudentPortal.controllers;

import com.StudentPortal.repository.moodleds.Attachments_Repository;
import com.StudentPortal.repository.moodleds.MDL_User_Repository;
import com.StudentPortal.repository.moodleds.Messages_Reply_Repository;
import com.StudentPortal.repository.moodleds.Messages_Repository;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import java.io.FileInputStream;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;


import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

/**
 * Created by abdul on 5/1/17.
 */
public class Fac_Inbox_ControllerTest {


    @Mock
    MDL_User_Repository mdl_user_repository;

    @Mock
    Messages_Repository messages_repository;

    @Mock
    Messages_Reply_Repository messages_reply_repository;

    @Mock
    Attachments_Repository attachments_repository;

    @InjectMocks
    Fac_Inbox_Controller fac_inbox_controller;

    private MockMvc mockMvc;

    @Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
//        this.mockMvc = MockMvcBuilders.standaloneSetup(fac_inbox_controller).build();
        InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
        viewResolver.setPrefix("/WEB-INF/jsp/view/");
        viewResolver.setSuffix(".jsp");

        mockMvc = MockMvcBuilders.standaloneSetup(fac_inbox_controller)
                .setViewResolvers(viewResolver)
                .build();
    }

    @Test
    public void read_Message() throws Exception {


        Mockito.when(mdl_user_repository.get_Email_Id("sarmad")).thenReturn("sarmad2014@namal.edu.pk");

        List<Object> messages = new ArrayList<>();
        Object[] objects = new Object[4];
        objects[0] = "Sarmad Ali";
        objects[1] = "sarmad@namaledu.pk";
        objects[2] = "ajabbar2014@namal.edu.pk";
        objects[3] = "Testing service";
        messages.add(objects);

        Mockito.when(messages_repository.get_Message(1)).thenReturn(messages);

        List<String> file_names = new ArrayList<>();
        Mockito.when(attachments_repository.get_Thread_Files_Names(1)).thenReturn(file_names);

        List<Object> messages_replies = new ArrayList<>();
        Object[] message_replies = new Object[5];
        message_replies[0] = 1;
        message_replies[1] = "Sarmad Ali";
        message_replies[2] = "sarmad@namaledu.pk";
        message_replies[3] = "ajabbar2014@namal.edu.pk";
        message_replies[4] = "Testing service";
        messages_replies.add(message_replies);

        Mockito.when(messages_reply_repository.get_Thread_Replies(1)).thenReturn(messages_replies);

        Mockito.when(attachments_repository.get_reply_Files_Names(1)).thenReturn(new ArrayList<String>());


        this.mockMvc.perform(get("/message/fac/"+1).sessionAttr("fac_name", "sarmad").sessionAttr("id", 21))
                .andExpect(status().isOk())
                .andExpect(view().name("message_read"));

        this.mockMvc.perform(get("/message/fac/1"))
                .andExpect(status().is(302))
                .andExpect(view().name("redirect:/"));
    }

    @Test
    public void upload_Files_Handler() throws Exception {


        FileInputStream inputFile = new FileInputStream( "path of the file");
        MockMultipartFile file = new MockMultipartFile("file", "NameOfTheFile", "multipart/form-data", inputFile);

        List<Object> messages_replies = new ArrayList<>();
        Object[] message_replies = new Object[4];
        message_replies[1] = "Sarmad Ali";
        message_replies[0] = "sarmad@namaledu.pk";
        message_replies[3] = "ajabbar2014@namal.edu.pk";
        message_replies[2] = "Abdul Malik";
        messages_replies.add(message_replies);

        Mockito.when(messages_repository.get_Information_For_Reply(1)).thenReturn(messages_replies);

        List<Object> messages_replies_ = new ArrayList<>();
        Object[] message_replies_ = new Object[5];
        message_replies_[0] = 1;
        message_replies_[1] = "Sarmad Ali";
        message_replies_[2] = "sarmad@namaledu.pk";
        message_replies_[3] = "ajabbar2014@namal.edu.pk";
        message_replies_[4] = "Testing service";
        messages_replies.add(message_replies_);

        Mockito.when(messages_reply_repository.get_Thread_Replies(1)).thenReturn(messages_replies_);
        List<String> file_names = new ArrayList<>();
        Mockito.when(attachments_repository.get_Thread_Files_Names(1)).thenReturn(file_names);

        List<Object> messages = new ArrayList<>();
        Object[] objects = new Object[4];
        objects[0] = "Sarmad Ali";
        objects[1] = "sarmad@namaledu.pk";
        objects[2] = "ajabbar2014@namal.edu.pk";
        objects[3] = "Testing service";
        messages.add(objects);

        Mockito.when(messages_repository.get_Message(1)).thenReturn(messages);
        Mockito.when(attachments_repository.get_reply_Files_Names(1)).thenReturn(new ArrayList<String>());


        this.mockMvc.perform(get("/send_reply/fac/message/" + "14031220" + "/" + "1").sessionAttr("fac_name", "14031220").sessionAttr("id", 21))

                .andExpect(status().isOk())
                .andExpect(view().name("message_read"));

        this.mockMvc.perform(get("/send_reply/fac/message/14031220/1"))
                .andExpect(status().is(302))
                .andExpect(view().name("redirect:/"));
    }

    @Test
    public void fac_inbox() throws Exception {

//
        Mockito.when(mdl_user_repository.get_Email_Id("sarmad")).thenReturn("sarmad@namal.edu.pk");

        List<Object> sender_information = new ArrayList<>();
        Object[] objects_sender = new Object[4];
        objects_sender[0] = 1;
        objects_sender[1] = "Sarmad Ali";
        objects_sender[2] = new Date();
        objects_sender[3] = "12:12 Am";
        sender_information.add(objects_sender);

        Mockito.when(messages_repository.get_Sender_Information("sarmad@namal.edu.pk", true)).thenReturn(sender_information);
        Mockito.when(messages_reply_repository.get_Reply_Status(1, "ajabbar2014@namal.edu.pk")).thenReturn(new Object[1]);

        this.mockMvc.perform(get("/fac_inbox").sessionAttr("fac_name", "sarmad").sessionAttr("id", 21))
                .andExpect(status().isOk())
                .andExpect(view().name("fac_inbox"));
//
        this.mockMvc.perform(get("/fac_inbox"))
                .andExpect(status().is(302))
                .andExpect(view().name("redirect:/"));
    }

    @Test
    public void home() throws Exception {
        Mockito.when(mdl_user_repository.get_Email_Id("sarmad")).thenReturn("sarmad@nama.edu.pk");
        List<Object> list_names = new ArrayList<>();
        Object[] names = new Object[2];
        names[0] = "Sarmad";
        names[1] = "Ali";
        list_names.add(names);

        Mockito.when(mdl_user_repository.get_Name_By_Email("sarmad@namal.edu.pk")).thenReturn(list_names);

        this.mockMvc.perform(get("/fac_send_message").sessionAttr("fac_name", "sarmad").sessionAttr("id", 21))
                .andExpect(status().isOk())
                .andExpect(view().name("redirect:/fac_inbox"));
//
        this.mockMvc.perform(get("/fac_send_message"))
                .andExpect(status().is(302))
                .andExpect(view().name("redirect:/"));
    }

    @Test
    public void fac_sent__inbox() throws Exception {

        Mockito.when(mdl_user_repository.get_Email_Id("sarmad")).thenReturn("sarmad@nama.edu.pk");

        List<Object> sent_messages = new ArrayList<>();
        Object[] objects = new Object[4];
        objects[0] = 1;
        objects[1] = "Sarmad Ali";
        objects[2] = new Date();
        objects[3] = "12:12 Am";
        sent_messages.add(objects);

        Mockito.when(messages_repository.get_Receiver_Information("sarmad@namal.edu.pk")).thenReturn(sent_messages);
        Mockito.when(messages_reply_repository.get_Reply_Status(1, "ajabbar2014@namal.edu.pk")).thenReturn(new Object[1]);

        this.mockMvc.perform(get("/sent_fac_inbox").sessionAttr("fac_name", "sarmad").sessionAttr("id", 21))
                .andExpect(status().isOk())
                .andExpect(view().name("fac_sent_messages"));
    }

}